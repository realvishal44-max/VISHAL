// ============================================================
// BCA STORE - script.js  (Complete Rewrite - All Fixed)
// ============================================================

// Global Maintenance Mode Check
(function () {
  const currentPage = window.location.pathname.split('/').pop().toLowerCase();
  const isAdminPage = window.location.pathname.toLowerCase().includes('admin');
  if (currentPage.includes('maintenance.html') || currentPage === 'maintenance' || isAdminPage) return;

  // Check bypass for Super Admin role
  let isAdminBypass = false;
  try {
    const auth = JSON.parse(localStorage.getItem('adminAuth'));
    const bypassMaint = localStorage.getItem('bypass_maintenance') === 'true';
    if (auth && (auth.role === 'admin' || auth.role === 'superadmin') && bypassMaint) {
      isAdminBypass = true;
    }
  } catch (e) { }

  if (isAdminBypass) return;

  // Quick cached block to avoid flash content
  if (localStorage.getItem('maintenance_mode_cache') === 'true') {
    document.documentElement.style.display = 'none';
    const isLocalFile = window.location.protocol === 'file:';
    window.location.href = isLocalFile ? 'maintenance.html' : '/maintenance';
    return;
  }
})();

// Global Scroll Handlers for UX
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  const btt = document.getElementById('backToTop');
  if (window.scrollY > 50) {
    if (nav) nav.classList.add('scrolled');
  } else {
    if (nav) nav.classList.remove('scrolled');
  }

  if (window.scrollY > 500) {
    if (btt) btt.classList.add('show');
  } else {
    if (btt) btt.classList.remove('show');
  }
});

const ELITE_BATCHES_STATIC = {};


// ============================================================
// 1. FIREBASE CONFIG
// ============================================================
const firebaseConfig = {
  apiKey: "AIzaSyC_mWJld2NksodLIg0hI_O0wuLWpUL4AoE",
  authDomain: "bca-store.firebaseapp.com",
  databaseURL: "https://bca-store-default-rtdb.firebaseio.com",
  projectId: "bca-store",
  storageBucket: "bca-store.firebasestorage.app",
  messagingSenderId: "1063532602856",
  appId: "1:1063532602856:web:30812a52ccbded1548305d",
  measurementId: "G-SEYBV2CS0W"
};

let db = null;
try {
  if (typeof firebase !== 'undefined') {
    const app = firebase.apps && firebase.apps.length > 0 ? firebase.app() : firebase.initializeApp(firebaseConfig);
    db = firebase.database(app);
    window.db = db;

    // Live Maintenance check
    db.ref('system/maintenance/enabled').on('value', (snap) => {
      const active = !!snap.val();
      localStorage.setItem('maintenance_mode_cache', active ? 'true' : 'false');

      const currentPage = window.location.pathname.split('/').pop().toLowerCase();
      const isAdminPage = window.location.pathname.toLowerCase().includes('admin');
      if (active && !currentPage.includes('maintenance') && !isAdminPage) {
        let isAdminBypass = false;
        try {
          const auth = JSON.parse(localStorage.getItem('adminAuth'));
          const bypassMaint = localStorage.getItem('bypass_maintenance') === 'true';
          if (auth && (auth.role === 'admin' || auth.role === 'superadmin') && bypassMaint) {
            isAdminBypass = true;
          }
        } catch (e) { }

        if (!isAdminBypass) {
          document.documentElement.style.display = 'none';
          const isLocalFile = window.location.protocol === 'file:';
          window.location.href = isLocalFile ? 'maintenance.html' : '/maintenance';
        }
      }
    });

    // Live Lockdown check
    db.ref('system/lockdown').on('value', (snap) => {
      const active = !!snap.val();
      if (active) {
        const currentPage = window.location.pathname.split('/').pop().toLowerCase();
        const isAdminPage = window.location.pathname.toLowerCase().includes('admin');
        if (isAdminPage) {
          let isSuperAdmin = false;
          try {
            const auth = JSON.parse(localStorage.getItem('adminAuth'));
            if (auth && auth.role === 'superadmin') {
              isSuperAdmin = true;
            }
          } catch (e) {}
          if (!isSuperAdmin) {
            forceLogoutSession("System lockdown activated by Super Admin.");
          }
        } else if (!currentPage.includes('maintenance.html') && !currentPage.includes('maintenance')) {
          showLockdownScreen();
        }
      } else {
        const overlay = document.getElementById('lockdownOverlay');
        if (overlay) overlay.remove();
      }
    });

    // Auto migration: batches_config -> batches
    db.ref('batches').once('value').then(async (snap) => {
      if (!snap.exists()) {
        const configSnap = await db.ref('batches_config').once('value');
        if (configSnap.exists()) {
          console.log("💾 Migrating batches data from batches_config to batches...");
          await db.ref('batches').set(configSnap.val());
        }
      }
    });

    // Live batches configuration sync for homepage dynamic updates
    db.ref('batches').on('value', (snap) => {
      const data = snap.val();
      if (data) {
        // Overwrite and sync with ELITE_BATCHES_STATIC in real-time
        Object.keys(data).forEach(batchId => {
          const remoteBatch = data[batchId];
          if (!ELITE_BATCHES_STATIC[batchId]) {
            ELITE_BATCHES_STATIC[batchId] = {
              url: `elite-batches.html?batch=${batchId}`
            };
          }
          // Merge remote batch configuration
          Object.assign(ELITE_BATCHES_STATIC[batchId], remoteBatch);
          // Maintain correct URL pointer
          if (!ELITE_BATCHES_STATIC[batchId].url) {
            ELITE_BATCHES_STATIC[batchId].url = `elite-batches.html?batch=${batchId}`;
          }
        });

        // Remove locally cached keys that no longer exist in Firebase
        Object.keys(ELITE_BATCHES_STATIC).forEach(key => {
          if (!data[key]) {
            delete ELITE_BATCHES_STATIC[key];
          }
        });

        // Trigger real-time UI card refreshes
        if (typeof renderSemesterCards === 'function') renderSemesterCards();
        if (typeof renderMyBatches === 'function') renderMyBatches();
      }
    });
  }
} catch (e) { console.warn("Firebase fallback:", e.message); }

// ============================================================
// 2. SUBJECT DATA
// ============================================================
const SUBJECTS = {
  Semester1: [
    { code: "BCA-101", name: "Mathematical Foundation", icon: "📐" },
    { code: "BCA-102", name: "Computer Fundamentals", icon: "💻" },
    { code: "BCA-103", name: "Business Communication & Information System", icon: "📊" },
    { code: "BCA-104", name: "C Programming", icon: "⌨️" },
    { code: "BCA-105", name: "Lab on DOS & Windows", icon: "🖥️" },
    { code: "BCA-106", name: "Lab on C", icon: "🔬" }
  ],
  Semester2: [
    { code: "BCA-201", name: "Discrete Mathematics", icon: "🔢" },
    { code: "BCA-202", name: "Computer Architecture", icon: "🏗️" },
    { code: "BCA-203", name: "Data Structure through C", icon: "🌲" },
    { code: "BCA-204", name: "System Analysis and Design", icon: "📋" },
    { code: "BCA-205", name: "Lab on MS-Office", icon: "📝" },
    { code: "BCA-206", name: "Lab on Data Structure", icon: "🔬" }
  ],
  Semester3: [
    { code: "BCA-301", name: "Management & Business Accounting", icon: "💰" },
    { code: "BCA-302", name: "Database Management System", icon: "🗄️" },
    { code: "BCA-303", name: "Object Oriented Programming using C++", icon: "🎯" },
    { code: "BCA-304", name: "Numerical Methodology", icon: "🔢" },
    { code: "BCA-305", name: "Lab on DBMS", icon: "🔬" },
    { code: "BCA-306", name: "Lab on C++", icon: "🔬" }
  ],
  Semester4: [
    { code: "BCA-401", name: "Java Programming", icon: "☕" },
    { code: "BCA-402", name: "Computer Graphics & Multimedia", icon: "🎨" },
    { code: "BCA-403", name: "Operating System & Linux", icon: "🐧" },
    { code: "BCA-404", name: "Software Engineering", icon: "🛠️" },
    { code: "BCA-405", name: "Lab on Java", icon: "🔬" },
    { code: "BCA-406", name: "Lab on Graphics & Linux", icon: "🔬" }
  ],
  Semester5: [
    { code: "BCA-501", name: "RDBMS", icon: "🗄️" },
    { code: "BCA-502", name: "AI with Python", icon: "🤖" },
    { code: "BCA-503", name: "Web Technology (HTML, CSS, JS)", icon: "🌐" },
    { code: "BCA-504", name: "Network & Cyber Law", icon: "🔒" },
    { code: "BCA-505", name: "Lab on Oracle", icon: "🔬" },
    { code: "BCA-506", name: "Lab on Python & Web", icon: "🔬" }
  ],
  Semester6: [
    { code: "BCA-601", name: "Project", icon: "🚀" },
    { code: "BCA-602", name: "Seminar", icon: "🎤" },
    { code: "BCA-603", name: "Viva", icon: "🎓" }
  ]
};
const SEMESTER_DESCRIPTIONS = {
  Semester1: "<div class='batch-systematic'>• 📚 Premium Notes<br>• 📜 Solved PYQs<br>• 🎥 Video Guides</div>",
  Semester2: "<div class='batch-systematic'>• 🧠 Data Structures<br>• 🏛️ Architecture Docs<br>• 🧪 Lab Manuals</div>",
  Semester3: "<div class='batch-systematic'>• 🎯 C++ Modules<br>• 🗄️ DBMS Workbooks<br>• 📊 Accountancy Notes</div>",
  Semester4: "<div class='batch-systematic'>• ☕ Java Projects<br>• 🐧 Linux Commands<br>• 🛠️ SE Blueprints</div>",
  Semester5: "<div class='batch-systematic'>• 🤖 Python & AI<br>• 🌐 Web Tech Code<br>• 🔒 Security Guides</div>",
  Semester6: "<div class='batch-systematic'>• 🚀 Project Support<br>• 🎤 Seminar Kits<br>• 🎓 Viva Prep Sets</div>"
};

const SAMPLE_QUESTIONS = [
  { q: "What is the time complexity of Binary Search?", a: "O(log n)" },
  { q: "What does OOP stand for?", a: "Object Oriented Programming" },
  { q: "What is normalization in DBMS?", a: "Organizing data to reduce redundancy and improve data integrity" },
  { q: "What is a pointer in C?", a: "A variable that stores the memory address of another variable" },
  { q: "Difference between TCP and UDP?", a: "TCP is connection-oriented and reliable; UDP is connectionless and faster" },
  { q: "What is an algorithm?", a: "A step-by-step procedure for solving a problem" },
  { q: "Define inheritance in C++.", a: "A mechanism where a class derives properties from a parent class" },
  { q: "What is a primary key in SQL?", a: "A column that uniquely identifies each row in a table" },
  { q: "What is recursion?", a: "A function that calls itself until a base condition is met" },
  { q: "Difference between stack and queue?", a: "Stack is LIFO; Queue is FIFO" },
  { q: "What is deadlock in OS?", a: "A state where processes wait for each other and none can proceed" },
  { q: "What is encapsulation?", a: "Bundling data and methods within one unit (class)" },
  { q: "Full form of HTML?", a: "HyperText Markup Language" },
  { q: "What is an IP address?", a: "A unique numerical label assigned to each device on a network" },
  { q: "What is polymorphism?", a: "The ability of an object to take many forms" }
];

const DEFINITIONS = {
  "algorithm": "A step-by-step procedure for solving a problem.",
  "array": "A data structure storing elements of the same type in contiguous memory.",
  "class": "A blueprint for creating objects with state and behavior.",
  "compiler": "Translates source code into machine code.",
  "database": "An organized collection of structured information stored electronically.",
  "encapsulation": "Bundling data and methods together within a class.",
  "function": "A reusable block of code that performs a specific task.",
  "inheritance": "A mechanism where a class acquires properties from a parent class.",
  "loop": "A control structure that repeats a block of code while a condition is true.",
  "normalization": "Organizing a database to reduce redundancy.",
  "object": "An instance of a class containing state and behavior.",
  "pointer": "A variable storing the memory address of another variable.",
  "polymorphism": "The ability of an object to behave differently in different contexts.",
  "recursion": "A function that calls itself to solve a problem.",
  "sql": "Structured Query Language — for managing relational databases.",
  "stack": "A LIFO (Last In First Out) data structure.",
  "queue": "A FIFO (First In First Out) data structure.",
  "thread": "The smallest unit of execution within a process.",
  "variable": "A named storage location in memory.",
  "linux": "An open-source Unix-like operating system kernel.",
  "java": "A high-level, object-oriented, platform-independent programming language.",
  "python": "A high-level interpreted language known for simplicity.",
  "html": "HyperText Markup Language — the standard for creating web pages.",
  "css": "Cascading Style Sheets — a language for styling HTML documents.",
  "javascript": "A scripting language for dynamic web content."
};

// ============================================================
// 3. UTILITIES
// ============================================================
function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}
function showToast(msg, type = 'success') {
  const c = document.getElementById('toastContainer');
  if (!c) return;
  const t = document.createElement('div');
  t.className = 'toast toast-' + type;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}
function formatDate(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function genId() { return Date.now().toString(36) + Math.random().toString(36).substr(2, 5); }
async function fetchUserIp() {
  try {
    const res = await fetch('https://api.ipify.org?format=json');
    const data = await res.json();
    lsSet('userIp', data.ip);
    return data.ip;
  } catch (e) { return null; }
}
function lsGet(key, fallback = null) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}
function lsSet(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch { } }
function highlightText(text, kw) {
  if (!kw || kw.length < 2) return text;
  return text.replace(new RegExp('(' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'), '<mark>$1</mark>');
}
function getYouTubeEmbed(url) {
  if (!url) return null;
  const reg = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
  const m = url.match(reg);
  return m ? 'https://www.youtube-nocookie.com/embed/' + m[1] + '?autoplay=1&rel=0' : null;
}
function getYouTubeThumb(url) {
  const reg = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
  const m = url.match(reg);
  return m ? `https://img.youtube.com/vi/${m[1]}/hqdefault.jpg` : 'https://via.placeholder.com/480x270?text=Video+Preview';
}
function isVideo(url) { return url && /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(url); }

function isImage(url) { return url && /\.(jpg|jpeg|png|gif|webp|svg)(\?.*)?$/i.test(url); }

function typeBadge(type) {
  const labels = { notes: '📝 Notes', pyq: '📄 PYQs', video: '🎥 Video', pyq_solve: '📜 PYQs Solve', program: '⌨️ Program' };
  return `<span class="card-type-badge badge-${type}">${labels[type] || type}</span>`;
}
function setCookie(name, value, days) {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + expires + '; path=/; SameSite=Lax';
}
function getCookie(name) {
  return document.cookie.split('; ').reduce((r, v) => {
    const parts = v.split('=');
    return parts[0] === name ? decodeURIComponent(parts[1]) : r;
  }, '');
}
function saveScrollPosition() { lsSet('scroll_' + location.href, window.scrollY); }
function restoreScrollPosition() {
  const p = lsGet('scroll_' + location.href, 0);
  if (p > 0) setTimeout(() => window.scrollTo({ top: p, behavior: 'smooth' }), 400);
}
function getSemesterProgress(semKey) {
  const done = lsGet('completed', {});
  const subs = SUBJECTS[semKey];
  if (!subs || !subs.length) return 0;
  return Math.round(subs.filter(s => done[semKey + '_' + s.code]).length / subs.length * 100);
}
function isMatDone(id) {
  if (!id) return false;
  const key = currentSemKey + '_' + currentCode + '_' + id;
  return lsGet('mat_completed', {})[key] || false;
}

// ============================================================
// 4. DARK MODE
// ============================================================
function initDarkMode() {
  const dark = lsGet('darkMode', false);
  if (dark) document.documentElement.setAttribute('data-theme', 'dark');
  updateDarkToggle(dark);
  const darkButton = document.getElementById('darkToggle');
  if (darkButton && darkButton.dataset.darkBound !== '1') {
    darkButton.dataset.darkBound = '1';
    darkButton.addEventListener('click', toggleDarkMode);
  }
}
function toggleDarkMode() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
  lsSet('darkMode', !isDark);
  updateDarkToggle(!isDark);
}
function updateDarkToggle(isDark) {
  const b = document.getElementById('darkToggle');
  if (b) b.textContent = isDark ? '☀️' : '🌙';
}

window.shareBatchOnWhatsApp = function (batchName, batchDescription, pagePath) {
  // Helper to clean HTML, markdown, and code snippets from the text
  const cleanText = (text) => {
    if (!text) return "";

    let clean = text;

    // 1. Remove contents of pre/code/style/script tags completely to ensure no code snippets leak
    clean = clean.replace(/<(pre|code|style|script)[^>]*>[\s\S]*?<\/\1>/gi, '');

    // 2. Decode common HTML entities using browser's DOM parser if available
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(clean, 'text/html');
      clean = doc.body.textContent || doc.body.innerText || clean;
    } catch (e) {
      // Fallback manual replacement
      clean = clean
        .replace(/&nbsp;/gi, ' ')
        .replace(/&amp;/gi, '&')
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/gi, "'")
        .replace(/&middot;/gi, '·')
        .replace(/&bullet;/gi, '•')
        .replace(/&ndash;/gi, '–')
        .replace(/&mdash;/gi, '—');
    }

    // 3. Strip remaining HTML tags
    clean = clean.replace(/<[^>]*>/g, '');

    // 4. Remove Markdown code blocks (```lang ... ```)
    clean = clean.replace(/```[\s\S]*?```/g, '');

    // 5. Remove inline backticks (but keep the text inside, e.g. `foo` -> foo)
    clean = clean.replace(/`/g, '');

    // 6. Split into lines and filter out lines that look like program code statements
    const lines = clean.split('\n');
    const cleanLines = lines.filter(line => {
      const trimmed = line.trim();
      if (!trimmed) return true; // Keep empty lines for formatting

      // Filter out typical programming statements or markup code lines
      const isRawCodeLine =
        // e.g. line ending with semicolon and containing code operators
        (trimmed.endsWith(';') && /[\+\-\*\/=\(\)\{\}\[\]]/.test(trimmed)) ||
        // line is just curly braces or parentheses
        /^[{}()[\]\s;]+$/.test(trimmed) ||
        // import / #include / require lines
        /^(#include|import\s+.*\s+from|require\()/i.test(trimmed) ||
        // comments
        /^\/\/|^\/\*|^\*/.test(trimmed);

      return !isRawCodeLine;
    });

    clean = cleanLines.join('\n').trim();

    // 7. Simplify brackets or brace structures (remove leftover JSON objects, code snippets)
    clean = clean.replace(/\{[^}]*\}/g, '');

    // 8. Normalize spacing and reduce multiple newlines to max 2
    clean = clean.replace(/[ \t]+/g, ' ');
    clean = clean.replace(/\n{3,}/g, '\n\n');

    return clean.trim();
  };

  const cleanName = cleanText(batchName);
  let cleanDesc = cleanText(batchDescription);

  // Truncate description if too long to keep the WhatsApp message concise and beautiful
  if (cleanDesc.length > 200) {
    cleanDesc = cleanDesc.substring(0, 197) + "...";
  }

  const origin = window.location.origin;
  const cleanPath = pagePath.startsWith('/') ? pagePath : '/' + pagePath;
  const shareUrl = origin + cleanPath;

  // Custom message content based on the page type
  let intro = `Hey! Check out this amazing batch on *BCA Store* 📚:`;
  let callToAction = `Access premium study materials, notes, lab manuals, and solved PYQs instantly:`;

  if (pagePath.includes('semester.html')) {
    intro = `Hey! Check out all the study materials for *${cleanName}* on *BCA Store* 📚:`;
    callToAction = `Access complete semester notes, solved PYQs, lab manuals, and video lectures instantly:`;
  } else if (pagePath.includes('elite-batches.html') || pagePath.includes('elite')) {
    intro = `Hey! Check out this premium *Elite Batch* on *BCA Store* 💎:`;
    callToAction = `Get premium notes, interactive lab programs, solved PYQs, and video lectures instantly:`;
  }

  const text = `*📚 BCA STUDY HUB 🎓*\n\n` +
    `${intro}\n\n` +
    `💎 *${cleanName}*\n` +
    `📝 ${cleanDesc}\n\n` +
    `${callToAction}\n` +
    `👉 ${shareUrl}\n\n` +
    `Start studying today! 🚀`;

  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  let whatsappUrl = "";
  if (isMobile) {
    whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
  } else {
    whatsappUrl = `https://web.whatsapp.com/send?text=${encodeURIComponent(text)}`;
  }
  window.open(whatsappUrl, '_blank');
};

const ADMIN_TOP_NAV_META = {
  dashboard: { title: 'Dashboard', subtitle: 'A calm control center for content and student growth.' },
  add: { title: 'Add Material', subtitle: 'Upload notes, videos, PDFs, and files in one fast flow.' },
  manage: { title: 'Manage Content', subtitle: 'Review, edit, and organize your library with less friction.' },
  test: { title: 'Test Hub', subtitle: 'Build quizzes and practice sessions without leaving the page.' },
  notifications: { title: 'Notices', subtitle: 'Send updates and announcements in a few clean steps.' },
  inbox: { title: 'Inbox', subtitle: 'Review student messages and suggestion cards.' },
  visitors: { title: 'Visitors', subtitle: 'Track active users and live presence at a glance.' },
  analytics: { title: 'Analytics', subtitle: 'Watch visits, growth, and content performance trends.' },
  community: { title: 'Community', subtitle: 'Moderate posts, polls, and engagement activity.' },
  voting: { title: 'Voting Hub', subtitle: 'Keep polls, votes, and feedback organized.' },
  'ai-settings': { title: 'AI Settings', subtitle: 'Tune analysis, automation, and smart recommendations.' },
  settings: { title: 'Settings', subtitle: 'Adjust theme, behavior, and system controls.' },
};

function updateAdminTopNavigation(tab) {
  const safeTab = ADMIN_TOP_NAV_META[tab] ? tab : 'dashboard';
  const meta = ADMIN_TOP_NAV_META[safeTab];

  document.querySelectorAll('[data-admin-topnav]').forEach((button) => {
    const isActive = button.getAttribute('data-admin-topnav') === safeTab;
    button.classList.toggle('active', isActive);
    if (isActive) {
      button.setAttribute('aria-current', 'page');
    } else {
      button.removeAttribute('aria-current');
    }
  });

  const titleEl = document.getElementById('admTopbarTitle');
  if (titleEl) titleEl.textContent = meta.title;

  const subtitleEl = document.getElementById('admTopbarSubtitle');
  if (subtitleEl) subtitleEl.textContent = meta.subtitle;

  document.title = `Admin Panel | ${meta.title}`;
}

window.updateAdminTopNavigation = updateAdminTopNavigation;

// ============================================================
// 5. NAVBAR
// ============================================================
function initNavbar() {
  const h = document.getElementById('hamburger');
  const nl = document.getElementById('navLinks');

  // Insert "📋 Attendance" desktop link
  if (nl) {
    const attendanceLink = document.getElementById('navAttendance') || nl.querySelector('a[href="attendance.html"]');
    if (attendanceLink) {
      if (window.location.pathname.includes('attendance.html')) {
        attendanceLink.classList.add('active');
        nl.querySelectorAll('.nav-link.active').forEach(el => {
          if (el !== attendanceLink) el.classList.remove('active');
        });
      }
    } else {
      const newAttendanceLink = document.createElement('a');
      newAttendanceLink.id = 'navAttendance';
      newAttendanceLink.className = 'nav-link';
      newAttendanceLink.href = 'attendance.html';
      newAttendanceLink.innerHTML = '📋 Attendance';
      if (window.location.pathname.includes('attendance.html')) {
        newAttendanceLink.classList.add('active');
        nl.querySelectorAll('.nav-link.active').forEach(el => el.classList.remove('active'));
      }

      const myBatchLink = nl.querySelector('a[href="my-batches.html"]') || nl.querySelector('a[href*="my-batches"]');
      const homeLink = nl.querySelector('a[href="index.html"]') || nl.querySelector('a[href*="index"]');
      if (myBatchLink) {
        nl.insertBefore(newAttendanceLink, myBatchLink.nextSibling);
      } else if (homeLink) {
        nl.insertBefore(newAttendanceLink, homeLink.nextSibling);
      } else {
        nl.insertBefore(newAttendanceLink, nl.firstChild);
      }
    }
  }

  // Insert "👤 My Account" desktop link
  if (nl) {
    if (!document.getElementById('navMyAccount')) {
      const isRegistered = localStorage.getItem('student_registered') === 'true';
      if (isRegistered) {
        const myAccountLink = document.createElement('a');
        myAccountLink.id = 'navMyAccount';
        myAccountLink.className = 'nav-link';
        myAccountLink.href = 'my-account.html';
        myAccountLink.innerHTML = '👤 My Account';
        if (window.location.pathname.includes('my-account.html')) {
          myAccountLink.classList.add('active');
          nl.querySelectorAll('.nav-link.active').forEach(el => el.classList.remove('active'));
        }

        const bookmarkBtn = document.getElementById('navBkBtn') || nl.querySelector('.nav-bookmark-btn');
        if (bookmarkBtn) {
          nl.insertBefore(myAccountLink, bookmarkBtn);
        } else {
          nl.appendChild(myAccountLink);
        }
      }
    }
  }

  // Insert dynamic Notifications Bell dropdown
  if (nl && !document.getElementById('navBellWrapper')) {
    const bellWrapper = document.createElement('div');
    bellWrapper.id = 'navBellWrapper';
    bellWrapper.className = 'bell-dropdown-container';
    bellWrapper.style.marginRight = '10px';
    
    bellWrapper.innerHTML = `
      <a href="notifications.html" class="notif-bell-btn nav-bell-btn" id="navBellBtn" title="Notifications" aria-label="Open notifications" style="text-decoration: none;">
        <span class="notif-bell-glyph">&#128276;</span>
        <span class="notif-badge-pill" id="bellBadge" style="display: none;">0</span>
      </a>
    `;
    
    const darkToggle = document.getElementById('darkToggle');
    const navBkBtn = document.getElementById('navBkBtn');
    if (navBkBtn) {
      nl.insertBefore(bellWrapper, navBkBtn);
    } else if (darkToggle) {
      nl.insertBefore(bellWrapper, darkToggle);
    } else {
      nl.appendChild(bellWrapper);
    }
  }

  // Desktop nav click-away behavior (still works on desktop)
  if (h && nl) {
    // Inject mobile drawer if not already injected
    if (!document.getElementById('mobileDrawer')) {
      injectMobileDrawer();
    }

    h.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMobileDrawer();
    });
  }

  // Run security check hook safely
  if (typeof verifyActiveSession === 'function') {
    verifyActiveSession();
  }

  // Block Protection
  checkBlockStatus();

  let lastScrollY = window.scrollY;
  let ticking = false;

  window.addEventListener('scroll', () => {
    lastScrollY = window.scrollY;
    if (!ticking) {
      window.requestAnimationFrame(() => {
        const nav = document.getElementById('navbar');
        if (nav) {
          nav.style.boxShadow = lastScrollY > 10 ? '0 4px 24px rgba(0,0,0,0.15)' : '';
          nav.style.transform = lastScrollY > 10 ? 'translateY(0)' : ''; // Keep it stable
        }
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
}

function injectMobileDrawer() {
  // Clean up any existing drawer to ensure no DOM duplicates
  const existingDrawer = document.getElementById('mobileDrawer');
  const existingOverlay = document.getElementById('mobileOverlay');
  if (existingDrawer) existingDrawer.remove();
  if (existingOverlay) existingOverlay.remove();

  // Determine active page
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const isHome = currentPage === 'index.html' || currentPage === '' || currentPage === '/';
  const isBatch = currentPage === 'my-batches.html';
  const isSemester = currentPage === 'semester.html' || currentPage === 'subject.html';
  const isAdmin = currentPage === 'admin.html';
  const isStaff = currentPage === 'staff.html';

  // Get user name
  const userName = lsGet('userName', '');
  const displayName = userName || 'Student';
  const initial = displayName.charAt(0).toUpperCase();

  // Get enrolled batch count
  const enrolledCount = lsGet('enrolledBatches', []).length;

  const isRegistered = localStorage.getItem('student_registered') === 'true';
  const headerClickAttr = isRegistered ? 'style="cursor: pointer;" onclick="closeMobileDrawer(); window.location.href=\'my-account.html\';"' : '';

  // Retrieve customized profile picture
  let photoHtml = `<div class="drawer-avatar">${initial}</div>`;
  const studentDataStr = localStorage.getItem('student_data');
  if (studentDataStr) {
    try {
      const studentData = JSON.parse(studentDataStr);
      if (studentData.photo) {
        photoHtml = `<img src="${studentData.photo}" class="drawer-avatar" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary);" />`;
      }
    } catch (e) { }
  }

  const drawerHTML = `
    <div class="mobile-menu-overlay" id="mobileOverlay"></div>
    <div class="mobile-drawer" id="mobileDrawer">
      <div class="drawer-header" ${headerClickAttr}>
        ${photoHtml}
        <div class="drawer-profile-info">
          <div class="drawer-user-name">${displayName}</div>
          <div class="drawer-user-role-premium">Premium Student 👑</div>
        </div>
        <a href="javascript:void(0)" class="notif-bell-btn drawer-notif-link ${window.location.pathname.includes('notifications.html') ? 'active' : ''}" aria-label="Open notifications" onclick="event.stopPropagation(); closeMobileDrawer(); window.location.href='notifications.html';">
          <span class="notif-bell-glyph">&#128276;</span>
          <span class="notif-badge-pill" id="mobileNotifBadge" style="display: none;">0</span>
        </a>
      </div>
      
      <div class="drawer-nav">
        ${!isRegistered ? `
          <div class="drawer-login-card" onclick="closeMobileDrawer(); if (window.triggerStudentLoginPopup) window.triggerStudentLoginPopup();" style="margin: 0 16px 16px; padding: 16px; background: rgba(139, 92, 246, 0.1); border: 1px dashed rgba(139, 92, 246, 0.4); border-radius: 12px; cursor: pointer; text-align: center; transition: all 0.3s ease;">
            <div style="font-size: 1.2rem; margin-bottom: 6px;">🔑</div>
            <div style="font-weight: 800; color: #a78bfa; font-size: 0.9rem;">Student Login / Register</div>
            <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 4px;">Access all premium features & save progress</div>
          </div>
        ` : ''}
        <div class="drawer-section-label">Quick Access</div>
        <div class="drawer-grid-menu">
          <!-- Featured Elite Plus Workspace -->
          <a href="elite-plus.html" class="drawer-grid-item ${window.location.pathname.includes('elite-plus.html') || window.location.pathname.includes('elite-batches.html') ? 'active' : ''}" style="grid-column: span 3; display: flex; align-items: center; justify-content: center; gap: 10px; background: linear-gradient(135deg, rgba(139, 92, 246, 0.25) 0%, rgba(59, 130, 246, 0.25) 100%); border: 1.5px solid rgba(139, 92, 246, 0.55); box-shadow: 0 4px 20px rgba(139, 92, 246, 0.25); margin-bottom: 12px; border-radius: 16px; transition: all 0.4s ease;">
            <div class="grid-item-icon" style="font-size: 1.4rem; margin-bottom: 0; animation: wgFloat 2s infinite ease-in-out;">💎</div>
            <div class="grid-item-text" style="color: #c084fc; font-weight: 900; font-size: 0.95rem; text-transform: uppercase; letter-spacing: 0.8px; text-shadow: 0 0 10px rgba(167, 139, 250, 0.3);">Elite Plus</div>
          </a>

          <a href="index.html" class="drawer-grid-item ${isHome ? 'active' : ''}">
            <div class="grid-item-icon">🏠</div>
            <div class="grid-item-text">Home</div>
          </a>
          <a href="my-batches.html" class="drawer-grid-item ${isBatch ? 'active' : ''}">
            <div class="grid-item-icon">🎓</div>
            <div class="grid-item-text">My Batch</div>
            ${enrolledCount > 0 ? `<div class="grid-item-badge">${enrolledCount}</div>` : ''}
          </a>
          <a href="${isRegistered ? 'my-account.html' : 'javascript:void(0)'}" class="drawer-grid-item ${window.location.pathname.includes('my-account.html') ? 'active' : ''}" ${!isRegistered ? 'onclick="closeMobileDrawer(); if(window.showRegistrationModal) window.showRegistrationModal(false, \'login\')"' : ''}>
            <div class="grid-item-icon">👤</div>
            <div class="grid-item-text">My Account</div>
          </a>
          <a href="attendance.html" class="drawer-grid-item ${window.location.pathname.includes('attendance.html') ? 'active' : ''}">
            <div class="grid-item-icon">📋</div>
            <div class="grid-item-text">Attendance</div>
          </a>
          <a href="exam.html" class="drawer-grid-item ${window.location.pathname.includes('exam.html') ? 'active' : ''}">
            <div class="grid-item-icon">📝</div>
            <div class="grid-item-text">Exam</div>
          </a>
          <a href="semester.html?sem=1" class="drawer-grid-item ${isSemester ? 'active' : ''}">
            <div class="grid-item-icon">📖</div>
            <div class="grid-item-text">Subjects</div>
          </a>
          <a href="test-hub.html" class="drawer-grid-item ${window.location.pathname.includes('test-hub.html') ? 'active' : ''}">
            <div class="grid-item-icon">🧠</div>
            <div class="grid-item-text">Tests</div>
          </a>
          <a href="community.html" class="drawer-grid-item ${window.location.pathname.includes('community.html') ? 'active' : ''}">
            <div class="grid-item-icon">🧑‍🤝‍🧑</div>
            <div class="grid-item-text">Community</div>
          </a>
          <a href="analytics.html" class="drawer-grid-item ${window.location.pathname.includes('analytics.html') ? 'active' : ''}">
            <div class="grid-item-icon">📊</div>
            <div class="grid-item-text">Stats</div>
          </a>
          <a href="javascript:void(0)" class="drawer-grid-item bk-drawer-item" onclick="closeMobileDrawer(); setTimeout(openBkPanel, 300);">
            <div class="grid-item-icon">🔖</div>
            <div class="grid-item-text">Bookmarks</div>
            ${(lsGet('bookmarks_v2', []).length > 0) ? `<div class="grid-item-bk-badge">${lsGet('bookmarks_v2', []).length}</div>` : ''}
          </a>
          <a href="developer.html" class="drawer-grid-item ${window.location.pathname.includes('developer.html') ? 'active' : ''}">
            <div class="grid-item-icon">👨‍💻</div>
            <div class="grid-item-text">Developer</div>
          </a>
          <a href="contact.html" class="drawer-grid-item ${window.location.pathname.includes('contact.html') ? 'active' : ''}">
            <div class="grid-item-icon">📧</div>
            <div class="grid-item-text">Contact</div>
          </a>
          <a href="javascript:void(0)" class="drawer-grid-item" onclick="closeMobileDrawer(); setTimeout(openSuggestionModal, 300);">
            <div class="grid-item-icon">💡</div>
            <div class="grid-item-text">Suggestion</div>
          </a>
        </div>

        <div class="drawer-section-label">Semesters</div>
        <div class="semester-square-grid">
          ${[1, 2, 3, 4, 5, 6].map(s => `
            <a href="semester.html?sem=${s}" class="sem-square-item ${window.location.search.includes('sem=' + s) ? 'active' : ''}">
              <span class="sem-num">${s}</span>
              <span class="sem-label">SEM</span>
            </a>
          `).join('')}
        </div>

        <div class="drawer-section-label">Resources</div>
        <div class="resource-square-grid">
          <a href="semester.html?sem=1&type=notes" class="res-square-item">
            <span class="res-icon">📝</span>
            <span class="res-text">Notes</span>
          </a>
          <a href="semester.html?sem=1&type=pyq" class="res-square-item">
            <span class="res-icon">📜</span>
            <span class="res-text">PYQs</span>
          </a>

          <a href="semester.html?sem=1&type=syllabus" class="res-square-item">
            <span class="res-icon">📋</span>
            <span class="res-text">Syllabus</span>
          </a>
        </div>
      </div>

      <div class="drawer-footer">
        <div class="drawer-dark-toggle" id="drawerDarkToggle" onclick="toggleDarkMode(); updateDrawerDarkSwitch();">
          <div class="drawer-dark-label">
            <span id="drawerDarkIcon">🌙</span>
            <span id="drawerDarkText">Dark Mode</span>
          </div>
          <div class="drawer-dark-switch" id="drawerDarkSwitch"></div>
        </div>
        <div class="drawer-version">BCA Store • V2.0 Professional</div>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', drawerHTML);

  // Overlay click to close
  document.getElementById('mobileOverlay').addEventListener('click', () => {
    closeMobileDrawer();
  });

  // Close on link click
  document.querySelectorAll('.drawer-nav-item').forEach(link => {
    link.addEventListener('click', () => {
      closeMobileDrawer();
    });
  });

  // Close on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeMobileDrawer();
  });
}

function toggleMobileDrawer() {
  const drawer = document.getElementById('mobileDrawer');

  // If drawer is already open, close it
  if (drawer && drawer.classList.contains('open')) {
    closeMobileDrawer();
    return;
  }

  // Always rebuild the drawer on open to ensure username and dynamic counts are perfectly fresh
  injectMobileDrawer();

  const newDrawer = document.getElementById('mobileDrawer');
  const newOverlay = document.getElementById('mobileOverlay');
  const newHamburger = document.getElementById('hamburger');

  if (newDrawer) {
    newDrawer.classList.add('open');
    if (newOverlay) newOverlay.classList.add('show');
    if (newHamburger) newHamburger.classList.add('active');
    document.body.classList.add('drawer-open');
  }
}

function closeMobileDrawer() {
  const drawer = document.getElementById('mobileDrawer');
  const overlay = document.getElementById('mobileOverlay');
  const hamburger = document.getElementById('hamburger');
  if (drawer) drawer.classList.remove('open');
  if (overlay) overlay.classList.remove('show');
  if (hamburger) hamburger.classList.remove('active');
  document.body.classList.remove('drawer-open');
}

function updateDrawerDarkSwitch() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const icon = document.getElementById('drawerDarkIcon');
  const text = document.getElementById('drawerDarkText');
  if (icon) icon.textContent = isDark ? '☀️' : '🌙';
  if (text) text.textContent = isDark ? 'Light Mode' : 'Dark Mode';
}

// ============================================================
// 6. SUGGESTION SYSTEM
// ============================================================
function openSuggestionModal() {
  const modal = document.getElementById('suggestionModal');
  if (!modal) return;
  modal.classList.add('active');

  // Pre-fill name if available
  const name = lsGet('userName', '');
  const nameInp = document.getElementById('suggName');
  if (nameInp && !nameInp.value) nameInp.value = name;

  // Set context (current page/subject)
  const contextInp = document.getElementById('suggContext');
  if (contextInp) {
    let ctx = window.location.pathname.split('/').pop() || 'Home';
    if (typeof currentCode !== 'undefined' && currentCode) ctx += ` › Subject: ${currentCode}`;
    else if (getParam('sem')) ctx += ` › Semester: ${getParam('sem')}`;
    contextInp.value = ctx;
  }
}
function closeSuggestionModal() {
  document.getElementById('suggestionModal')?.classList.remove('active');
  // Reset body if success state was shown
  setTimeout(() => {
    const body = document.getElementById('suggestionBody');
    const footer = document.getElementById('suggestionFooter');
    if (body && footer && body.innerHTML.includes('sugg-success-state')) {
      location.reload(); // Simplest way to reset the complex modal structure
    }
  }, 300);
}
function updateCharCount(el) {
  const cur = document.getElementById('charCurrent');
  if (cur) cur.textContent = el.value.length;
}
function submitSuggestion() {
  const name = document.getElementById('suggName')?.value.trim() || 'Anonymous';
  const email = document.getElementById('suggEmail')?.value.trim() || 'No Email';
  const subject = document.getElementById('suggSubject')?.value.trim();
  const category = document.getElementById('suggCategory')?.value || 'General';
  const context = document.getElementById('suggContext')?.value || 'Unknown';
  const msg = document.getElementById('suggMessage')?.value.trim();

  if (!subject) { showToast('❌ Please enter a subject.', 'error'); return; }
  if (!msg) { showToast('❌ Please enter a message.', 'error'); return; }
  if (!db) { showToast('❌ Firebase not connected.', 'error'); return; }

  // Show loading state on button
  const submitBtn = document.querySelector('#suggestionModal .btn-primary');
  const originalBtnText = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<span class="spinner-sm"></span> Sending...';

  const visitorId = getVisitorId();
  const ip = lsGet('userIp', 'Pending...');

  const suggData = {
    visitorId,
    name,
    email,
    subject,
    category,
    context,
    lastMessage: msg,
    date: Date.now(),
    read: false,
    status: 'Pending',
    ip: ip,
    messages: {
      [genId()]: { text: msg, sender: 'user', date: Date.now() }
    }
  };

  db.ref('suggestions').push(suggData).then(() => {
    // Show visual success state
    const body = document.getElementById('suggestionBody');
    const footer = document.getElementById('suggestionFooter');
    if (body && footer) {
      body.innerHTML = `
          <div class="sugg-success-state" style="text-align:center; padding: 40px 20px;">
          <span class="sugg-success-icon" style="font-size: 4rem; display:block; margin-bottom: 20px;">🚀</span>
          <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Suggestion Received!</h3>
          <p style="color:var(--text-muted); line-height:1.6;">Thank you for helping us improve **BCA Store**. Admin will review your feedback soon.</p>
        </div>`;
      footer.innerHTML = `<button class="btn-primary" style="width:100%" onclick="closeSuggestionModal()">Close</button>`;
    } else {
      showToast('✅ Message sent!', 'success');
      closeSuggestionModal();
    }
  }).catch((err) => {
    console.error(err);
    showToast('❌ Failed to send.', 'error');
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalBtnText;
  });
}

function sendAdminMessage(id) {
  const msg = prompt('Enter your reply to this user:');
  if (!msg || !db) return;

  const newMsgKey = db.ref('suggestions/' + id + '/messages').push().key;
  db.ref('suggestions/' + id + '/messages/' + newMsgKey).set({
    text: msg,
    sender: 'admin',
    date: Date.now()
  }).then(() => {
    db.ref('suggestions/' + id).update({ read: true, lastMessage: msg });
    showToast('💬 Reply sent successfully!', 'success');
  }).catch(() => showToast('❌ Failed to send.', 'error'));
}

function sendUserMessage(id) {
  const msg = prompt('Enter your message for the admin:');
  if (!msg || !db) return;

  const newMsgKey = db.ref('suggestions/' + id + '/messages').push().key;
  db.ref('suggestions/' + id + '/messages/' + newMsgKey).set({
    text: msg,
    sender: 'user',
    date: Date.now()
  }).then(() => {
    db.ref('suggestions/' + id).update({ read: false, lastMessage: msg });
    showToast('🚀 Message sent to admin!', 'success');
    renderSuggHistory();
  }).catch(() => showToast('❌ Failed to send.', 'error'));
}

function switchSuggTab(tab) {
  const sendView = document.getElementById('suggSendView');
  const histView = document.getElementById('suggHistoryView');
  const tabSend = document.getElementById('tabSend');
  const tabHist = document.getElementById('tabHistory');

  if (tab === 'history') {
    sendView.style.display = 'none';
    histView.style.display = 'block';
    tabSend.classList.remove('active');
    tabHist.classList.add('active');
    renderSuggHistory();
  } else {
    sendView.style.display = 'block';
    histView.style.display = 'none';
    tabSend.classList.add('active');
    tabHist.classList.remove('active');
  }
}

function renderSuggHistory() {
  const cont = document.getElementById('suggestionHistoryBody');
  if (!cont || !db) return;
  cont.innerHTML = '<div style="text-align:center;padding:20px;">⌛ Loading your history...</div>';

  const visitorId = getVisitorId();
  db.ref('suggestions').orderByChild('visitorId').equalTo(visitorId).once('value', snap => {
    if (!snap.exists()) {
      cont.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-muted);">You haven\'t sent any suggestions yet!</div>';
      return;
    }
    const history = [];
    snap.forEach(child => { history.unshift({ id: child.key, ...child.val() }); });

    cont.innerHTML = history.map(h => {
      const msgs = h.messages ? Object.values(h.messages) : [];
      return `
        <div class="history-item">
          <div style="display:flex;justify-content:space-between;font-size:0.75rem;color:var(--text-muted);margin-bottom:8px;">
            <span>${h.category}</span>
            <span>${formatDate(h.date)}</span>
          </div>
          
          <div class="user-chat-thread" style="margin-bottom:12px;">
            ${msgs.map(m => `
              <div style="margin-bottom:10px; text-align:${m.sender === 'admin' ? 'left' : 'right'}">
                <div style="display:inline-block; padding:8px 12px; border-radius:12px; font-size:0.85rem; 
                  background:${m.sender === 'admin' ? 'var(--primary-light)' : 'var(--primary)'}; 
                  color:${m.sender === 'admin' ? 'var(--primary)' : '#fff'};
                  border:1px solid ${m.sender === 'admin' ? 'var(--primary)' : 'transparent'}">
                  ${m.text}
                </div>
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:2px;">${formatDate(m.date)}</div>
              </div>
            `).join('')}
          </div>

          <button class="btn-outline btn-sm" style="width:100%; font-size:0.8rem;" onclick="sendUserMessage('${h.id}')">💬 Reply Back to Admin</button>
        </div>
      `;
    }).join('');
  });
}

function adminReply(id) {
  const msg = prompt('Enter your reply to this suggestion:');
  if (!msg || !db) return;

  db.ref('suggestions/' + id).update({
    reply: msg,
    replyDate: Date.now(),
    read: true
  }).then(() => {
    showToast('💬 Reply sent successfully!', 'success');
    loadInboxMessages();
  }).catch(() => showToast('❌ Failed to send reply.', 'error'));
}

function checkMyReplies() {
  if (!db) return;
  const visitorId = getVisitorId();

  db.ref('suggestions').orderByChild('visitorId').equalTo(visitorId).on('child_changed', snap => {
    const data = snap.val();
    if (data.reply && !lsGet('replied_' + snap.key, false)) {
      showToast(`📢 Admin replied to your suggestion: "${data.reply.substring(0, 30)}..."`, 'success');
      lsSet('replied_' + snap.key, true);
    }
  });
}

// ============================================================
// 7. GLOBAL UI INITIALIZATION
// ============================================================
function initGlobalUI() {
  initDarkMode();
  initNavbar();
  initWelcomeFlow();
  updateNavGreeting(); // Ensure greeting and logout button state is correct
  initVisitCounter();
  restoreScrollPosition();
  window.addEventListener('beforeunload', saveScrollPosition);
  checkMyReplies();
  updateBkNavBadge();
  if (typeof syncAssistantKnowledge === 'function') syncAssistantKnowledge();
  if (typeof loadLiveNotificationsService === 'function') loadLiveNotificationsService();
}

function loadLiveNotificationsService() {
  if (document.getElementById('notif-service-loader')) return;
  const script = document.createElement('script');
  script.id = 'notif-service-loader';
  script.src = 'notifications-service.js';
  script.onload = () => {
    if (window.NotificationsService) {
      window.NotificationsService.listenForRealTimeNotifications();
      
      const isRegistered = localStorage.getItem('student_registered') === 'true';
      const studentId = localStorage.getItem('student_id');
      const userName = localStorage.getItem('userName');
      if (isRegistered && studentId) {
        window.NotificationsService.startUserHeartbeat(studentId, userName);
      }
    }
  };
  document.head.appendChild(script);
}

// ============================================================
// 7.1 HOME PAGE
// ============================================================
function initScrollReveal() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');

        // Trigger statistics counters if this is the stats strip
        if (entry.target.classList.contains('stats-strip')) {
          entry.target.querySelectorAll('.stat-number').forEach(el => {
            const target = parseInt(el.getAttribute('data-target')) || 0;
            const hasPlus = el.textContent.includes('+');
            animateCounterValue(el, 0, target, 1000, hasPlus ? '+' : '');
          });
        }

        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Target elements to reveal
  const revealElements = document.querySelectorAll('.reveal, .reveal-stagger, .reveal-scale');
  revealElements.forEach(el => observer.observe(el));
}

function initHomePage() {
  initGlobalUI();
  renderSemesterCards();
  renderProgressGrid();
  renderNotifications();
  checkRevisionDue();
  initScrollReveal();
  initCookieConsent(); // Added professional cookie flow
  const f = getParam('filter');
  if (f && document.getElementById('globalSearch')) document.getElementById('globalSearch').value = f;
  renderMyBatches();

  // Launch Notification
  if (!lsGet('launched_v2', false)) {
    setTimeout(() => {
      showToast('🚀 Welcome to BCA STORE Professional Edition!', 'success');
      lsSet('launched_v2', true);
    }, 2000);
  }

  // Sync visitor activity if name exists
  if (lsGet('userName')) {
    fetchUserIp().then(() => syncVisitorData());
  }

  // ── ANALYTICS: session start + streak ──
  if (typeof BCA_Analytics !== 'undefined') {
    BCA_Analytics.trackSessionStart();
    BCA_Analytics.trackPageVisit('home');
  }
}

// ============================================================
// 7.2 ENROLLMENT SYSTEM
// ============================================================
function enrollInBatch(semKey) {
  const isRegistered = localStorage.getItem('student_registered') === 'true';
  if (!isRegistered) {
    if (window.showRegistrationModal) {
      localStorage.setItem('pendingStandardEnrollment', semKey);
      window.showRegistrationModal(false, 'register', semKey);
    } else {
      alert("Please register or login first to enroll!");
    }
    return;
  }

  const enrolled = lsGet('enrolledBatches', []);
  const isFirstEnrollment = enrolled.length === 0;
  if (!enrolled.includes(semKey)) {
    enrolled.push(semKey);
    lsSet('enrolledBatches', enrolled);

    // Increment global enrollment counter in Firebase
    if (db) {
      db.ref('site_stats/totalEnrolled').transaction(current => (current || 0) + 1);
    }

    showToast('🎉 Enrolled successfully in ' + semKey + '!', 'success');
    renderSemesterCards();
    renderMyBatches();
    fetchUserIp().then(() => syncVisitorData());
  }
}

function isEnrolled(semKey) {
  return lsGet('enrolledBatches', []).includes(semKey);
}

function generateBatchCardHTML(k, enrolled) {
  const n = k.replace('Semester', '');
  const desc = SEMESTER_DESCRIPTIONS[k] || "Access all study materials for this semester.";
  const p = getSemesterProgress(k);
  const subCount = (SUBJECTS[k] || []).length;

  return `
    <div class="batch-header">
      <div class="batch-status-badge">${enrolled ? '✅ ENROLLED' : '📢 OPEN'}</div>
      <button class="batch-card-whatsapp-share" onclick="event.stopPropagation(); window.shareBatchOnWhatsApp('Semester ${n}', '${desc.replace(/'/g, "\\'")}', 'semester.html?sem=${n}')" title="Share on WhatsApp">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L3 496l131-34.3c32.7 17.8 69.3 27.2 106.6 27.2 122.4 0 222-99.6 222-222 0-59.3-23.2-115-65.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-77.9 20.4 20.8-76-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
      </button>
      <!-- Premium large decorative background number -->
      <div class="batch-bg-number">${n}</div>
      <div class="batch-sem-label">Semester ${n}</div>
    </div>
    <div class="batch-body">
      <div class="batch-desc">${desc}</div>
      <div class="batch-info-strip">
        <span>📚 ${subCount} Subjects</span>
        <span>💎 Premium Notes</span>
      </div>
      <div class="batch-features">
        <span class="feature-tag">📄 PYQ Sets</span>
        <span class="feature-tag">💻 Lab Manuals</span>
      </div>
      <div class="batch-price-row">
        <span class="batch-price-final">₹0</span>
        <span class="batch-price-old">₹999</span>
        <span class="batch-price-tag">FREE</span>
      </div>
      <div class="batch-footer">
        ${enrolled ? `
          <div class="batch-progress-wrap">
            <div style="display:flex;justify-content:space-between;font-size:0.75rem;color:var(--text-muted);margin-bottom:6px;">
              <span>Batch Progress</span><span>${p}%</span>
            </div>
            <div class="progress-bar-track">
              <div class="progress-bar-fill" style="width:${p}%"></div>
            </div>
          </div>
          <div style="display: flex; gap: 8px; width: 100%;">
            <button class="batch-btn" style="flex: 1; margin: 0;" onclick="location.href='semester.html?sem=${n}'">Let's Study 📖</button>
          </div>
        ` : `
          <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom: 2px;">Enroll to start studying</div>
          <div style="display: flex; gap: 8px; width: 100%;">
            <button class="batch-btn batch-btn-gold" style="flex: 1; margin: 0;" onclick="enrollInBatch('${k}')">Enroll Now 🚀</button>
          </div>
        `}
      </div>
    </div>`;
}


window.generateUnifiedBatchCardHTML = function(batchId, batchData) {
  injectCardStyles();
  
  const enrolled = JSON.parse(localStorage.getItem('enrolledEliteBatches') || '[]');
  const isEnrolled = enrolled.includes(batchId);
  const isPlacement = batchData.category === 'placement';
  const color = batchData.color || '#8b5cf6';
  
  const coverImageSrc = batchData.thumbnail || (isPlacement ? 'placement_cover.png' : 'elite_cover.png');
  
  const ctaText = isPlacement ? 'Join Placement' : 'Enroll Free';
  const priceDisplay = batchData.price === 'Free' || !batchData.price ? 'FREE' : batchData.price;
  const originalPriceDisplay = batchData.originalPrice || '';
  
  const courseType = batchData.faculty ? `${batchData.faculty}` : (batchData.level || 'Hinglish');

  return `
    <div class="redesigned-card-inner" style="--accent-glow: ${color};">
      <!-- 1. Full-width Cover Thumbnail (100% occupancy, cover fit, clean) -->
      <div class="redesigned-card-thumbnail-box">
        <img src="${coverImageSrc}" class="redesigned-card-img" alt="${batchData.name} Cover" loading="lazy" />
      </div>

      <!-- 2. Content Box -->
      <div class="redesigned-card-content">
        <!-- Title and Share Row -->
        <div class="redesigned-card-title-row">
          <h3 class="redesigned-card-title" title="${batchData.name}">${batchData.name}</h3>
          <button class="redesigned-card-share-btn" onclick="event.stopPropagation(); window.shareBatchOnWhatsApp('${batchData.name.replace(/'/g, "\\'")}', '${batchData.subtitle ? batchData.subtitle.replace(/'/g, "\\'") : ''}', 'elite-batches.html?batch=${batchId}')" title="Share on WhatsApp">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="14" height="14"><path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L3 496l131-34.3c32.7 17.8 69.3 27.2 106.6 27.2 122.4 0 222-99.6 222-222 0-59.3-23.2-115-65.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-77.9 20.4 20.8-76-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
          </button>
        </div>

        <!-- Essential Metadata Row: Duration | Student Count | Course Type -->
        <div class="redesigned-card-metadata">
          <span class="metadata-pill duration" title="Duration"><span class="pill-icon">⏳</span> ${batchData.duration || 'Self-Paced'}</span>
          <span class="metadata-pill students" title="Students"><span class="pill-icon">👥</span> ${batchData.students || '100+'} Students</span>
          <span class="metadata-pill course-type" title="Course Type/Faculty"><span class="pill-icon">🌐</span> ${courseType}</span>
        </div>

        <!-- Hidden container for compatibility with real-time stats update if required -->
        <div id="stats-${batchId}" style="display:none;"></div>

        <!-- Action Section: Price and CTA -->
        <div class="redesigned-card-actions">
          <div class="redesigned-card-price-box">
            <span class="price-current ${priceDisplay === 'FREE' ? 'is-free' : ''}">${priceDisplay}</span>
            ${originalPriceDisplay ? `<span class="price-original">${originalPriceDisplay}</span>` : ''}
          </div>
          <div class="redesigned-card-cta-box">
            ${isEnrolled ? `
              <a href="elite-batches.html?batch=${batchId}" class="redesigned-card-btn study-btn" style="--btn-color: ${color}">
                <span>Study 🚀</span>
              </a>
            ` : `
              <button class="redesigned-card-btn enroll-btn" onclick="window.enrollInEliteBatch('${batchId}'); event.stopPropagation();" style="--btn-color: ${color}">
                <span>Enroll 💳</span>
              </button>
            `}
          </div>
        </div>
      </div>
    </div>
  `;
};

function generateEliteBatchCardHTML(batchId, batchData) {
  return window.generateUnifiedBatchCardHTML(batchId, batchData);
}

function injectCardStyles() {
  if (document.getElementById('unified-card-styles')) return;
  const style = document.createElement('style');
  style.id = 'unified-card-styles';
  style.textContent = `
    /* Container Override for Redesigned Card */
    .elite-batch-card {
      min-height: auto !important;
      height: 100% !important;
      border-radius: 16px !important;
      background: var(--bg-card, #ffffff) !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.05) !important;
      transition: transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), box-shadow 0.3s ease, border-color 0.3s ease !important;
      border: 1px solid rgba(139, 92, 246, 0.12) !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }

    [data-theme="dark"] .elite-batch-card {
      background: #0f172a !important;
      border-color: rgba(255,255,255,0.06) !important;
      box-shadow: 0 4px 30px rgba(0,0,0,0.3) !important;
    }

    .elite-batch-card:hover {
      transform: translateY(-6px) !important;
      box-shadow: 0 12px 30px rgba(139, 92, 246, 0.15) !important;
      border-color: var(--accent-glow) !important;
    }

    /* Redesigned Card Inner Structure */
    .redesigned-card-inner {
      display: flex;
      flex-direction: column;
      height: 100%;
      width: 100%;
    }

    /* 1. Thumbnail Container */
    .redesigned-card-thumbnail-box {
      width: 100%;
      aspect-ratio: 16 / 9;
      overflow: hidden;
      position: relative;
      background: #1e293b;
    }

    .redesigned-card-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s ease;
    }

    .elite-batch-card:hover .redesigned-card-img {
      transform: scale(1.06);
    }

    /* 2. Content Box */
    .redesigned-card-content {
      padding: 16px;
      display: flex;
      flex-direction: column;
      flex-grow: 1;
    }

    .redesigned-card-title-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }

    .redesigned-card-title {
      font-size: 1.05rem !important;
      font-weight: 850 !important;
      color: var(--text-primary) !important;
      margin: 0 !important;
      line-height: 1.35 !important;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      height: 2.7rem;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    [data-theme="dark"] .redesigned-card-title {
      color: #f8fafc !important;
    }

    .redesigned-card-share-btn {
      background: rgba(37, 211, 102, 0.1);
      border: 1px solid rgba(37, 211, 102, 0.2);
      color: #25d366;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      flex-shrink: 0;
      transition: all 0.2s ease;
      padding: 0;
    }

    .redesigned-card-share-btn:hover {
      background: #25d366;
      color: white;
      transform: scale(1.1);
    }

    .redesigned-card-share-btn svg {
      width: 14px;
      height: 14px;
    }

    /* 3. Metadata Row */
    .redesigned-card-metadata {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 16px;
      margin-top: auto;
    }

    .metadata-pill {
      font-size: 0.7rem;
      font-weight: 600;
      color: var(--text-muted, #64748b);
      background: rgba(139, 92, 246, 0.04);
      padding: 4px 8px;
      border-radius: 6px;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      white-space: nowrap;
    }

    [data-theme="dark"] .metadata-pill {
      background: rgba(255, 255, 255, 0.04);
      color: #94a3b8;
    }

    .pill-icon {
      font-size: 0.75rem;
    }

    /* 4. Actions Row */
    .redesigned-card-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-top: 1px solid rgba(139, 92, 246, 0.08);
      padding-top: 12px;
      margin-top: 4px;
    }

    .redesigned-card-price-box {
      display: flex;
      align-items: baseline;
      gap: 6px;
    }

    .price-current {
      font-size: 1.15rem;
      font-weight: 900;
      color: var(--text-primary);
    }

    .price-current.is-free {
      color: #10b981;
    }

    .price-original {
      font-size: 0.75rem;
      color: var(--text-muted);
      text-decoration: line-through;
    }

    .redesigned-card-cta-box {
      flex-shrink: 0;
    }

    .redesigned-card-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 0.78rem;
      font-weight: 800;
      border: none;
      cursor: pointer;
      transition: all 0.2s ease;
      text-decoration: none;
    }

    .redesigned-card-btn.enroll-btn {
      background: linear-gradient(135deg, var(--btn-color, #8b5cf6) 0%, rgba(139, 92, 246, 0.8) 100%);
      color: white;
      box-shadow: 0 4px 10px rgba(139, 92, 246, 0.15);
    }

    .redesigned-card-btn.study-btn {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: white;
      border: 1px solid rgba(255,255,255,0.08);
    }

    [data-theme="dark"] .redesigned-card-btn.study-btn {
      background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.08) 100%);
      color: white;
    }

    .redesigned-card-btn:hover {
      transform: translateY(-1.5px);
      filter: brightness(1.08);
    }
  `;
  document.head.appendChild(style);
}

function renderMyBatches() {
  const sec = document.getElementById('myBatchesSection');
  const grid = document.getElementById('myBatchesGrid');
  const countEl = document.getElementById('myBatchCount');
  if (!sec || !grid) return;

  const enrolledSems = lsGet('enrolledBatches', []);
  const enrolledElites = lsGet('enrolledEliteBatches', []);

  if (enrolledSems.length === 0 && enrolledElites.length === 0) {
    sec.style.display = 'none';
    const msg = document.getElementById('noBatchesMsg');
    if (msg) msg.style.display = 'block';
    if (countEl) countEl.style.display = 'none';
    return;
  }

  sec.style.display = 'block';
  const msg = document.getElementById('noBatchesMsg');
  if (msg) msg.style.display = 'none';
  if (countEl) countEl.style.display = 'inline-flex';

  const total = enrolledSems.length + enrolledElites.length;
  if (countEl) countEl.textContent = total + (total === 1 ? ' Batch' : ' Batches');

  grid.innerHTML = '';

  // Render enrolled Elite Plus batches
  enrolledElites.forEach(batchId => {
    const batchData = ELITE_BATCHES_STATIC[batchId];
    if (batchData) {
      const c = document.createElement('div');
      c.className = `elite-batch-card`;
      c.style.setProperty('--accent-glow', batchData.color);
      c.style.minHeight = 'auto'; // Fits nicely in my-batches grid
      c.innerHTML = generateEliteBatchCardHTML(batchId, batchData);
      grid.appendChild(c);
    }
  });

  // Render enrolled Semesters
  enrolledSems.forEach(k => {
    const semNum = k.replace('Semester', '');
    const c = document.createElement('div');
    c.className = `batch-card batch-card-${semNum}`;
    c.innerHTML = generateBatchCardHTML(k, true);
    grid.appendChild(c);
  });
}

window.currentHomeBatchCategory = 'semester';

window.switchHomeBatchCategory = function (category) {
  window.currentHomeBatchCategory = category;
  document.querySelectorAll('.switcher-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-category') === category);
  });
  if (typeof renderSemesterCards === 'function') {
    renderSemesterCards();
  }
};

window.showEnrollmentSuccessPopup = function (batchName) {
  let existing = document.getElementById('enrollment-success-popup');
  if (existing) existing.remove();

  const popup = document.createElement('div');
  popup.id = 'enrollment-success-popup';
  popup.style.cssText = `
    position: fixed;
    top: 24px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(15, 23, 42, 0.95);
    border: 1px solid rgba(139, 92, 246, 0.4);
    border-radius: 16px;
    padding: 16px 24px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), 0 0 20px rgba(139, 92, 246, 0.2);
    z-index: 100000;
    color: #fff;
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: 'Plus Jakarta Sans', sans-serif;
    font-weight: 700;
    font-size: 0.95rem;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s ease, top 0.3s ease;
  `;

  popup.innerHTML = `
    <span style="font-size: 1.5rem;">🎉</span>
    <div>
      <div style="color: #a78bfa; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 2px; font-weight: 800;">Congratulations</div>
      <div>Your batch <span style="color: #fbbf24;">${batchName}</span> is enrolled successfully!</div>
    </div>
  `;

  document.body.appendChild(popup);
  popup.offsetHeight;
  popup.style.opacity = '1';
  popup.style.top = '32px';

  setTimeout(() => {
    popup.style.opacity = '0';
    popup.style.top = '24px';
    setTimeout(() => {
      popup.remove();
    }, 300);
  }, 2000);
};

window.enrollInEliteBatch = function (batchId) {
  const isRegistered = localStorage.getItem('student_registered') === 'true';
  if (!isRegistered) {
    if (window.showRegistrationModal) {
      localStorage.setItem('pendingEliteEnrollment', batchId);
      window.showRegistrationModal(false, 'register');
    } else {
      alert("Please register or login first to enroll!");
    }
    return;
  }

  let enrolled = JSON.parse(localStorage.getItem('enrolledEliteBatches') || '[]');
  if (!enrolled.includes(batchId)) {
    enrolled.push(batchId);
    localStorage.setItem('enrolledEliteBatches', JSON.stringify(enrolled));

    const studentId = localStorage.getItem('student_id');
    if (studentId && typeof firebase !== 'undefined' && firebase.database) {
      firebase.database().ref(`students/${studentId}`).update({
        batchesEliteEnrolled: enrolled
      }).catch(err => console.error(err));
    }

    if (typeof window.syncVisitorData === 'function') {
      window.syncVisitorData();
    } else {
      const deviceId = localStorage.getItem('visitorId') || 'DEV_' + Date.now();
      if (deviceId && typeof firebase !== 'undefined' && firebase.database) {
        let semEnrolled = [];
        try {
          semEnrolled = JSON.parse(localStorage.getItem('enrolledBatches') || '[]');
        } catch (e) { }
        const allEnrolled = [...semEnrolled, ...enrolled];
        const name = localStorage.getItem('userName') || 'Student';
        firebase.database().ref(`visitors/${deviceId}`).update({
          name: name,
          enrolled: allEnrolled,
          lastActive: Date.now()
        });
      }
    }

    const batchName = ELITE_BATCHES_STATIC[batchId] ? ELITE_BATCHES_STATIC[batchId].name : 'Premium Batch';
    if (typeof window.showEnrollmentSuccessPopup === 'function') {
      window.showEnrollmentSuccessPopup(batchName);
    } else if (typeof showToast === 'function') {
      showToast(`🎉 Enrolled in ${batchName} successfully!`, 'success');
    }

    if (typeof renderSemesterCards === 'function') renderSemesterCards();
    if (typeof renderMyBatches === 'function') renderMyBatches();
  }
};

function renderHomeBatchHighlights(category) {
  const container = document.getElementById('batchHighlights');
  if (!container) return;

  if (category === 'semester') {
    container.innerHTML = '';
    container.style.display = 'none';
  } else if (category === 'elite' || category === 'placement') {
    container.style.display = 'none';
    container.innerHTML = '';
  }
}

function renderSemesterCards() {
  const g = document.getElementById('semesterGrid'); if (!g) return;
  g.innerHTML = '';

  const category = window.currentHomeBatchCategory || 'semester';
  renderHomeBatchHighlights(category);

  if (category === 'semester') {
    Object.keys(SUBJECTS).forEach((k, i) => {
      const n = i + 1;
      const enrolled = isEnrolled(k);
      const c = document.createElement('div');
      c.className = `batch-card batch-card-${n}`;
      c.style.animationDelay = (i * 45) + 'ms';
      c.innerHTML = generateBatchCardHTML(k, enrolled);
      g.appendChild(c);
    });
  } else {
    let cardIdx = 0;
    Object.keys(ELITE_BATCHES_STATIC).forEach(batchId => {
      const batchData = ELITE_BATCHES_STATIC[batchId];

      const isPlacement = batchId.includes('aptitude') || batchId.includes('prep') || batchId.includes('booster') || batchId.includes('linkedin') || batchId.includes('round');
      const targetCategory = isPlacement ? 'placement' : 'elite';

      if (targetCategory === category && batchData.isElitePlus !== true) {
        const c = document.createElement('div');
        c.className = `elite-batch-card`;
        c.style.setProperty('--accent-glow', batchData.color);
        c.style.animationDelay = (cardIdx * 45) + 'ms';
        cardIdx++;
        c.innerHTML = generateEliteBatchCardHTML(batchId, batchData);
        g.appendChild(c);
      }
    });
  }
}

function renderProgressGrid() {
  const g = document.getElementById('progressGrid'); if (!g) return;
  g.innerHTML = '';
  Object.keys(SUBJECTS).forEach((k, i) => {
    const p = getSemesterProgress(k);
    const done = lsGet('completed', {});
    const doneCount = SUBJECTS[k].filter(s => done[k + '_' + s.code]).length;
    const d = document.createElement('div');
    d.className = 'glass-card progress-card';
    d.innerHTML = `
      <div class="prog-square-header">
        <span class="prog-sem-num">${i + 1}</span>
        <div class="prog-info">
          <div class="prog-name">Semester ${i + 1}</div>
          <div class="prog-stats">${doneCount}/${SUBJECTS[k].length} Done</div>
        </div>
      </div>
      <div class="progress-bar-track">
        <div class="progress-bar-fill" style="width:${p}%"></div>
      </div>
      <div class="prog-footer">
        <span class="prog-percentage">${p}%</span>
        <button class="btn-sm" onclick="location.href='semester.html?sem=${i + 1}'">Study 🚀</button>
      </div>`;
    g.appendChild(d);
  });
}

function checkRevisionDue() {
  const revs = lsGet('revisions', []);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const due = revs.filter(r => new Date(r.nextDate) <= today);
  const sec = document.getElementById('revisionSection');
  const lst = document.getElementById('revisionList');
  if (due.length > 0 && sec && lst) {
    sec.style.display = 'block';
    lst.innerHTML = due.map(r => `<div class="revision-chip" onclick="location.href='subject.html?sem=${r.sem}&code=${r.code}&tab=${r.tab || 'notes'}'">🔁 ${r.subjectName} — ${r.title}</div>`).join('');
  }
}


function setFilter(type) { lsSet('quickFilter', type); }

function performGlobalSearch() {
  const q = document.getElementById('globalSearch')?.value.trim();
  if (!q) return;
  const results = [];
  Object.keys(SUBJECTS).forEach((k, i) => SUBJECTS[k].forEach(s => {
    if (s.name.toLowerCase().includes(q.toLowerCase()) || s.code.toLowerCase().includes(q.toLowerCase()))
      results.push({ sem: i + 1, semKey: k, subject: s });
  }));
  const sec = document.getElementById('searchResultsSection');
  const con = document.getElementById('searchResults');
  if (!sec || !con) return;
  sec.style.display = 'block';
  con.innerHTML = results.length === 0
    ? '<div class="empty-state"><div class="empty-icon">🔍</div><h3>No results found</h3><p>Try different keywords.</p></div>'
    : results.map(r => `<div class="subject-card glass-card" onclick="location.href='subject.html?sem=${r.sem}&code=${r.subject.code}'" style="cursor:pointer;"><div class="subject-code">${r.subject.code}</div><div class="subject-name">${r.subject.icon} ${highlightText(r.subject.name, q)}</div><div class="sem-sub-count" style="margin-top:6px;">Semester ${r.sem}</div></div>`).join('');
  sec.scrollIntoView({ behavior: 'smooth' });
}

function clearSearch() {
  const s = document.getElementById('searchResultsSection');
  const g = document.getElementById('globalSearch');
  if (s) s.style.display = 'none';
  if (g) g.value = '';
}

// ============================================================
// 8. PAGE: EXAM PATTERN
// ============================================================
function initExamPage() {
  initGlobalUI();
}

// ============================================================
// 9. PAGE: MY BATCHES
// ============================================================
function initMyBatchesPage() {
  initGlobalUI();
  renderMyBatches();

  // Check if grid is empty to show message
  setTimeout(() => {
    const grid = document.getElementById('myBatchesGrid');
    const msg = document.getElementById('noBatchesMsg');
    if (grid && grid.children.length === 0) {
      msg.style.display = 'block';
      const countPill = document.getElementById('myBatchCount');
      if (countPill) countPill.style.display = 'none';
    }
  }, 100);
}

// ============================================================
// 10. PAGE: ADMIN
// ============================================================
// Admin initialization is now consolidated at line 2023.

// ============================================================
// 11. PAGE: SEMESTER
// ============================================================
function initSemesterPage() {
  initGlobalUI();
  const semNum = parseInt(getParam('sem')) || 1;
  const semKey = 'Semester' + semNum;
  const el = id => document.getElementById(id);

  if (el('semNumber')) el('semNumber').textContent = semNum;
  if (el('semTitle')) {
    el('semTitle').innerHTML = `
      <div style="display: inline-flex; align-items: center; gap: 16px; flex-wrap: wrap;">
        <span>Semester <span class="gradient-text">${semNum}</span></span>
        <button onclick="window.shareBatchOnWhatsApp('Semester ${semNum}', 'Access all study materials, notes, PYQs and labs for Semester ${semNum}', 'semester.html?sem=${semNum}')" style="background: #25d366; color: white; border: none; border-radius: 20px; padding: 6px 14px; font-size: 0.8rem; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(37,211,102,0.3); transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" style="width: 14px; height: 14px; fill: white;"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L3 496l131-34.3c32.7 17.8 69.3 27.2 106.6 27.2 122.4 0 222-99.6 222-222 0-59.3-23.2-115-65.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-77.9 20.4 20.8-76-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
          <span>Share on WhatsApp</span>
        </button>
      </div>
    `;
  }
  if (el('semDesc')) el('semDesc').textContent = (SUBJECTS[semKey]?.length || 0) + ' subjects — Select one to access study materials';
  if (el('semBreadcrumb')) el('semBreadcrumb').textContent = 'Semester ' + semNum;
  document.title = 'Semester ' + semNum + ' | BCA STORE';

  const tabs = el('semTabs');
  if (tabs) tabs.innerHTML = [1, 2, 3, 4, 5, 6].map(n => `<button class="sem-tab${n === semNum ? ' active' : ''}" onclick="location.href='semester.html?sem=${n}'">Semester ${n}</button>`).join('');

  renderSubjectCards(semKey, semNum);
  updateSemesterProgress(semKey);
  trackView(semNum);
}

function renderSubjectCards(semKey, semNum, filter = '') {
  const g = document.getElementById('subjectsGrid'); if (!g) return;
  const subs = SUBJECTS[semKey] || [];
  const done = lsGet('completed', {});
  const bk = lsGet('bookmarks', {});
  const vis = lsGet('visits', {});
  const filtered = filter ? subs.filter(s => s.name.toLowerCase().includes(filter) || s.code.toLowerCase().includes(filter)) : subs;
  if (!filtered.length) { g.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><h3>No subjects found</h3></div>'; return; }
  g.innerHTML = filtered.map(s => {
    const key = semKey + '_' + s.code;
    const vc = vis[key] || 0;
    const hc = vc > 5 ? 'heat-high' : vc > 2 ? 'heat-medium' : 'heat-low';
    return `<div class="subject-card glass-card" onclick="goToSubject(${semNum},'${s.code}')" style="cursor:pointer;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div class="subject-code">${s.code}</div>
        <span class="heat-badge ${hc}" style="font-size:0.7rem;">${hc.replace('heat-', '')}</span>
      </div>
      <div class="subject-name">${s.icon} ${s.name}</div>
      <div class="subject-meta">
        ${done[key] ? '<span class="completed-badge">✅ Completed</span>' : ''}
        ${bk[key] ? '<span class="bookmarked-badge">🔖 Bookmarked</span>' : ''}
      </div>
    </div>`;
  }).join('');
}

function filterSubjects() {
  const q = document.getElementById('subjectSearch')?.value.toLowerCase().trim();
  const semNum = parseInt(getParam('sem')) || 1;
  renderSubjectCards('Semester' + semNum, semNum, q);
}

function goToSubject(semNum, code) {
  const k = 'Semester' + semNum + '_' + code;
  const v = lsGet('visits', {}); v[k] = (v[k] || 0) + 1; lsSet('visits', v);
  location.href = 'subject.html?sem=' + semNum + '&code=' + code;
}

function updateSemesterProgress(semKey) {
  const p = getSemesterProgress(semKey);
  const b = document.getElementById('semProgressBar');
  const t = document.getElementById('semProgressPct');
  if (b) b.style.width = p + '%';
  if (t) t.textContent = p + '%';
}

// ============================================================
// 9. SUBJECT PAGE - MAIN INIT
// ============================================================
let currentSemNum = 1, currentSemKey = 'Semester1', currentCode = '', currentSubject = null;


let allMaterials = { notes: [], pyq: [], video: [], pyq_solve: [], program: [] };
let currentTab = 'notes';
let ttsUtterance = null;

function initSubjectPage() {
  initGlobalUI();
  currentSemNum = parseInt(getParam('sem')) || 1;
  currentCode = getParam('code') || '';
  currentSemKey = 'Semester' + currentSemNum;
  currentSubject = SUBJECTS[currentSemKey]?.find(s => s.code === currentCode);

  if (!currentSubject) {
    const h = document.getElementById('subjectHeader');
    if (h) h.innerHTML = '<div class="container" style="padding-top:100px;"><h1 class="page-title" style="color:#fff;">Subject Not Found</h1><a href="index.html" class="btn-primary" style="display:inline-block;margin-top:16px;">Back to Home</a></div>';
    return;
  }

  document.title = currentSubject.name + ' | BCA STORE';
  const el = id => document.getElementById(id);
  if (el('subjectTitle')) el('subjectTitle').textContent = currentSubject.icon + ' ' + currentSubject.name;
  if (el('subjectCode')) el('subjectCode').textContent = currentCode + ' — Semester ' + currentSemNum;
  if (el('subjectBreadcrumb')) el('subjectBreadcrumb').textContent = currentCode;
  const sl = el('semLink');
  if (sl) { sl.textContent = 'Semester ' + currentSemNum; sl.href = 'semester.html?sem=' + currentSemNum; }

  updateBookmarkBtn();
  updateCompleteBtn();
  loadMaterials();
  initStudyTabs();
  loadAnnotations();
  restoreScrollPosition();
  window.addEventListener('beforeunload', saveScrollPosition);
  const tabParam = getParam('tab');
  if (tabParam) switchTab(tabParam);
  if (el('examModeBar')) el('examModeBar').style.display = 'none';
  trackView(currentSemNum);

  // ── ANALYTICS: page visit + mini strip ──
  if (typeof BCA_Analytics !== 'undefined') {
    BCA_Analytics.trackPageVisit('subject', currentSemKey + '_' + currentCode);
    _injectAnalyticsMiniStrip();
  }
}

function _injectAnalyticsMiniStrip() {
  const tabBar = document.getElementById('multiTabBar');
  if (!tabBar || document.getElementById('anaMiniStrip')) return;
  const data = BCA_Analytics.getData();
  const key = currentSemKey + '_' + currentCode;
  const stat = data.subjectStats[key] || {};
  const todayXP = stat.xp || 0;
  const strip = document.createElement('div');
  strip.className = 'container'; strip.id = 'anaMiniStrip';
  strip.innerHTML = `
    <div class="ana-mini-strip">
      <div class="ana-mini-chip">📘 Notes: <span id="miniNoteCount">${stat.notesOpened || 0}</span></div>
      <div class="ana-mini-chip">🎥 Videos: <span id="miniVidCount">${stat.videosWatched || 0}</span></div>
      <div class="ana-mini-chip">⚡ XP: <span id="miniXpCount">${todayXP}</span></div>
      <div class="ana-mini-chip">🔥 Streak: <span>${data.streakDays || 0} days</span></div>
      <a href="analytics.html" class="ana-mini-strip-link">📊 Full Stats →</a>
    </div>`;
  tabBar.after(strip);
}

function loadMaterials() {
  const spinner = document.getElementById('loadingSpinner');
  if (spinner) spinner.style.display = 'block';
  allMaterials = { notes: [], pyq: [], video: [], pyq_solve: [], program: [] };

  const done = () => { if (spinner) spinner.style.display = 'none'; mergeLSMaterials(); renderCurrentTab(); };

  if (db) {
    try {
      firebase.database().ref('materials/' + currentSemKey + '/' + currentCode).on('value', snap => {
        allMaterials = { notes: [], pyq: [], video: [], pyq_solve: [], program: [] };
        if (snap.exists()) snap.forEach(child => {
          const item = { id: child.key, ...child.val() };
          if (item.type === 'lab') item.type = 'pyq_solve';
          const type = item.type || 'notes';
          if (!allMaterials[type]) allMaterials[type] = [];
          allMaterials[type].push(item);
        });
        done();
      }, (error) => {
        console.error("Firebase read error:", error);
        loadLSMaterials();
      });
    } catch (e) { loadLSMaterials(); }
  } else { loadLSMaterials(); }
}

function loadLSMaterials() {
  allMaterials = { notes: [], pyq: [], video: [], pyq_solve: [], program: [] };
  mergeLSMaterials();
  const spinner = document.getElementById('loadingSpinner');
  if (spinner) spinner.style.display = 'none';
  renderCurrentTab();
}

function mergeLSMaterials() {
  const key = 'materials_' + currentSemKey + '_' + currentCode;
  const stored = lsGet(key, {});
  Object.values(stored).forEach(item => {
    const type = item.type || 'notes';
    if (!allMaterials[type]) allMaterials[type] = [];
    if (!allMaterials[type].find(m => m.id === item.id)) allMaterials[type].push(item);
  });
}

function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.content-tab').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
  document.querySelectorAll('.tab-content').forEach(div => div.classList.remove('active'));
  const active = document.getElementById('tab-' + tab);
  if (active) active.classList.add('active');
  renderCurrentTab();
}

function renderCurrentTab() {
  const kw = document.getElementById('materialSearch')?.value.trim() || '';
  const items = (allMaterials[currentTab] || []).filter(m =>
    !kw || m.title?.toLowerCase().includes(kw.toLowerCase()) || m.description?.toLowerCase().includes(kw.toLowerCase())
  );
  if (currentTab === 'video') renderVideoMaterials(items, kw);
  else renderMaterialCards(items, currentTab, kw);
}

function renderMaterialCards(items, type, kw = '') {
  const grid = document.getElementById(type + 'Materials');
  const empty = document.getElementById(type + 'Empty');
  if (!grid) return;
  if (!items.length) { grid.innerHTML = ''; if (empty) empty.style.display = 'block'; return; }
  if (empty) empty.style.display = 'none';
  grid.innerHTML = items.map(item => {
    const isImg = isImage(item.link);
    const sl = (item.link || '').replace(/'/g, "\\'");
    const st = (item.title || 'Untitled').replace(/'/g, "\\'");

    // Determine badges
    const ageDays = (Date.now() - (item.timestamp || Date.now())) / (1000 * 60 * 60 * 24);
    const isNew = ageDays < 7;
    const isImp = (item.title || '').toLowerCase().includes('important') || (item.title || '').toLowerCase().includes('vvi');
    let badgeHtml = isNew ? '<span class="pdf-badge new-badge">New</span>' : '';
    if (isImp && !isNew) badgeHtml = '<span class="pdf-badge imp-badge">Important</span>';

    return `<div class="pdf-note-card premium-glass">
      <div class="pdf-preview-area">
        <div class="pdf-icon-wrapper">
             <span class="doc-icon">${isImg ? '🖼️' : '📄'}</span>
        </div>
        <div class="pdf-badges-top">
            ${badgeHtml}
            <span class="pdf-badge type-badge">${typeBadge(item.type || type)}</span>
        </div>
      </div>
      <div class="pdf-info-area">
          <h3 class="pdf-title" title="${st}">${highlightText(item.title || 'Untitled', kw)}</h3>
          <p class="pdf-desc">${highlightText(item.description || 'Premium study material', kw)}</p>
          <div class="pdf-meta">
               <span class="meta-item"><span class="meta-icon">📅</span> ${formatDate(item.timestamp)}</span>
               <span class="meta-item"><span class="meta-icon">📦</span> ${isImg ? '~1 MB' : '~3 MB'}</span>
          </div>
          <div class="pdf-actions">
             ${isImg
        ? `<button class="action-btn view-btn" onclick="trackInteraction('${item.type || type}'); openImageViewer('${sl}','${st}')">👁️ View Image</button>`
        : `<a href="${item.link || '#'}" target="_blank" rel="noopener noreferrer" class="action-btn view-btn" onclick="trackInteraction('${item.type || type}')">👁️ Read PDF</a>`
      }
             <div class="pdf-icon-actions">
               <button class="action-btn icon-btn" onclick="bookmarkMaterial('${item.id || ''}','${st}')" title="Bookmark">🔖</button>
               <button class="action-btn icon-btn ${isMatDone(item.id) ? 'done' : ''}" onclick="markItemComplete('${item.id || ''}','${st}','${item.type || type}')" title="Mark as Done">
                  ${isMatDone(item.id) ? '✅' : '✔️'}
               </button>
             </div>
          </div>
      </div>
    </div>`;
  }).join('');
  addDefinitionListeners(grid);
}



function renderVideoMaterials(items, kw = '') {
  const grid = document.getElementById('videoMaterials');
  const empty = document.getElementById('videoEmpty');
  if (!grid) return;
  if (!items.length) { grid.innerHTML = ''; if (empty) empty.style.display = 'block'; return; }
  if (empty) empty.style.display = 'none';
  grid.innerHTML = items.map(item => {
    const embed = getYouTubeEmbed(item.link);
    const sl = (item.link || '').replace(/'/g, "\\'");
    const st = (item.title || '').replace(/'/g, "\\'");
    const isDirectVideo = isVideo(item.link);

    // Premium Video Card
    return `<div class="video-card">
      <div class="video-thumb-container" onclick="openVideoPlayer('${sl}','${st}')">
        <img src="${getYouTubeThumb(item.link)}" class="video-thumb" alt="${item.title}" onerror="this.src='https://via.placeholder.com/480x270?text=Video+Lecture'" loading="lazy">
        <div class="play-overlay">
          <div class="video-badge-overlay">${isDirectVideo ? 'DIRECT' : 'VIDEO'}</div>
          <span class="play-icon">▶</span>
        </div>
      </div>
      <div class="video-info">
        <div class="video-title">${highlightText(item.title || 'Untitled', kw)}</div>
        <div class="video-desc">${highlightText(item.description || '', kw)}</div>
        <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;">
          <button class="btn-primary btn-sm" onclick="trackInteraction('video'); openVideoPlayer('${sl}','${st}')">📺 Watch Now</button>
          <button class="btn-outline btn-sm" onclick="copyToClipboard('${sl}')">📋 Copy</button>
          <button class="btn-outline btn-sm ${isMatDone(item.id) ? 'active' : ''}" onclick="markItemComplete('${item.id || ''}','${st}','video')">
            ${isMatDone(item.id) ? '✅ Done' : '✔️ Mark Done'}
          </button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function filterMaterials() { renderCurrentTab(); }
function clearMaterialSearch() { const el = document.getElementById('materialSearch'); if (el) el.value = ''; renderCurrentTab(); }

function toggleBookmark() {
  const key = currentSemKey + '_' + currentCode;
  const bk = lsGet('bookmarks', {}); bk[key] = !bk[key]; lsSet('bookmarks', bk);
  // Also store in rich bookmarks
  const v2 = lsGet('bookmarks_v2', []);
  const existing = v2.findIndex(b => b.key === key);
  if (bk[key]) {
    if (existing === -1) {
      v2.push({
        key, type: 'subject', title: currentSubject?.name || currentCode,
        icon: currentSubject?.icon || '📖', code: currentCode,
        sem: currentSemNum, semKey: currentSemKey,
        link: 'subject.html?sem=' + currentSemNum + '&code=' + currentCode,
        timestamp: Date.now()
      });
    }
  } else {
    if (existing > -1) v2.splice(existing, 1);
  }
  lsSet('bookmarks_v2', v2);
  updateBookmarkBtn(); updateBkNavBadge();
  showToast(bk[key] ? '🔖 Bookmarked!' : '🔖 Removed', 'info');
}
function updateBookmarkBtn() {
  const key = currentSemKey + '_' + currentCode;
  const btn = document.getElementById('bookmarkBtn');
  if (btn) btn.textContent = lsGet('bookmarks', {})[key] ? '🔖 Bookmarked' : '🔖 Bookmark';
}
function markSubjectComplete() {
  const key = currentSemKey + '_' + currentCode;
  const done = lsGet('completed', {}); done[key] = !done[key]; lsSet('completed', done);
  if (done[key]) scheduleRevision(currentSemNum, currentCode, currentSubject.name, 'Subject completed', 'notes');
  updateCompleteBtn();
  showToast(done[key] ? '✅ Marked complete! Revisions scheduled.' : '↩️ Marked incomplete', done[key] ? 'success' : 'info');
  // ── ANALYTICS hook ──
  if (typeof BCA_Analytics !== 'undefined') {
    if (done[key]) BCA_Analytics.trackSubjectComplete(currentSemKey, currentCode, currentSubject?.name || currentCode);
    else BCA_Analytics.trackSubjectIncomplete(currentSemKey, currentCode);
  }
}
function updateCompleteBtn() {
  const key = currentSemKey + '_' + currentCode;
  const btn = document.getElementById('completeBtn');
  if (btn) btn.textContent = lsGet('completed', {})[key] ? '↩️ Mark Incomplete' : '✅ Mark Complete';
}
function bookmarkMaterial(id, title) {
  const key = 'mat_' + id; const bk = lsGet('bookmarks', {}); bk[key] = !bk[key]; lsSet('bookmarks', bk);
  // Rich bookmark v2
  const v2 = lsGet('bookmarks_v2', []);
  const existing = v2.findIndex(b => b.key === key);
  // Find the material to get its link and type
  let matType = currentTab || 'notes';
  let matLink = '';
  Object.values(allMaterials).forEach(arr => {
    const found = arr.find(m => m.id === id);
    if (found) { matType = found.type || matType; matLink = found.link || ''; }
  });
  if (bk[key]) {
    if (existing === -1) {
      v2.push({
        key, type: matType, title: title || 'Untitled',
        icon: matType === 'notes' ? '📝' : matType === 'pyq' ? '📄' : matType === 'video' ? '🎥' : matType === 'program' ? '⌨️' : matType === 'pyq_solve' ? '📜' : '📎',
        code: currentCode, sem: currentSemNum, semKey: currentSemKey,
        subjectName: currentSubject?.name || currentCode,
        link: matLink, timestamp: Date.now()
      });
    }
  } else {
    if (existing > -1) v2.splice(existing, 1);
  }
  lsSet('bookmarks_v2', v2); updateBkNavBadge();
  showToast(bk[key] ? '🔖 Bookmarked!' : '🔖 Removed', 'info');
}

// ============================================================
// BOOKMARKS PANEL SYSTEM
// ============================================================
let bkPanelTab = 'all';

function injectBookmarksPanel() {
  if (document.getElementById('bkPanel')) return;
  const html = `
    <div class="bk-panel-overlay" id="bkPanelOverlay"></div>
    <div class="bk-panel" id="bkPanel">
      <div class="bk-panel-header">
        <div class="bk-panel-title">
          <div class="bk-icon-wrap">🔖</div>
          <h3>My Bookmarks</h3>
        </div>
        <button class="bk-panel-close" onclick="closeBkPanel()" title="Close">✕</button>
      </div>
      <div class="bk-stats-bar" id="bkStatsBar">
        <div class="bk-stat-chip"><span class="bk-stat-num" id="bkStatTotal">0</span><span class="bk-stat-label">Total</span></div>
        <div class="bk-stat-chip"><span class="bk-stat-num" id="bkStatSubjects">0</span><span class="bk-stat-label">Subjects</span></div>
        <div class="bk-stat-chip"><span class="bk-stat-num" id="bkStatMaterials">0</span><span class="bk-stat-label">Materials</span></div>
      </div>
      <div class="bk-tabs" id="bkTabs">
        <button class="bk-tab active" data-filter="all" onclick="switchBkTab('all')">📌 All</button>
        <button class="bk-tab" data-filter="subject" onclick="switchBkTab('subject')">📖 Subjects</button>
        <button class="bk-tab" data-filter="notes" onclick="switchBkTab('notes')">📝 Notes</button>
        <button class="bk-tab" data-filter="video" onclick="switchBkTab('video')">🎥 Videos</button>
        <button class="bk-tab" data-filter="other" onclick="switchBkTab('other')">📎 Other</button>
      </div>
      <div class="bk-content" id="bkContent"></div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', html);
  document.getElementById('bkPanelOverlay').addEventListener('click', closeBkPanel);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeBkPanel(); });
}

function openBkPanel() {
  injectBookmarksPanel();
  document.getElementById('bkPanel')?.classList.add('active');
  document.getElementById('bkPanelOverlay')?.classList.add('active');
  document.body.classList.add('drawer-open');
  bkPanelTab = 'all';
  renderBkPanel();
}

function closeBkPanel() {
  document.getElementById('bkPanel')?.classList.remove('active');
  document.getElementById('bkPanelOverlay')?.classList.remove('active');
  document.body.classList.remove('drawer-open');
}

function switchBkTab(tab) {
  bkPanelTab = tab;
  document.querySelectorAll('.bk-tab').forEach(t => t.classList.toggle('active', t.dataset.filter === tab));
  renderBkContent();
}

function renderBkPanel() {
  const v2 = lsGet('bookmarks_v2', []);
  const subjects = v2.filter(b => b.type === 'subject');
  const materials = v2.filter(b => b.type !== 'subject');
  const totalEl = document.getElementById('bkStatTotal');
  const subEl = document.getElementById('bkStatSubjects');
  const matEl = document.getElementById('bkStatMaterials');
  if (totalEl) totalEl.textContent = v2.length;
  if (subEl) subEl.textContent = subjects.length;
  if (matEl) matEl.textContent = materials.length;
  // Update tabs active
  document.querySelectorAll('.bk-tab').forEach(t => t.classList.toggle('active', t.dataset.filter === bkPanelTab));
  renderBkContent();
}

function renderBkContent() {
  const container = document.getElementById('bkContent');
  if (!container) return;
  const v2 = lsGet('bookmarks_v2', []);
  let filtered = v2;
  if (bkPanelTab === 'subject') filtered = v2.filter(b => b.type === 'subject');
  else if (bkPanelTab === 'notes') filtered = v2.filter(b => b.type === 'notes');
  else if (bkPanelTab === 'video') filtered = v2.filter(b => b.type === 'video');
  else if (bkPanelTab === 'other') filtered = v2.filter(b => !['subject', 'notes', 'video'].includes(b.type));

  // Sort by timestamp desc
  filtered = filtered.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  if (!filtered.length) {
    container.innerHTML = `
      <div class="bk-empty">
        <span class="bk-empty-icon">🔖</span>
        <h4>No Bookmarks Yet</h4>
        <p>Bookmark subjects and materials while studying to find them quickly here!</p>
      </div>
    `;
    return;
  }

  const typeIcons = { subject: '📖', notes: '📝', pyq: '📄', video: '🎥', program: '⌨️', pyq_solve: '📜' };
  const typeLabels = { subject: 'Subject', notes: 'Notes', pyq: 'PYQ', video: 'Video', program: 'Program', pyq_solve: 'PYQ Solve' };

  let html = filtered.map((bk, i) => {
    const timeAgo = getTimeAgo(bk.timestamp);
    const badge = bk.type || 'subject';
    return `<div class="bk-card bk-type-${badge}" style="animation-delay: ${i * 0.05}s" onclick="navigateBookmark('${encodeURIComponent(JSON.stringify({ link: bk.link, type: bk.type }))}')" title="Click to open">
      <div class="bk-card-header">
        <div class="bk-card-info">
          <div class="bk-card-title">${bk.icon || typeIcons[badge] || '📎'} ${bk.title || 'Untitled'}</div>
          <div class="bk-card-sub">
            <span class="bk-card-type-badge bk-badge-${badge}">${typeLabels[badge] || badge}</span>
            ${bk.code ? `<span>• ${bk.code}</span>` : ''}
            ${bk.sem ? `<span>• Sem ${bk.sem}</span>` : ''}
            <span>• ${timeAgo}</span>
          </div>
        </div>
        <div class="bk-card-actions">
          ${bk.link ? `<button class="bk-action-btn bk-open-btn" onclick="event.stopPropagation(); window.open('${bk.link}', '_blank')" title="Open">🔗</button>` : ''}
          <button class="bk-action-btn" onclick="event.stopPropagation(); removeSingleBookmark('${bk.key}')" title="Remove">🗑️</button>
        </div>
      </div>
      ${bk.subjectName && bk.type !== 'subject' ? `<div class="bk-card-sub" style="margin-top:4px; font-size:0.72rem; opacity:0.7;">📚 ${bk.subjectName}</div>` : ''}
    </div>`;
  }).join('');

  html += `<button class="bk-clear-all-btn" onclick="clearAllBookmarks()">🗑️ Clear All Bookmarks</button>`;
  container.innerHTML = html;
}

function getTimeAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  const days = Math.floor(hrs / 24);
  if (days < 30) return days + 'd ago';
  return Math.floor(days / 30) + 'mo ago';
}

function navigateBookmark(encoded) {
  try {
    const data = JSON.parse(decodeURIComponent(encoded));
    if (data.link) {
      if (data.type === 'subject' || data.link.startsWith('subject.html') || data.link.startsWith('semester.html')) {
        window.location.href = data.link;
      } else {
        window.open(data.link, '_blank');
      }
    }
  } catch (e) { console.warn('Navigate bookmark error:', e); }
}

function removeSingleBookmark(key) {
  // Remove from v2
  const v2 = lsGet('bookmarks_v2', []);
  const idx = v2.findIndex(b => b.key === key);
  if (idx > -1) v2.splice(idx, 1);
  lsSet('bookmarks_v2', v2);
  // Remove from old bookmarks too
  const bk = lsGet('bookmarks', {});
  if (bk[key]) { delete bk[key]; lsSet('bookmarks', bk); }
  renderBkPanel(); updateBkNavBadge();
  showToast('🗑️ Bookmark removed', 'info');
}

function clearAllBookmarks() {
  if (!confirm('Remove all bookmarks? This cannot be undone.')) return;
  lsSet('bookmarks_v2', []);
  lsSet('bookmarks', {});
  renderBkPanel(); updateBkNavBadge();
  showToast('🗑️ All bookmarks cleared', 'info');
}

function updateBkNavBadge() {
  const v2 = lsGet('bookmarks_v2', []);
  const count = v2.length;
  document.querySelectorAll('.bk-count-badge').forEach(el => {
    el.textContent = count > 0 ? (count > 99 ? '99+' : count) : '';
    el.setAttribute('data-count', count);
  });
}
function markItemComplete(id, title, type) {
  if (!id) return;
  const key = currentSemKey + '_' + currentCode + '_' + id;
  const done = lsGet('mat_completed', {});
  done[key] = !done[key];
  lsSet('mat_completed', done);

  if (done[key]) {
    scheduleRevision(currentSemNum, currentCode, currentSubject?.name || currentCode, title, type);
    showToast('✅ ' + title + ' complete! Revisions scheduled.', 'success');
    // ── ANALYTICS hook ──
    if (typeof BCA_Analytics !== 'undefined') {
      BCA_Analytics.trackMaterialClick(type || 'notes', currentSemKey, currentCode);
    }
  } else {
    showToast('↩️ ' + title + ' marked incomplete', 'info');
  }
  renderCurrentTab();

  // Auto-check if all materials are done to suggest marking subject complete
  checkSubjectAutoCompletion();
}

// Called by existing card onclick="trackInteraction('type')"
function trackInteraction(type) {
  if (typeof BCA_Analytics === 'undefined') return;
  BCA_Analytics.trackMaterialClick(type, currentSemKey || '', currentCode || '');
  // Update mini strip counters live
  const data = BCA_Analytics.getData();
  const key = (currentSemKey || '') + '_' + (currentCode || '');
  const stat = data.subjectStats[key] || {};
  const nc = document.getElementById('miniNoteCount');
  const vc = document.getElementById('miniVidCount');
  const xc = document.getElementById('miniXpCount');
  if (nc) nc.textContent = stat.notesOpened || 0;
  if (vc) vc.textContent = stat.videosWatched || 0;
  if (xc) xc.textContent = stat.xp || 0;
}

function checkSubjectAutoCompletion() {
  const keyPrefix = currentSemKey + '_' + currentCode + '_';
  const doneMats = lsGet('mat_completed', {});
  const doneCount = Object.keys(doneMats).filter(k => k.startsWith(keyPrefix) && doneMats[k]).length;

  // If user has done 3+ materials, encourage marking subject complete
  if (doneCount >= 3) {
    const subKey = currentSemKey + '_' + currentCode;
    const subDone = lsGet('completed', {});
    if (!subDone[subKey]) {
      // Potentially show a subtle hint
    }
  }
}

function scheduleRevision(semNum, code, subjectName, title, tab = 'notes') {
  const revs = lsGet('revisions', []);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  [1, 3, 7].forEach(days => {
    const d = new Date(today); d.setDate(d.getDate() + days);
    revs.push({ id: genId(), sem: semNum, semKey: 'Semester' + semNum, code, subjectName, title, tab, nextDate: d.toISOString(), done: false });
  });
  lsSet('revisions', revs);
}

function ttsPlay() {
  const items = allMaterials[currentTab] || [];
  if (!items.length) { showToast('No content to read.', 'error'); return; }
  if (!('speechSynthesis' in window)) { showToast('TTS not supported.', 'error'); return; }
  window.speechSynthesis.cancel();
  ttsUtterance = new SpeechSynthesisUtterance(items.map(m => (m.title || '') + '. ' + (m.description || '')).join('. '));
  ttsUtterance.lang = 'en-IN'; ttsUtterance.rate = 0.9;
  ttsUtterance.onstart = () => {
    const g = id => document.getElementById(id);
    if (g('ttsPlayBtn')) g('ttsPlayBtn').style.display = 'none';
    if (g('ttsPauseBtn')) g('ttsPauseBtn').style.display = 'inline';
    if (g('ttsStopBtn')) g('ttsStopBtn').style.display = 'inline';
    if (g('ttsStatus')) g('ttsStatus').textContent = '🔊 Reading...';
  };
  ttsUtterance.onend = ttsStop; ttsUtterance.onerror = ttsStop;
  window.speechSynthesis.speak(ttsUtterance);
}
function ttsPause() {
  if (!('speechSynthesis' in window)) return;
  const s = document.getElementById('ttsStatus');
  if (window.speechSynthesis.paused) { window.speechSynthesis.resume(); if (s) s.textContent = '🔊 Reading...'; }
  else { window.speechSynthesis.pause(); if (s) s.textContent = '⏸ Paused'; }
}
function ttsStop() {
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  const g = id => document.getElementById(id);
  if (g('ttsPlayBtn')) g('ttsPlayBtn').style.display = 'inline';
  if (g('ttsPauseBtn')) g('ttsPauseBtn').style.display = 'none';
  if (g('ttsStopBtn')) g('ttsStopBtn').style.display = 'none';
  if (g('ttsStatus')) g('ttsStatus').textContent = '';
}

function toggleExamMode() {
  document.body.classList.toggle('exam-mode');
  const bar = document.getElementById('examModeBar');
  const on = document.body.classList.contains('exam-mode');
  if (bar) bar.style.display = on ? 'block' : 'none';
  showToast(on ? '🎯 Exam Mode ON' : '🎯 Exam Mode OFF', 'info');
}

let studyTabs = [];
function initStudyTabs() {
  studyTabs = lsGet('studyTabs', []);
  const cur = { code: currentCode, name: currentSubject?.name || currentCode, sem: currentSemNum };
  if (!studyTabs.find(t => t.code === currentCode)) {
    studyTabs.push(cur); if (studyTabs.length > 6) studyTabs.shift(); lsSet('studyTabs', studyTabs);
  }
  renderStudyTabs();
}
function renderStudyTabs() {
  const lst = document.getElementById('openTabsList'); if (!lst) return;
  lst.innerHTML = studyTabs.map(t => `<span class="study-tab-chip${t.code === currentCode ? ' active' : ''}" onclick="location.href='subject.html?sem=${t.sem}&code=${t.code}'">${t.code} <span class="close-tab" onclick="event.stopPropagation();removeStudyTab('${t.code}')">✕</span></span>`).join('');
}
function addStudyTab() { location.href = 'semester.html?sem=' + currentSemNum; }
function removeStudyTab(code) {
  studyTabs = studyTabs.filter(t => t.code !== code); lsSet('studyTabs', studyTabs);
  if (code === currentCode && studyTabs.length > 0) location.href = 'subject.html?sem=' + studyTabs[0].sem + '&code=' + studyTabs[0].code;
  else renderStudyTabs();
}

function loadAnnotations() {
  const key = 'ann_' + currentSemKey + '_' + currentCode;
  const anns = lsGet(key, []);
  const c = document.getElementById('savedAnnotations'); if (!c) return;
  c.innerHTML = anns.length === 0 ? '<p style="font-size:0.82rem;color:var(--text-muted);padding:10px 14px;">No annotations yet.</p>'
    : anns.map(a => `<div class="annotation-item"><div class="ann-text">${a.text}</div><div class="ann-date">${formatDate(a.date)}</div></div>`).join('');
}
function openAnnotation() { const p = document.getElementById('annotationPanel'); if (p) p.style.display = p.style.display === 'block' ? 'none' : 'block'; }
function closeAnnotation() { const p = document.getElementById('annotationPanel'); if (p) p.style.display = 'none'; }
function saveAnnotation() {
  const txt = document.getElementById('annotationText')?.value.trim(); if (!txt) return;
  const key = 'ann_' + currentSemKey + '_' + currentCode;
  const anns = lsGet(key, []); anns.unshift({ id: genId(), text: txt, date: Date.now() }); lsSet(key, anns);
  document.getElementById('annotationText').value = ''; loadAnnotations(); showToast('✏️ Saved!', 'success');
}

let imgZoom = 1;
function openImageViewer(url, title) {
  imgZoom = 1;
  const img = document.getElementById('viewerImg');
  if (img) { img.src = url; img.style.transform = 'scale(1)'; }
  const ttl = document.getElementById('imageViewerTitle'); if (ttl) ttl.textContent = title || 'Image';
  document.getElementById('imageViewerModal')?.classList.add('active');
}
function closeImageViewer() { document.getElementById('imageViewerModal')?.classList.remove('active'); }
function zoomImage(delta) { imgZoom = Math.max(0.2, Math.min(4, imgZoom + delta)); const img = document.getElementById('viewerImg'); if (img) img.style.transform = 'scale(' + imgZoom + ')'; }



function showRandomQuestion() {
  const pyqs = (allMaterials.pyq || []).map(m => ({ q: m.title, a: m.description || 'See linked material.' }));
  const pool = [...SAMPLE_QUESTIONS, ...pyqs];
  if (!pool.length) { showToast('No questions available.', 'error'); return; }
  const q = pool[Math.floor(Math.random() * pool.length)];
  const body = document.getElementById('randomQBody');
  if (body) body.innerHTML = `<div class="challenge-q">${q.q}</div><details style="margin-top:14px;padding:14px;background:rgba(79,70,229,0.07);border-radius:var(--radius-sm);"><summary style="cursor:pointer;font-weight:600;color:var(--primary);">💡 Reveal Answer</summary><p style="margin-top:10px;">${q.a}</p></details>`;
  document.getElementById('randomQModal')?.classList.add('active');
}

function copyToClipboard(text) {
  if (!text) { showToast('Nothing to copy.', 'error'); return; }
  const fb = () => { const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.focus(); ta.select(); try { document.execCommand('copy'); showToast('📋 Copied!', 'success'); } catch { showToast('Copy failed.', 'error'); } document.body.removeChild(ta); };
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(() => showToast('📋 Copied!', 'success')).catch(fb);
  else fb();
}

function addDefinitionListeners(container) {
  const popup = document.getElementById('definitionPopup'); if (!popup) return;
  container.addEventListener('mouseup', e => {
    const sel = window.getSelection()?.toString().trim().toLowerCase();
    if (sel && sel.length > 2 && sel.length < 20 && DEFINITIONS[sel]) {
      popup.innerHTML = '<strong>' + sel.charAt(0).toUpperCase() + sel.slice(1) + '</strong>' + DEFINITIONS[sel];
      popup.style.left = Math.min(e.pageX, window.innerWidth - 300) + 'px';
      popup.style.top = (e.pageY + 14) + 'px'; popup.style.display = 'block';
    } else popup.style.display = 'none';
  });
  document.addEventListener('mousedown', e => { if (!e.target.closest('#definitionPopup')) popup.style.display = 'none'; });
}

function printNotes() { window.print(); }

// ============================================================
// ============================================================
// 25. EXPORT / IMPORT
// ============================================================
function exportData() {
  const data = { completed: lsGet('completed', {}), bookmarks: lsGet('bookmarks', {}), bookmarks_v2: lsGet('bookmarks_v2', []), revisions: lsGet('revisions', []), suggestions: lsGet('suggestions', []), annotations: {}, visits: lsGet('visits', {}), exportDate: new Date().toISOString() };
  Object.keys(SUBJECTS).forEach(sk => SUBJECTS[sk].forEach(s => { const k = 'ann_' + sk + '_' + s.code; const a = lsGet(k, []); if (a.length > 0) data.annotations[k] = a; }));
  const b = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = 'bca-store-data.json'; a.click(); URL.revokeObjectURL(u);
  showToast('📥 Data exported!', 'success');
}
function importData(event) {
  const f = event.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = e => {
    try {
      const d = JSON.parse(e.target.result);
      if (d.completed) lsSet('completed', d.completed); if (d.bookmarks) lsSet('bookmarks', d.bookmarks);
      if (d.bookmarks_v2) lsSet('bookmarks_v2', d.bookmarks_v2);
      if (d.revisions) lsSet('revisions', d.revisions); if (d.suggestions) lsSet('suggestions', d.suggestions);
      if (d.visits) lsSet('visits', d.visits);
      if (d.annotations) Object.keys(d.annotations).forEach(k => lsSet(k, d.annotations[k]));
      showToast('📤 Imported!', 'success'); setTimeout(() => location.reload(), 1500);
    } catch { showToast('❌ Invalid file.', 'error'); }
  }; r.readAsText(f);
}

// ============================================================
// 26. MINI CHALLENGE (REVAMPED)
// ============================================================
const CHALLENGE_BANK = {
  "GENERAL": [
    // Day 0 (Sunday)
    [
      { q: "What is the brain of the computer?", o: ["CPU", "RAM", "HDD", "GPU"], a: 0 },
      { q: "Which of these is an input device?", o: ["Monitor", "Printer", "Keyboard", "Speaker"], a: 2 },
      { q: "1 Byte is equal to how many bits?", o: ["4 bits", "8 bits", "16 bits", "32 bits"], a: 1 },
      { q: "What does HTTP stand for?", o: ["Hyper Text Transfer Protocol", "High Tech Transfer Process", "Hyper Terminal Transfer Protocol", "None"], a: 0 },
      { q: "Which language is used for web styling?", o: ["HTML", "Java", "PHP", "CSS"], a: 3 }
    ],
    // Day 1 (Monday)
    [
      { q: "Who is the father of C language?", o: ["James Gosling", "Dennis Ritchie", "Bjarne Stroustrup", "Guido van Rossum"], a: 1 },
      { q: "Which of these is volatile memory?", o: ["ROM", "HDD", "RAM", "SSD"], a: 2 },
      { q: "What is the full form of RAM?", o: ["Read Access Memory", "Random Access Memory", "Ready Auto Memory", "None"], a: 1 },
      { q: "Which is the smallest unit of data?", o: ["Bit", "Byte", "KB", "Nibble"], a: 0 },
      { q: "What is Linux?", o: ["Hardware", "Operating System", "Compiler", "Editor"], a: 1 }
    ],
    // Day 2 (Tuesday)
    [
      { q: "What does HTML stand for?", o: ["Hyper Tool Markup Language", "Hyper Text Markup Language", "High Text Machine Language", "None"], a: 1 },
      { q: "Which symbol is used for comments in C?", o: ["//", "#", "--", "%%"], a: 0 },
      { q: "What is a compiler?", o: ["Translates code to machine language", "Executes code line by line", "Fixes bugs", "None"], a: 0 },
      { q: "Which of these is an OOP concept?", o: ["Function", "Recursion", "Inheritance", "Looping"], a: 2 },
      { q: "What is the extension of a Java file?", o: [".jv", ".java", ".js", ".class"], a: 1 }
    ],
    // Day 3 (Wednesday)
    [
      { q: "What is the full form of SQL?", o: ["Simple Query Language", "Structured Query Language", "System Query Language", "None"], a: 1 },
      { q: "Which logic gate is known as universal gate?", o: ["AND", "OR", "NAND", "NOT"], a: 2 },
      { q: "What is a database?", o: ["Collection of hardware", "Organized collection of data", "A type of code", "None"], a: 1 },
      { q: "Which tag is used for links in HTML?", o: ["<link>", "<a>", "<href>", "<url>"], a: 1 },
      { q: "What is the base of Binary number system?", o: ["10", "8", "2", "16"], a: 2 }
    ],
    // Day 4 (Thursday)
    [
      { q: "What is the extension of C++ files?", o: [".c", ".cp", ".cpp", ".cxx"], a: 2 },
      { q: "Which of these is a social network?", o: ["Google", "Facebook", "Amazon", "Intel"], a: 1 },
      { q: "What is IP address used for?", o: ["To identify device on network", "To store data", "To speed up PC", "None"], a: 0 },
      { q: "Full form of WWW?", o: ["World Wide Web", "World Word Web", "Web World Wide", "None"], a: 0 },
      { q: "Which is a permanent storage?", o: ["RAM", "ROM", "Cache", "Register"], a: 1 }
    ],
    // Day 5 (Friday)
    [
      { q: "What is the result of 10 % 3 in C?", o: ["3", "1", "0", "10"], a: 1 },
      { q: "Which of these is a search engine?", o: ["Chrome", "Google", "Safari", "Windows"], a: 1 },
      { q: "What does PDF stand for?", o: ["Portable Document Format", "Print Document File", "Public Data Format", "None"], a: 0 },
      { q: "What is the brain of OS?", o: ["Shell", "Kernel", "UI", "API"], a: 1 },
      { q: "Which CSS property changes text color?", o: ["font-color", "text-style", "color", "background-color"], a: 2 }
    ],
    // Day 6 (Saturday)
    [
      { q: "What is a 4-bit data called?", o: ["Byte", "Nibble", "Chunk", "Word"], a: 1 },
      { q: "Who created Java?", o: ["James Gosling", "Dennis Ritchie", "Bill Gates", "Steve Jobs"], a: 0 },
      { q: "Which of these is an primary memory?", o: ["Pen drive", "Hard disk", "RAM", "CD-ROM"], a: 2 },
      { q: "Full form of URL?", o: ["Uniform Resource Locator", "Universal Radio Link", "Unique Resource Line", "None"], a: 0 },
      { q: "What is 2 in binary?", o: ["01", "10", "11", "00"], a: 1 }
    ]
  ],
  "BCA-104": [ // C Programming
    { q: "Which is used to take input in C?", o: ["printf", "scanf", "gets", "input"], a: 1 },
    { q: "Size of 'int' in 32-bit system?", o: ["1 byte", "2 bytes", "4 bytes", "8 bytes"], a: 2 },
    { q: "C language is a ______ language.", o: ["Low-level", "High-level", "Middle-level", "Machine-level"], a: 2 },
    { q: "Which keyword is used to exit a loop?", o: ["stop", "exit", "break", "return"], a: 2 },
    { q: "Header file for printf?", o: ["stdio.h", "conio.h", "math.h", "string.h"], a: 0 }
  ],
  "BCA-302": [ // DBMS
    { q: "What is the full form of DBMS?", o: ["Data Base Management System", "Data Bank Management System", "Database Master System", "None"], a: 0 },
    { q: "Which level of abstraction is closest to user?", o: ["Physical", "Logical", "View", "Internal"], a: 2 },
    { q: "What is a Row called in a table?", o: ["Attribute", "Tuple", "Field", "Entity"], a: 1 },
    { q: "SQL is a ______ language.", o: ["Procedural", "Non-procedural", "Low-level", "None"], a: 1 },
    { q: "Which key uniquely identifies a record?", o: ["Foreign Key", "Primary Key", "Candidate Key", "Super Key"], a: 1 }
  ]
};

let challengeQuestions = [], challengeIndex = 0, challengeScore = 0;

function openChallenge() {
  const body = document.getElementById('challengeBody');
  const footer = document.getElementById('challengeFooter');
  if (!body || !footer) return;

  challengeScore = 0; challengeIndex = 0;
  document.getElementById('challengeModal')?.classList.add('active');

  body.innerHTML = `
    <div style="text-align:center;">
      <h3 style="margin-bottom:16px;">Step 1: Select Semester</h3>
      <div class="challenge-sem-grid">
        ${[1, 2, 3, 4, 5, 6].map(n => `<button class="challenge-sem-btn" onclick="selectChallengeSemester(${n})">Semester ${n}</button>`).join('')}
      </div>
      <p style="margin-top:20px; font-size:0.85rem; color:var(--text-muted);">Try a daily challenge based on your semester topics!</p>
    </div>
  `;
  footer.innerHTML = `<button class="btn-outline" onclick="closeChallenge()">Exit</button>`;
}

function selectChallengeSemester(semNum) {
  const body = document.getElementById('challengeBody');
  if (!body) return;
  const semKey = 'Semester' + semNum;
  const subs = SUBJECTS[semKey] || [];

  body.innerHTML = `
    <div style="text-align:center;">
      <h3 style="margin-bottom:16px;">Step 2: Select Subject</h3>
      <div class="challenge-sub-grid">
        <button class="challenge-sub-btn general" onclick="startChallenge('GENERAL')">🌟 General BCA Topics</button>
        ${subs.map(s => `<button class="challenge-sub-btn" onclick="startChallenge('${s.code}')">${s.icon} ${s.name}</button>`).join('')}
      </div>
      <button class="btn-sm" style="margin-top:16px;" onclick="openChallenge()">⬅ Back</button>
    </div>
  `;
}

function startChallenge(subCode) {
  const dayIndex = new Date().getDay(); // 0-6
  let pool = [];

  if (subCode === 'GENERAL') {
    pool = CHALLENGE_BANK.GENERAL[dayIndex];
  } else {
    pool = CHALLENGE_BANK[subCode] || CHALLENGE_BANK.GENERAL[dayIndex];
  }

  challengeQuestions = pool;
  challengeIndex = 0;
  challengeScore = 0;
  renderChallengeQuestion();
}

function closeChallenge() { document.getElementById('challengeModal')?.classList.remove('active'); }

function renderChallengeQuestion() {
  const body = document.getElementById('challengeBody');
  const footer = document.getElementById('challengeFooter');
  if (!body || !footer) return;
  if (challengeIndex >= challengeQuestions.length) { renderChallengeScore(); return; }

  const q = challengeQuestions[challengeIndex];
  body.innerHTML = `
    <div class="challenge-progress-container">
      <div class="challenge-step">Question ${challengeIndex + 1} of ${challengeQuestions.length}</div>
      <div class="challenge-score-badge">Score: ${challengeScore}</div>
    </div>
    <div class="challenge-q">${q.q}</div>
    <div class="challenge-options">
      ${q.o.map((opt, i) => `
        <button class="challenge-opt-btn" onclick="handleChallengeAnswer(${i})">
          <span class="opt-prefix">${String.fromCharCode(65 + i)}</span>
          <span class="opt-text">${opt}</span>
        </button>
      `).join('')}
    </div>
  `;
  footer.innerHTML = `<button class="btn-outline" onclick="closeChallenge()">Quit</button>`;
}

function handleChallengeAnswer(selectedIdx) {
  const q = challengeQuestions[challengeIndex];
  const btns = document.querySelectorAll('.challenge-opt-btn');

  // Disable all buttons
  btns.forEach(b => b.style.pointerEvents = 'none');

  if (selectedIdx === q.a) {
    challengeScore++;
    btns[selectedIdx].classList.add('correct');
    showToast('✨ Correct!', 'success');
  } else {
    btns[selectedIdx].classList.add('wrong');
    btns[q.a].classList.add('correct');
    showToast('❌ In-correct!', 'error');
  }

  setTimeout(() => {
    challengeIndex++;
    renderChallengeQuestion();
  }, 1000);
}

function renderChallengeScore() {
  const body = document.getElementById('challengeBody');
  const footer = document.getElementById('challengeFooter');
  if (!body || !footer) return;
  const pct = Math.round(challengeScore / challengeQuestions.length * 100);
  const badge = pct === 100 ? '👑 Unstoppable!' : pct >= 80 ? '🏆 Expert!' : pct >= 60 ? '🥈 Good Job!' : pct >= 40 ? '🥉 Keep Trying!' : '📚 More Practice!';

  body.innerHTML = `
    <div class="challenge-result">
      <div class="result-icon">${pct >= 60 ? '🎉' : '📖'}</div>
      <div class="score-num">${challengeScore}/${challengeQuestions.length}</div>
      <p style="color:var(--text-muted);margin-top:8px;">${pct}% correct</p>
      <div class="challenge-badge">${badge}</div>
    </div>
  `;
  footer.innerHTML = `
    <button class="btn-outline" onclick="closeChallenge()">Close</button>
    <button class="btn-primary" onclick="openChallenge()">🔄 Restart</button>
  `;

  // Save score (existing logic)
  const scores = lsGet('challengeScores', []);
  scores.unshift({ score: challengeScore, total: challengeQuestions.length, date: Date.now() });
  lsSet('challengeScores', scores.slice(0, 20));
}

// ============================================================
// 27. ADMIN
// ============================================================
function safeBase64Decode(str) {
  try {
    if (/^[A-Za-z0-9+/=]+$/.test(str)) {
      return atob(str);
    }
  } catch (e) {}
  return str;
}

let isAdminSigningIn = false;
let secHeartbeatInterval = null;

// Audit Logging System
function logSecurityEvent(type, details) {
  if (!window.db) return Promise.resolve();
  const logId = window.db.ref('securityLogs').push().key;
  const user = (typeof firebase !== 'undefined' && firebase.auth) ? firebase.auth().currentUser : null;
  const adminId = user ? user.uid : 'system';
  return window.db.ref(`securityLogs/${logId}`).set({
    type: type,
    timestamp: Date.now(),
    adminId: adminId,
    details: details
  });
}
window.logSecurityEvent = logSecurityEvent;

// Device Fingerprinting & Telemetry
function getDeviceDetails() {
  const ua = navigator.userAgent;
  let browser = "Other";
  let os = "Other";
  let deviceName = "Unknown Device";
  
  if (ua.indexOf("Chrome") > -1) browser = "Chrome";
  else if (ua.indexOf("Safari") > -1) browser = "Safari";
  else if (ua.indexOf("Firefox") > -1) browser = "Firefox";
  else if (ua.indexOf("Edge") > -1) browser = "Edge";
  
  if (ua.indexOf("Windows NT 10.0") > -1) os = "Windows 10/11";
  else if (ua.indexOf("Windows NT 6.2") > -1) os = "Windows 8";
  else if (ua.indexOf("Windows NT 6.1") > -1) os = "Windows 7";
  else if (ua.indexOf("Macintosh") > -1) os = "macOS";
  else if (ua.indexOf("iPhone") > -1) { os = "iOS"; deviceName = "iPhone"; }
  else if (ua.indexOf("Android") > -1) { os = "Android"; deviceName = "Android Device"; }
  else if (ua.indexOf("Linux") > -1) os = "Linux";

  if (deviceName === "Unknown Device") {
    deviceName = os + " PC";
  }

  let fingerData = ua + navigator.language + screen.width + "x" + screen.height;
  let hash = 0;
  for (let i = 0; i < fingerData.length; i++) {
    hash = (hash << 5) - hash + fingerData.charCodeAt(i);
    hash |= 0;
  }
  const deviceId = "DEV-" + Math.abs(hash).toString(16).toUpperCase();

  return { deviceName, browser, os, deviceId };
}

// Brute-force lockout helpers
function checkLoginBruteForce() {
  const attempts = parseInt(localStorage.getItem('failedLoginAttempts') || '0');
  const lockoutUntil = parseInt(localStorage.getItem('loginLockoutUntil') || '0');
  
  if (lockoutUntil > Date.now()) {
    const secondsLeft = Math.ceil((lockoutUntil - Date.now()) / 1000);
    const minutes = Math.floor(secondsLeft / 60);
    const seconds = secondsLeft % 60;
    const timeStr = `${minutes}:${seconds < 10 ? '0' + seconds : seconds}`;
    throw new Error(`Too many failed attempts. Try again in ${timeStr}.`);
  }
}

function handleFailedLoginAttempt() {
  let attempts = parseInt(localStorage.getItem('failedLoginAttempts') || '0');
  attempts++;
  localStorage.setItem('failedLoginAttempts', attempts);
  
  if (attempts >= 5) {
    const lockoutDuration = 15 * 60 * 1000; // 15 mins
    const lockoutTime = Date.now() + lockoutDuration;
    localStorage.setItem('loginLockoutUntil', lockoutTime);
    logSecurityEvent('Lockout Triggered', `Admin panel locked out for 15 minutes due to repeated failures.`);
    if (window.db) {
      window.db.ref('failed_login_count').transaction(c => (c || 0) + 1);
    }
    throw new Error("Too many failed attempts. Account locked out for 15 minutes.");
  }
  
  if (window.db) {
    window.db.ref('failed_login_count').transaction(c => (c || 0) + 1);
  }
}

function resetFailedLoginAttempts() {
  localStorage.setItem('failedLoginAttempts', '0');
  localStorage.setItem('loginLockoutUntil', '0');
}



// Heartsbeat checks
function startSecurityHeartbeat() {
  if (secHeartbeatInterval) clearInterval(secHeartbeatInterval);
  
  secHeartbeatInterval = setInterval(async () => {
    const sessionId = localStorage.getItem('currentSessionId') || sessionStorage.getItem('currentSessionId');
    if (!sessionId || !db) return;
    
    db.ref(`sessions/${sessionId}/lastActive`).set(Date.now());
    
    db.ref(`sessions/${sessionId}`).once('value', async (snap) => {
      if (snap.exists()) {
        const sess = snap.val();
        if (sess.status === 'revoked' || sess.status === 'expired') {
          forceLogoutSession("Your session has been terminated by an administrator.");
        }
      } else {
        forceLogoutSession("Session invalid or expired.");
      }
    });

    db.ref('system/lockdown').once('value', (snap) => {
      const active = !!snap.val();
      const auth = lsGet('adminAuth');
      if (active && auth && auth.role !== 'superadmin') {
        forceLogoutSession("System lockdown active. All sessions revoked.");
      }
    });
  }, 30000);
}

function forceLogoutSession(message) {
  if (secHeartbeatInterval) clearInterval(secHeartbeatInterval);
  if (typeof firebase !== 'undefined' && firebase.auth) {
    firebase.auth().signOut().catch(e => console.error(e));
  }
  lsSet('adminAuth', null);
  localStorage.removeItem('currentSessionId');
  sessionStorage.removeItem('currentSessionId');
  
  alert(message || "Your session has expired.");
  window.location.reload();
}

async function adminLogout() {
  if (confirm("Are you sure you want to log out?")) {
    const sessionId = localStorage.getItem('currentSessionId') || sessionStorage.getItem('currentSessionId');
    if (sessionId && db) {
      await db.ref(`sessions/${sessionId}/status`).set('expired');
      await logSecurityEvent('Logout', `Super Admin logged out.`);
    }

    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        await firebase.auth().signOut();
      } catch (e) {
        console.error("Firebase signOut error:", e);
      }
    }
    lsSet('adminAuth', null);
    lsSet('lastAdminTab', 'dashboard');
    localStorage.removeItem('currentSessionId');
    sessionStorage.removeItem('currentSessionId');
    window.location.reload();
  }
}



function applyRoleBasedAccess(role) {
  const isStaff = (role === 'staff');
  const restrictedSidebarTabs = [
    'tabManage', 'tabTest', 'tabRegisteredStudents', 'tabNotifications', 'tabInbox', 'tabVisitors', 'tabAnalytics', 'tabCommunity', 'tabVoting', 'tabAiSettings', 'tabPortfolio', 'tabSettings', 'tabSecurity'
  ];
  
  restrictedSidebarTabs.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.style.setProperty('display', isStaff ? 'none' : 'flex', 'important');
    }
  });

  const restrictedQuickActions = [ 'bnManage', 'bnAnalytics' ];
  restrictedQuickActions.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.style.setProperty('display', isStaff ? 'none' : 'flex', 'important');
    }
  });

  const aiFab = document.getElementById('adminAssistantFab');
  if (aiFab) {
    aiFab.style.setProperty('display', isStaff ? 'none' : 'flex', 'important');
  }

  const currentTab = lsGet('lastAdminTab', 'dashboard');
  if (isStaff && ['manage', 'test', 'registered-students', 'notifications', 'inbox', 'visitors', 'analytics', 'community', 'voting', 'settings', 'ai-settings', 'portfolio', 'security'].includes(currentTab)) {
    if (typeof switchAdminTab === 'function') {
      switchAdminTab('dashboard');
    }
  }
}

function showLockdownScreen() {
  let overlay = document.getElementById('lockdownOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'lockdownOverlay';
    overlay.style.cssText = `
      position: fixed; inset: 0; background: rgba(15, 23, 42, 0.96); backdrop-filter: blur(20px);
      z-index: 999999; display: flex; flex-direction: column; align-items: center; justify-content: center;
      color: #fff; font-family: 'Outfit', sans-serif; padding: 24px; text-align: center;
    `;
    overlay.innerHTML = `
      <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 24px; padding: 40px; max-width: 480px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);">
        <span style="font-size: 4rem; display: block; margin-bottom: 20px;">🚨</span>
        <h1 style="font-size: 2rem; font-weight: 800; background: linear-gradient(135deg, #f87171, #ef4444); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 16px;">EMERGENCY LOCKDOWN</h1>
        <p style="color: #94a3b8; line-height: 1.6; margin-bottom: 24px; font-size: 0.95rem;">The platform is currently under emergency lockdown. All active sessions have been terminated, and user access is blocked for security purposes.</p>
        <div style="font-size: 0.78rem; text-transform: uppercase; color: #f87171; font-weight: 700; letter-spacing: 2px;">Core Security Protocol Engaged</div>
      </div>
    `;
    document.body.appendChild(overlay);
  }
}

async function initAdminPage() {
  initDarkMode(); initNavbar(); initVisitCounter();
  if (typeof syncAssistantKnowledge === 'function') syncAssistantKnowledge();
  
  if (typeof firebase !== 'undefined' && firebase.auth) {
    firebase.auth().onAuthStateChanged(async (user) => {
      if (user) {
        const email = user.email.toLowerCase();
        const role = (email === 'superadmin@bcastore.com') ? 'superadmin' : 'staff';
        
        // Block non-superadmin if lockdown is active
        if (db) {
          const snap = await db.ref('system/lockdown').once('value');
          if (snap.val() === true && role !== 'superadmin') {
            forceLogoutSession("System lockdown is active.");
            return;
          }
        }

        const auth = lsGet('adminAuth') || {};
        if (!auth.token || auth.exp <= Date.now() || auth.role !== role) {
          const token = await AttendanceSecurity.generateJWT({ username: role, role: role });
          lsSet('adminAuth', { token: token, exp: Date.now() + 3600000 * 24, role: role });
        }
        localStorage.setItem('bypass_maintenance', 'true');

        const gateEl = document.getElementById('adminLoginGate');
        if (gateEl) gateEl.style.display = 'none';
        document.body.classList.remove('login-active');
        const extras = document.getElementById('adminExtras');
        if (extras) extras.style.display = 'block';
        const ap = document.getElementById('adminPanel');
        if (ap) {
          ap.style.display = 'flex';
          ap.classList.add('adm-shell');
        }
        
        applyRoleBasedAccess(role);
        
        const lastTab = lsGet('lastAdminTab', 'dashboard');
        switchAdminTab(lastTab);

        loadInboxBadge(); loadManageMaterials(); loadAnalytics();
        startSecurityHeartbeat();

        const greetingLabel = document.getElementById('adminGreetingLabel');
        const now = new Date();
        const hour = now.getHours();
        let greetingText = "GOOD DAY";
        if (hour < 12) greetingText = "GOOD MORNING";
        else if (hour < 17) greetingText = "GOOD AFTERNOON";
        else greetingText = "GOOD EVENING";
        if (greetingLabel) greetingLabel.textContent = greetingText;
      } else {
        // No Firebase user — show admin panel directly (login gate removed)
        document.body.classList.remove('login-active');
        const ap = document.getElementById('adminPanel');
        if (ap) {
          ap.style.display = 'flex';
          ap.classList.add('adm-shell');
        }
        applyRoleBasedAccess('superadmin');
        const lastTab = lsGet('lastAdminTab', 'dashboard');
        switchAdminTab(lastTab);
        loadInboxBadge(); loadManageMaterials(); loadAnalytics();
        startSecurityHeartbeat();
      }
    });
  } else {
    // Firebase unavailable — always show admin panel directly
    const ap = document.getElementById('adminPanel');
    if (ap) {
      ap.style.display = 'flex';
      ap.classList.add('adm-shell');
    }
    document.body.classList.remove('login-active');
    applyRoleBasedAccess('superadmin');
    const lastTab = lsGet('lastAdminTab', 'dashboard');
    switchAdminTab(lastTab);
    loadInboxBadge(); loadManageMaterials(); loadAnalytics();
    startSecurityHeartbeat();
  }
}

function switchAdminTab(tab) {
  // Tactile feedback for mobile
  if (window.navigator && window.navigator.vibrate) window.navigator.vibrate(5);

  // Close Sidebar on Mobile immediately
  if (window.innerWidth <= 1024) {
    closeAdmSidebar();
  }

  // Save tab for persistence
  lsSet('lastAdminTab', tab);

  // Instant UI Refresh - Fade out sections
  const sections = ['dashboard', 'add', 'manage', 'inbox', 'analytics', 'visitors', 'notifications', 'community', 'voting', 'test', 'registered-students', 'portfolio', 'batches', 'security', 'settings', 'ai-settings'];
  sections.forEach(t => {
    const el = document.getElementById('admin-tab-' + t);
    if (el) {
      el.style.display = 'none';
      el.style.opacity = '0';
      el.classList.remove('active');
    }
    let btnId = 'tab' + t.charAt(0).toUpperCase() + t.slice(1);
    if (t === 'registered-students') btnId = 'tabRegisteredStudents';
    if (t === 'ai-settings') btnId = 'tabAiSettings';
    const btn = document.getElementById(btnId);
    if (btn) btn.classList.remove('active');
  });

  // Show selected with fresh state
  const active = document.getElementById('admin-tab-' + tab);
  if (active) {
    active.style.display = 'block';
    active.classList.add('active');
    active.classList.remove('animate-refresh');
    void active.offsetWidth; // Trigger reflow
    active.classList.add('animate-refresh');
    setTimeout(() => { active.style.opacity = '1'; }, 10);
  }

  let activeBtnId = 'tab' + tab.charAt(0).toUpperCase() + tab.slice(1);
  if (tab === 'registered-students') activeBtnId = 'tabRegisteredStudents';
  const activeBtn = document.getElementById(activeBtnId);
  if (activeBtn) activeBtn.classList.add('active');

  // Load Tab Data with "Fast Refresh" logic
  switch (tab) {
    case 'inbox': loadInboxMessages(); break;
    case 'manage': loadManageMaterials(); break;
    case 'analytics': loadAnalytics(); break;
    case 'visitors': loadVisitorsList(); break;
    case 'notifications': loadAdminNotifications(); break;
    case 'community': if (typeof loadAdminCommunityTab === 'function') loadAdminCommunityTab(); break;
    case 'voting': if (typeof loadAdminVotingTab === 'function') loadAdminVotingTab(); break;
    case 'dashboard': loadDashboardStats(); break;
    case 'test': if (typeof initAdminTestHub === 'function') initAdminTestHub(); break;
    case 'registered-students': if (typeof loadRegisteredStudentsTab === 'function') loadRegisteredStudentsTab(); break;
    case 'batches': if (typeof initBatchesTab === 'function') initBatchesTab(); break;
    case 'security': loadDeviceSessions(); loadSecurityDashboardData(); break;
  }

  updateAdminTopNavigation(tab);

  // Update Bottom Nav Active State
  const bnMap = {
    dashboard: 'bnDashboard',
    add: 'bnAdd',
    manage: 'bnManage',
    analytics: 'bnAnalytics'
  };
  Object.values(bnMap).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  });
  if (bnMap[tab]) {
    const el = document.getElementById(bnMap[tab]);
    if (el) el.classList.add('active');
  }

  // Close mobile sidebar
  closeAdmSidebar();
}

// Sidebar toggle functions
function toggleAdmSidebar() {
  const shell = document.querySelector('.adm-shell');
  if (window.innerWidth <= 1024) {
    const sb = document.getElementById('admSidebar');
    if (sb && sb.classList.contains('open')) {
      closeAdmSidebar();
    } else {
      openAdmSidebar();
    }
  } else {
    if (shell) shell.classList.toggle('sidebar-collapsed');
  }
}
function openAdmSidebar() {
  const sb = document.getElementById('admSidebar');
  const overlay = document.getElementById('admOverlay');
  if (sb) sb.classList.add('open');
  if (overlay) overlay.classList.add('show');
}
function closeAdmSidebar() {
  const sb = document.getElementById('admSidebar');
  const overlay = document.getElementById('admOverlay');
  if (sb) sb.classList.remove('open');
  if (overlay) overlay.classList.remove('show');
}

// Dashboard stats loader
function loadDashboardStats() {
  if (!db) return;
  db.ref('materials').once('value', snap => {
    let count = 0;
    if (snap.exists()) snap.forEach(sem => { sem.forEach(sub => { sub.forEach(() => count++); }); });
    const el = document.getElementById('dashTotalMaterials');
    if (el) el.textContent = count;
  });
  db.ref('site_stats/totalVisits').once('value', snap => {
    const el = document.getElementById('dashTotalVisitors');
    if (el) el.textContent = (snap.val() || 0).toLocaleString();
  });
  db.ref('suggestions').once('value', snap => {
    const el = document.getElementById('dashTotalInbox');
    if (el) el.textContent = snap.numChildren() || 0;
  });
  db.ref('site_stats/totalEnrolled').once('value', snap => {
    const el = document.getElementById('dashTotalEnrolled');
    if (el) el.textContent = (snap.val() || 0).toLocaleString();
  });
}

// Admin clock
function updateAdmClock() {
  const el = document.getElementById('admClock');
  if (el) el.textContent = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateAdmClock, 30000);

// Ctrl+K shortcut
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    const input = document.getElementById('admGlobalSearch');
    if (input) input.focus();
  }
});
// STAFF PANEL LOGIC
// ============================================================
function staffLogin() {
  const user = document.getElementById('staffUsername')?.value.trim();
  const pass = document.getElementById('staffPassword')?.value;

  // Staff Login completely deleted/disabled
  const err = document.getElementById('staffLoginError'); if (err) err.style.display = 'block';
  const p = document.getElementById('staffPassword'); if (p) p.value = '';
}

function staffLogout() {
  lsSet('staffAuth', null);
  location.reload();
}

function toggleStaffPassView() {
  const inp = document.getElementById('staffPassword');
  if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
}

function initStaffPage() {
  initDarkMode(); initNavbar();
  const auth = lsGet('staffAuth');
  if (auth && auth.exp > Date.now()) {
    document.getElementById('staffLoginGate').style.display = 'none';
    document.getElementById('staffPanel').style.display = 'block';
    loadStaffNotifications();
  }
  ['staffUsername', 'staffPassword'].forEach(id => document.getElementById(id)?.addEventListener('keydown', e => { if (e.key === 'Enter') staffLogin(); }));
}

function switchStaffTab(tab) {
  ['add', 'notifications'].forEach(t => {
    const el = document.getElementById('staff-tab-' + t); if (el) el.style.display = t === tab ? 'block' : 'none';
    const btn = document.getElementById('tab' + t.charAt(0).toUpperCase() + t.slice(1)); if (btn) btn.classList.toggle('active', t === tab);
  });
  if (tab === 'notifications') loadStaffNotifications();
}

function loadStaffNotifications() {
  const list = document.getElementById('staffNotifList');
  if (!list || !db) return;
  list.innerHTML = '<div class="loading-spinner"><div class="spinner"></div></div>';
  db.ref('notifications').orderByChild('createdAt').limitToLast(10).on('value', snap => {
    if (!snap.exists()) {
      list.innerHTML = '<div class="empty-state"><h3>No Notifications</h3></div>';
      return;
    }
    let items = [];
    snap.forEach(child => items.push({ id: child.key, ...child.val() }));
    items.sort((a, b) => b.createdAt - a.createdAt);
    list.innerHTML = items.map(n => {
      const t = NOTIF_TYPES[n.type] || NOTIF_TYPES.info;
      return `<div class="admin-notif-item glass-card" style="border-left:4px solid ${t.color};">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
          <div style="flex:1;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
              <span class="notif-type-badge">${t.icon} ${t.label}</span>
              ${n.pinned ? '<span class="notif-pin-badge">📌 Pinned</span>' : ''}
              <span style="font-size:0.75rem;color:var(--text-muted);margin-left:auto;">${formatDate(n.createdAt)}</span>
            </div>
            <div style="font-weight:800;font-size:1rem;margin-bottom:4px;">${n.title}</div>
            <div style="font-size:0.88rem;color:var(--text-muted);">${n.message}</div>
          </div>
        </div>
      </div>`;
    }).join('');
  });
}

// ============================================================
// NOTIFICATION SYSTEM
// ============================================================
const NOTIF_TYPES = {
  info: { label: 'Info', color: '#3b82f6', icon: '🔵' },
  update: { label: 'Update', color: '#10b981', icon: '🟢' },
  exam: { label: 'Exam', color: '#f59e0b', icon: '🟡' },
  alert: { label: 'Alert', color: '#ef4444', icon: '🔴' }
};

function renderNotifications() {
  const section = document.getElementById('notificationsSection');
  const grid = document.getElementById('notifCardsGrid');
  const ticker = document.getElementById('notifTickerBar');
  const tickerContent = document.getElementById('notifTickerContent');
  const countPill = document.getElementById('notifCountPill');
  if (!section || !grid) return;

  if (!db) { section.style.display = 'none'; return; }

  firebase.database().ref('notifications').orderByChild('createdAt').on('value', snap => {
    if (!snap.exists()) { section.style.display = 'none'; return; }

    let list = [];
    snap.forEach(child => list.push({ id: child.key, ...child.val() }));
    list.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return b.createdAt - a.createdAt;
    });

    section.style.display = 'block';
    if (countPill) { countPill.textContent = list.length + (list.length === 1 ? ' Notice' : ' Notices'); countPill.style.display = 'inline-block'; }

    // Ticker for pinned items
    const pinned = list.filter(n => n.pinned);
    if (ticker && tickerContent) {
      if (pinned.length > 0) {
        ticker.style.display = 'flex';
        tickerContent.innerHTML = pinned.map(n => `<span class="notif-ticker-item">📌 ${n.title}: ${n.message}</span>`).join('<span class="notif-ticker-sep">•••</span>');
      } else {
        ticker.style.display = 'none';
      }
    }

    // Render cards
    grid.innerHTML = list.map(n => {
      const t = NOTIF_TYPES[n.type] || NOTIF_TYPES.info;
      return `<div class="notif-card notif-card-${n.type || 'info'}" style="--notif-color:${t.color};">
        <div class="notif-card-left"></div>
        <div class="notif-card-body">
          <div class="notif-card-top">
            <span class="notif-type-badge">${t.icon} ${t.label}</span>
            ${n.pinned ? '<span class="notif-pin-badge">📌 Pinned</span>' : ''}
            <span class="notif-date">${formatDate(n.createdAt)}</span>
          </div>
          <div class="notif-card-title">${n.title}</div>
          <div class="notif-card-msg">${n.message}</div>
        </div>
      </div>`;
    }).join('');
  });
}

function addNotification() {
  const title = document.getElementById('notifTitle')?.value.trim();
  const message = document.getElementById('notifMessage')?.value.trim();
  const type = document.getElementById('notifType')?.value || 'info';
  const pinned = document.getElementById('notifPinned')?.checked || false;
  if (!title || !message) { showToast('❌ Title and message are required.', 'error'); return; }
  if (!db) { showToast('❌ Firebase not connected.', 'error'); return; }
  db.ref('notifications').push({ title, message, type, pinned, createdAt: Date.now() })
    .then(() => {
      // Trigger live notifications push
      if (window.NotificationsService) {
        let liveType = 'announcement';
        if (type === 'alert') liveType = 'announcement';
        else if (type === 'update') liveType = 'batch_update';
        else if (type === 'exam') liveType = 'test_added';
        
        window.NotificationsService.pushSystemNotification(
          liveType,
          title,
          message,
          '',
          'notifications.html',
          '',
          'Check Update'
        ).catch(e => console.warn("Live push announcement failed:", e));
      }

      showToast('📢 Notification posted!', 'success');
      document.getElementById('notifTitle').value = '';
      document.getElementById('notifMessage').value = '';
      document.getElementById('notifPinned').checked = false;
      if (document.getElementById('adminNotifList')) loadAdminNotifications();
      if (document.getElementById('staffNotifList')) loadStaffNotifications();
    })
    .catch(() => showToast('❌ Failed to post.', 'error'));
}

function deleteNotification(id) {
  if (!db) return;
  db.ref('notifications/' + id).remove()
    .then(() => { showToast('🗑️ Deleted!', 'success'); loadAdminNotifications(); })
    .catch(() => showToast('❌ Delete failed.', 'error'));
}

function clearAllNotifications() {
  if (!confirm('Delete ALL notifications? This cannot be undone.')) return;
  if (!db) return;
  db.ref('notifications').remove()
    .then(() => { showToast('🗑️ All notifications cleared!', 'success'); loadAdminNotifications(); })
    .catch(() => showToast('❌ Failed to clear.', 'error'));
}

function loadAdminNotifications() {
  const list = document.getElementById('adminNotifList');
  const empty = document.getElementById('adminNotifEmpty');
  if (!list || !db) return;
  list.innerHTML = '<div class="loading-spinner"><div class="spinner"></div></div>';
  db.ref('notifications').orderByChild('createdAt').on('value', snap => {
    if (!snap.exists()) {
      list.innerHTML = '';
      if (empty) empty.style.display = 'block';
      return;
    }
    if (empty) empty.style.display = 'none';
    let items = [];
    snap.forEach(child => items.push({ id: child.key, ...child.val() }));
    items.sort((a, b) => b.createdAt - a.createdAt);
    list.innerHTML = items.map(n => {
      const t = NOTIF_TYPES[n.type] || NOTIF_TYPES.info;
      return `<div class="admin-notif-item glass-card" style="border-left:4px solid ${t.color};">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
          <div style="flex:1;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
              <span class="notif-type-badge">${t.icon} ${t.label}</span>
              ${n.pinned ? '<span class="notif-pin-badge">📌 Pinned</span>' : ''}
              <span style="font-size:0.75rem;color:var(--text-muted);margin-left:auto;">${formatDate(n.createdAt)}</span>
            </div>
            <div style="font-weight:800;font-size:1rem;margin-bottom:4px;">${n.title}</div>
            <div style="font-size:0.88rem;color:var(--text-muted);">${n.message}</div>
          </div>
          <button class="btn-danger" onclick="deleteNotification('${n.id}')" style="flex-shrink:0;">🗑️</button>
        </div>
      </div>`;
    }).join('');
  });

  if (typeof loadLiveNotificationsAnalytics === 'function') {
    loadLiveNotificationsAnalytics();
  }
}

function loadLiveNotificationsAnalytics() {
  if (typeof db === 'undefined' || !db) return;

  const sentEl = document.getElementById('statNotifsSent');
  const openedEl = document.getElementById('statNotifsOpened');
  const ctrEl = document.getElementById('statNotifCTR');
  const viewsEl = document.getElementById('statNotifViews');
  const activeEl = document.getElementById('statActiveUsers');
  const tblBody = document.getElementById('tblNotifAnalytics');
  const lstActive = document.getElementById('lstActiveUsers');

  if (!tblBody) return;

  db.ref('notification_analytics/summary/sentCount').on('value', snap => {
    if (sentEl) sentEl.textContent = snap.val() || 0;
  });

  db.ref('notification_analytics/details').on('value', snap => {
    if (!snap.exists()) {
      tblBody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px 10px;">No analytics data available yet.</td></tr>`;
      if (openedEl) openedEl.textContent = 0;
      if (ctrEl) ctrEl.textContent = '0%';
      if (viewsEl) viewsEl.textContent = 0;
      return;
    }

    let items = [];
    let totalOpened = 0;
    let totalClicks = 0;
    let totalViews = 0;

    snap.forEach(child => {
      const data = child.val();
      items.push(data);
      totalOpened += (data.openedCount || 0);
      totalClicks += (data.clicksCount || 0);
      totalViews += (data.totalViews || 0);
    });

    if (openedEl) openedEl.textContent = totalOpened;
    if (viewsEl) viewsEl.textContent = totalViews;
    if (ctrEl) {
      const ctr = totalOpened > 0 ? ((totalClicks / totalOpened) * 100).toFixed(1) : 0;
      ctrEl.textContent = `${ctr}%`;
    }

    items.sort((a, b) => (b.sentAt || 0) - (a.sentAt || 0));

    tblBody.innerHTML = items.map(n => {
      const rate = n.openedCount > 0 ? ((n.clicksCount / n.openedCount) * 100).toFixed(1) : 0;
      const dateStr = new Date(n.sentAt).toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
      });
      return `
        <tr>
          <td style="padding: 10px 14px; font-weight: 700; color: #fff;">${n.title}</td>
          <td style="padding: 10px 14px; text-align: center; color: var(--text-muted);">${dateStr}</td>
          <td style="padding: 10px 14px; text-align: center; color: #a78bfa; font-weight: 800;">${n.openedCount || 0}</td>
          <td style="padding: 10px 14px; text-align: center; color: #10b981; font-weight: 800;">${n.clicksCount || 0}</td>
          <td style="padding: 10px 14px; text-align: center; color: #fbbf24; font-weight: 800;">${rate}%</td>
        </tr>
      `;
    }).join('');
  });

  db.ref('active_users').on('value', snap => {
    if (!lstActive) return;

    if (!snap.exists()) {
      lstActive.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 20px 0; font-size: 0.8rem;">No active students</div>`;
      if (activeEl) activeEl.textContent = 0;
      return;
    }

    const fiveMinsAgo = Date.now() - 300000;
    let activeUsers = [];

    snap.forEach(child => {
      const user = child.val();
      if (user.lastActive > fiveMinsAgo) {
        activeUsers.push(user);
      }
    });

    if (activeEl) activeEl.textContent = activeUsers.length;

    if (activeUsers.length === 0) {
      lstActive.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 20px 0; font-size: 0.8rem;">No active students</div>`;
      return;
    }

    activeUsers.sort((a, b) => b.lastActive - a.lastActive);

    lstActive.innerHTML = activeUsers.map(u => {
      const diffSec = Math.floor((Date.now() - u.lastActive) / 1000);
      let statusText = 'Just now';
      if (diffSec >= 60) {
        statusText = `${Math.floor(diffSec / 60)}m ago`;
      }
      return `
        <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(255,255,255,0.03); padding: 8px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 6px;">
          <div>
            <div style="font-weight: 700; color: #fff; font-size: 0.82rem;">${u.name}</div>
            <div style="font-size: 0.68rem; color: var(--text-muted); font-family: monospace;">@${u.id}</div>
          </div>
          <span style="font-size: 0.72rem; color: #10b981; font-weight: 700;">● ${statusText}</span>
        </div>
      `;
    }).join('');
  });
}

function updateSubjectDropdown(semId, subId) {
  const sk = document.getElementById(semId)?.value;
  const sel = document.getElementById(subId); if (!sel) return;
  sel.innerHTML = '<option value="">— Select Subject —</option>';
  (SUBJECTS[sk] || []).forEach(s => { const o = document.createElement('option'); o.value = s.code; o.textContent = s.code + ': ' + s.name; sel.appendChild(o); });
}

function addMaterial() {
  const semKey = document.getElementById('addSemester')?.value;
  const code = document.getElementById('addSubject')?.value;
  const type = document.getElementById('addType')?.value;
  const title = document.getElementById('addTitle')?.value.trim();
  const description = document.getElementById('addDescription')?.value.trim() || '';
  const link = document.getElementById('addLink')?.value.trim();
  if (!semKey || !code || !type || !title || !link) { showToast('❌ Fill all required fields.', 'error'); return; }
  const data = {
    type, title, description,
    link: link.trim(),
    createdAt: Date.now()
  };
  if (db) {
    const pushRef = firebase.database().ref('materials/' + semKey + '/' + code).push(data);
    showToast('✅ Added to Firebase!', 'success');
    
    // Automatically trigger push notification on addition
    if (window.NotificationsService) {
      let notifType = 'announcement';
      let titlePrefix = '📢 Important Update';
      let actionName = 'Check Update';
      if (type.includes('video')) {
        notifType = 'video_upload';
        titlePrefix = '🎉 New Video Uploaded';
        actionName = 'Open Batch Now';
      } else if (type.includes('notes') || type.includes('pdf')) {
        notifType = 'notes_upload';
        titlePrefix = '🔥 New Notes Added';
        actionName = 'View Notes';
      } else if (type.includes('assignment')) {
        notifType = 'assignment';
        titlePrefix = '📋 New Assignment Posted';
        actionName = 'View Assignment';
      } else if (type.includes('test')) {
        notifType = 'test_added';
        titlePrefix = '🎯 New Test Available';
        actionName = 'Start Test';
      }
      
      const notifMessage = `${semKey} › ${code} में नया material जोड़ा गया है।\n\nTopic: ${title}\n\nRevision के लिए अभी देखें।`;
      
      window.NotificationsService.pushSystemNotification(
        notifType,
        titlePrefix,
        notifMessage,
        semKey.toLowerCase().replace(' ', '-'),
        `semester.html?sem=${semKey.replace('Semester ', '')}`,
        '',
        actionName
      ).catch(e => console.warn("Auto push failed:", e));
    }

    clearAddForm();
    if (typeof loadManageMaterials === 'function') loadManageMaterials();
    if (typeof loadAnalytics === 'function') loadAnalytics();

    pushRef.catch((error) => {
      console.error("Firebase push error:", error);
      showToast('❌ Firebase Error: ' + error.message, 'error');
    });
  } else saveToLS(semKey, code, data);
}
function saveToLS(semKey, code, data) {
  const key = 'materials_' + semKey + '_' + code; const ex = lsGet(key, {}); const id = genId(); ex[id] = { ...data, id }; lsSet(key, ex);
  showToast('✅ Saved locally!', 'success'); clearAddForm(); loadManageMaterials(); loadAnalytics();
}
function clearAddForm() { ['addSemester', 'addSubject', 'addType', 'addTitle', 'addDescription', 'addLink'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; }); }

let manageListenerRef = null;

function loadManageMaterials() {
  const fSem = document.getElementById('filterSem')?.value || '';
  const fType = document.getElementById('filterType')?.value || '';
  const fQ = (document.getElementById('manageSearch')?.value || '').toLowerCase();
  const cont = document.getElementById('manageMaterialsList');
  const emptyEl = document.getElementById('manageEmpty');
  if (!cont) return;

  if (manageListenerRef && db) {
    manageListenerRef.off('value');
    manageListenerRef = null;
  }

  cont.innerHTML = '<div class="loading-spinner"><div class="spinner"></div></div>';
  const semKeys = fSem ? [fSem] : Object.keys(SUBJECTS);
  let items = [];
  semKeys.forEach(sk => SUBJECTS[sk]?.forEach(sub => {
    const k = 'materials_' + sk + '_' + sub.code;
    Object.values(lsGet(k, {})).forEach(item => {
      if ((!fType || item.type === fType) && (!fQ || item.title?.toLowerCase().includes(fQ)))
        items.push({ ...item, semKey: sk, code: sub.code, subjectName: sub.name });
    });
  }));
  if (db) {
    manageListenerRef = firebase.database().ref('materials');
    manageListenerRef.on('value', snap => {
      let fbItems = [...items];
      if (snap.exists()) {
        snap.forEach(skSnap => skSnap.forEach(subSnap => {
          const sk = skSnap.key, code = subSnap.key;
          const sub = SUBJECTS[sk]?.find(s => s.code === code);
          subSnap.forEach(child => {
            const item = { id: child.key, ...child.val(), semKey: sk, code, subjectName: sub?.name || code };
            if ((!fSem || sk === fSem) && (!fType || item.type === fType) && (!fQ || item.title?.toLowerCase().includes(fQ)))
              if (!fbItems.find(i => i.id === item.id)) fbItems.push(item);
          });
        }));
      }
      fbItems.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      renderManageList(fbItems, cont, emptyEl);
    }, (error) => {
      console.error("Firebase manage read error:", error);
      items.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      renderManageList(items, cont, emptyEl);
    });
  } else {
    items.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    renderManageList(items, cont, emptyEl);
  }
}

function renderManageList(items, cont, emptyEl) {
  if (!items.length) { cont.innerHTML = ''; if (emptyEl) emptyEl.style.display = 'block'; return; }
  if (emptyEl) emptyEl.style.display = 'none';
  cont.innerHTML = items.map(item => `<div class="manage-row">
    <div class="manage-row-info">
      <div class="manage-row-title">${item.title || 'Untitled'} ${typeBadge(item.type || 'notes')}</div>
      <div class="manage-row-meta">${item.semKey} › ${item.code} | 🕐 ${formatDate(item.timestamp)}</div>
      <div class="manage-row-meta"><a href="${item.link || '#'}" target="_blank" style="color:var(--primary);">🔗 ${(item.link || '').substring(0, 60)}</a></div>
    </div>
    <div class="manage-row-actions">
      <button class="btn-outline" data-item="${encodeURIComponent(JSON.stringify(item))}" onclick="openEditModal(JSON.parse(decodeURIComponent(this.getAttribute('data-item'))))">✏️ Edit</button>
      <button class="btn-danger" onclick="deleteMaterial('${item.semKey}','${item.code}','${item.id}')">🗑️</button>
    </div>
  </div>`).join('');
}

function openEditModal(item) {
  ['editId', 'editSemKey', 'editSubKey', 'editTitle', 'editDescription', 'editLink', 'editType'].forEach(id => {
    const el = document.getElementById(id); if (!el) return;
    if (id === 'editId') el.value = item.id || '';
    else if (id === 'editSemKey') el.value = item.semKey || '';
    else if (id === 'editSubKey') el.value = item.code || '';
    else if (id === 'editTitle') el.value = item.title || '';
    else if (id === 'editDescription') el.value = item.description || '';
    else if (id === 'editLink') el.value = item.link || '';
    else if (id === 'editType') el.value = item.type || 'notes';
  });
  document.getElementById('editModal')?.classList.add('active');
}
function closeEditModal() { document.getElementById('editModal')?.classList.remove('active'); }
function saveEditMaterial() {
  const id = document.getElementById('editId').value;
  const semKey = document.getElementById('editSemKey').value;
  const code = document.getElementById('editSubKey').value;
  const updates = { title: document.getElementById('editTitle').value.trim(), description: document.getElementById('editDescription').value.trim(), link: document.getElementById('editLink').value.trim(), type: document.getElementById('editType').value, timestamp: Date.now() };
  if (!updates.title || !updates.link) { showToast('❌ Title and Link required.', 'error'); return; }
  if (db) {
    firebase.database().ref('materials/' + semKey + '/' + code + '/' + id).update(updates).catch(() => updateLS(semKey, code, id, updates));
    showToast('✅ Updated!', 'success');
    closeEditModal();
    loadManageMaterials();
  } else updateLS(semKey, code, id, updates);
}
function updateLS(semKey, code, id, updates) {
  const key = 'materials_' + semKey + '_' + code; const ex = lsGet(key, {}); if (ex[id]) ex[id] = { ...ex[id], ...updates }; lsSet(key, ex);
  showToast('✅ Updated locally!', 'success'); closeEditModal(); loadManageMaterials();
}
function deleteMaterial(semKey, code, id) {
  if (!confirm('Delete this material?')) return;
  if (db) {
    firebase.database().ref('materials/' + semKey + '/' + code + '/' + id).remove().catch(() => deleteLS(semKey, code, id));
    showToast('🗑️ Deleted!', 'success');
    loadManageMaterials();
    loadAnalytics();
  } else deleteLS(semKey, code, id);
}
function deleteLS(semKey, code, id) {
  const key = 'materials_' + semKey + '_' + code; const ex = lsGet(key, {}); delete ex[id]; lsSet(key, ex);
  showToast('🗑️ Deleted locally!', 'success'); loadManageMaterials(); loadAnalytics();
}

function loadInboxBadge() {
  if (!db) return;
  db.ref('suggestions').off('value');
  db.ref('suggestions').on('value', snap => {
    let count = 0;
    snap.forEach(child => { if (!child.val().read) count++; });
    const b = document.getElementById('inboxBadge');
    if (b) { b.textContent = count; b.style.display = count > 0 ? 'inline' : 'none'; }
  });
}

function loadInboxMessages() {
  if (!db) return;
  const cont = document.getElementById('suggestionList');
  const emptyEl = document.getElementById('inboxEmpty');
  if (!cont) return;

  // Use .off() to prevent multiple listeners
  db.ref('suggestions').off('value');
  db.ref('visitors').off('value'); // Also listen to visitors for real-time presence

  db.ref('visitors').on('value', vSnap => {
    const visitors = vSnap.val() || {};

    db.ref('suggestions').on('value', snap => {
      if (!snap.exists()) {
        cont.innerHTML = '';
        if (emptyEl) emptyEl.style.display = 'block';
        return;
      }
      if (emptyEl) emptyEl.style.display = 'none';

      const suggs = [];
      snap.forEach(child => { suggs.unshift({ id: child.key, ...child.val() }); });

      cont.innerHTML = suggs.map(s => {
        const catClass = `badge-cat-${(s.category || 'general').toLowerCase().replace(' ', '-')}`;
        const msgs = s.messages ? Object.values(s.messages) : [];

        // Presence Check
        const visitor = visitors[s.visitorId] || {};
        const lastActive = visitor.lastActive || 0;
        const isOnline = Date.now() - lastActive < 60000;
        const statusHtml = isOnline
          ? `<span class="status-indicator status-online" style="color:var(--success); font-size:0.75rem;"><span class="status-dot" style="display:inline-block; width:8px; height:8px; background:var(--success); border-radius:50%; margin-right:4px; animation:pulse 2s infinite;"></span>Online</span>`
          : `<span class="status-indicator status-offline" style="color:var(--text-muted); font-size:0.75rem;">Last seen: ${formatDate(lastActive)}</span>`;

        const statusBadge = `<span class="status-badge" style="padding: 4px 10px; border-radius: 99px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; ${s.status === 'Resolved' ? 'background:rgba(16, 185, 129, 0.1); color:#10b981; border:1px solid rgba(16, 185, 129, 0.2);' : 'background:rgba(245, 158, 11, 0.1); color:#f59e0b; border:1px solid rgba(245, 158, 11, 0.2);'}">${s.status || 'Pending'}</span>`;

        return `
          <div class="suggestion-card ${s.read ? 'read' : 'unread'}" style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:20px; margin-bottom:16px; transition:all 0.3s ease;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px;">
              <div style="display:flex; flex-direction:column; gap:6px;">
                <div style="display:flex; align-items:center; gap:10px;">
                  <h4 style="margin:0; font-size:1.1rem; color:var(--text);">${s.subject || 'No Subject'}</h4>
                  ${statusBadge}
                </div>
                <div style="display:flex; align-items:center; gap:12px; font-size:0.85rem; color:var(--text-muted);">
                  <span>👤 ${s.name || 'Anonymous'}</span>
                  <span>📧 ${s.email || 'No Email'}</span>
                </div>
              </div>
              <div style="text-align:right;">
                <span class="sugg-category-badge ${catClass}" style="padding:4px 12px; border-radius:99px; font-size:0.75rem; font-weight:700; display:inline-block; margin-bottom:8px;">${s.category || 'General'}</span>
                <div style="font-size:0.75rem; color:var(--text-muted);">🕐 ${formatDate(s.date)}</div>
              </div>
            </div>
            
            <div class="chat-thread" style="margin:16px 0; background:rgba(0,0,0,0.03); padding:16px; border-radius:12px; border:1px dashed var(--border);">
              ${msgs.map(m => `
                <div style="margin-bottom:12px; text-align:${m.sender === 'admin' ? 'right' : 'left'}">
                  <div style="display:inline-block; padding:10px 16px; border-radius:14px; font-size:0.95rem; line-height:1.5; 
                    max-width: 85%;
                    background:${m.sender === 'admin' ? 'var(--primary)' : 'var(--bg)'}; 
                    color:${m.sender === 'admin' ? '#fff' : 'var(--text)'};
                    border:1px solid ${m.sender === 'admin' ? 'transparent' : 'var(--border)'}">
                    ${m.text}
                  </div>
                  <div style="font-size:0.7rem; color:var(--text-muted); margin-top:4px;">${formatDate(m.date)}</div>
                </div>
              `).join('')}
            </div>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:20px; padding-top:16px; border-top:1px solid var(--border);">
              <div style="display:flex; gap:16px; align-items:center;">
                ${statusHtml}
                <div class="sugg-context" style="font-size:0.8rem; color:var(--text-muted);">📍 ${s.context || 'Unknown'}</div>
              </div>
              <div class="sugg-actions" style="display:flex; gap:8px;">
                <button class="btn-primary" style="padding:6px 16px; font-size:0.85rem;" onclick="sendAdminMessage('${s.id}')">💬 Reply</button>
                <button class="btn-outline" style="padding:6px 16px; font-size:0.85rem;" onclick="toggleSuggStatus('${s.id}', '${s.status}')">${s.status === 'Resolved' ? '⏳ Pending' : '✅ Resolve'}</button>
                <button class="btn-outline" style="padding:6px 16px; font-size:0.85rem;" onclick="toggleSuggRead('${s.id}', ${s.read})">${s.read ? '📬 Unread' : '👁️ Read'}</button>
                <button class="btn-outline" style="padding:6px 16px; font-size:0.85rem; color:var(--danger); border-color:var(--danger);" onclick="deleteSuggestion('${s.id}')">🗑️</button>
              </div>
            </div>
          </div>`;
      }).join('');
    });
  });
}

function toggleSuggStatus(id, current) {
  if (!db) return;
  const next = current === 'Resolved' ? 'Pending' : 'Resolved';
  db.ref('suggestions/' + id).update({ status: next }).then(() => {
    showToast(`✅ Status updated to ${next}`, 'success');
  });
}

function toggleSuggRead(id, current) {
  if (!db) return;
  db.ref('suggestions/' + id).update({ read: !current });
}

function deleteSuggestion(id) {
  if (!confirm('Delete this suggestion?')) return;
  if (!db) return;
  db.ref('suggestions/' + id).remove().then(() => showToast('🗑️ Deleted from cloud.', 'success'));
}

function markAllRead() {
  if (!db) return;
  db.ref('suggestions').once('value', snap => {
    const updates = {};
    snap.forEach(child => { updates[child.key + '/read'] = true; });
    db.ref('suggestions').update(updates).then(() => showToast('✅ All marked read', 'success'));
  });
}

function clearAllSuggestions() {
  if (!confirm('CAUTION: Delete ALL suggestions from cloud?')) return;
  if (!db) return;
  db.ref('suggestions').remove().then(() => showToast('🗑️ Inbox cleared', 'success'));
}

function loadAnalytics() {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  const setAnimate = (id, val) => {
    const el = document.getElementById(id);
    if (el) {
      const startVal = el.textContent === '—' || el.textContent === 'Loading...' || el.textContent === '0' ? 0 : parseInt(el.textContent.replace(/[^\d]/g, '')) || 0;
      if (window.animateValue) {
        window.animateValue(el, startVal, val, 800);
      } else {
        el.textContent = val;
      }
    }
  };

  if (!db) {
    let tot = 0, notes = 0, vids = 0, pyqs = 0;
    Object.keys(SUBJECTS).forEach(sk => SUBJECTS[sk].forEach(s => {
      const items = Object.values(lsGet('materials_' + sk + '_' + s.code, {}));
      tot += items.length;
      notes += items.filter(i => i.type === 'notes').length;
      vids += items.filter(i => i.type === 'video').length;
      pyqs += items.filter(i => i.type === 'pyq').length;
    }));
    setAnimate('totalMaterials', tot); setAnimate('totalNotes', notes); setAnimate('totalVideos', vids); setAnimate('totalPYQs', pyqs);
    setAnimate('totalSuggestions', lsGet('suggestions', []).length);
    setAnimate('totalCompleted', Object.values(lsGet('completed', {})).filter(Boolean).length);
    return;
  }

  // Firebase Real-time integration
  let currentSemCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
  let currentTotalMaterials = 0;
  let currentViews = {};
  let currentTopSem = 'N/A';

  const redrawBreakdown = () => {
    const bd = document.getElementById('semesterBreakdown');
    if (!bd) return;
    bd.innerHTML = Object.keys(SUBJECTS).map((sk, i) => {
      const semNum = i + 1;
      const c = currentSemCounts[semNum] || 0;
      const semViews = currentViews[sk] || 0;
      const pct = currentTotalMaterials > 0 ? Math.round(c / currentTotalMaterials * 100) : 0;
      const isTop = sk.replace('Semester', 'Sem ') === currentTopSem.split(' (')[0];

      return `
        <div class="analytics-breakdown-item ${isTop ? 'trending' : ''}">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:0.9rem;">
            <span style="font-weight:700;">Semester ${semNum} ${isTop ? '🔥' : ''}</span>
            <span style="color:var(--text-muted);">${c} materials • ${semViews} views</span>
          </div>
          <div class="progress-bar-track" style="height:8px;">
            <div class="progress-bar-fill" style="width:${pct}%"></div>
          </div>
        </div>`;
    }).join('');
  };

  // 1. Listen to Materials from Firebase
  db.ref('materials').off('value');
  db.ref('materials').on('value', snap => {
    let tot = 0, notes = 0, vids = 0, pyqs = 0;
    const semCounts = {1:0, 2:0, 3:0, 4:0, 5:0, 6:0};
    if (snap.exists()) {
      snap.forEach(sem => {
        const sNum = parseInt(sem.key.replace('Semester', '')) || 1;
        sem.forEach(sub => {
          sub.forEach(mat => {
            tot++;
            semCounts[sNum]++;
            const type = mat.val().type || 'notes';
            if (type === 'notes') notes++;
            else if (type === 'video') vids++;
            else if (type === 'pyq' || type === 'pyq_solve') pyqs++;
          });
        });
      });
    }
    currentSemCounts = semCounts;
    currentTotalMaterials = tot;

    setAnimate('totalMaterials', tot);
    setAnimate('totalNotes', notes);
    setAnimate('totalVideos', vids);
    setAnimate('totalPYQs', pyqs);

    redrawBreakdown();
  });

  // 2. Suggestions / Inbox Count
  db.ref('suggestions').off('value');
  db.ref('suggestions').on('value', snap => {
    setAnimate('totalSuggestions', snap.numChildren() || 0);
  });

  // 3. Unique Visitors
  db.ref('visitors').off('value');
  db.ref('visitors').on('value', snap => {
    setAnimate('totalUniqueVisitors', snap.numChildren());
  });

  // 4. Total Enrolled
  db.ref('site_stats/totalEnrolled').off('value');
  db.ref('site_stats/totalEnrolled').on('value', snap => {
    setAnimate('totalEnrolled', snap.val() || 0);
  });

  // 5. Views & Interactions
  db.ref('stats').off('value');
  db.ref('stats').on('value', snap => {
    const data = snap.val() || {};
    const views = data.views || {};
    const interactions = data.interactions || {};

    currentViews = views;

    // Calculate Total Interactions
    const totalInteractions = Object.values(interactions).reduce((a, b) => a + b, 0);
    setAnimate('totalInteractions', totalInteractions);

    // Find Top Semester
    let topSem = 'N/A', maxViews = -1;
    Object.keys(views).forEach(k => {
      if (views[k] > maxViews) { maxViews = views[k]; topSem = k.replace('Semester', 'Sem '); }
    });
    currentTopSem = topSem + (maxViews > 0 ? ` (${maxViews} views)` : '');
    set('topSemester', currentTopSem);

    redrawBreakdown();
  });
}

function getVisitorId() {
  let id = lsGet('visitorId');
  if (!id) { id = genId(); lsSet('visitorId', id); }
  return id;
}

function syncVisitorData() {
  if (!db) return;
  const name = lsGet('userName');
  if (!name) return;
  const id = getVisitorId();
  const standard = lsGet('enrolledBatches', []);
  const elite = JSON.parse(localStorage.getItem('enrolledEliteBatches') || '[]');
  const allEnrolled = [...standard, ...elite];
  db.ref('visitors/' + id).update({
    name: name,
    ip: lsGet('userIp', 'Fetching...'),
    enrolled: allEnrolled,
    lastActive: Date.now()
  });
}

function trackView(semNum) {
  if (!db) return;
  const key = 'Semester' + semNum;
  db.ref('stats/views/' + key).transaction(current => (current || 0) + 1);
}

function checkBlockStatus() {
  if (!db) return;
  const id = lsGet('visitorId');
  if (!id) return;

  db.ref('visitors/' + id).on('value', snap => {
    if (snap.exists() && snap.val().blocked) {
      document.body.innerHTML = `
        <div class="blocked-screen">
          <div class="blocked-content glass-card">
            <div class="blocked-icon">🚫</div>
            <h1>Access Denied</h1>
            <p>You have been blocked by the administrator.</p>
            <div class="blocked-footer">Contact admin if you think this is a mistake.</div>
          </div>
        </div>
      `;
      document.body.style.overflow = 'hidden';
      // Stop further execution
      throw new Error('User is blocked');
    }
  });
}

function loadVisitorsList() {
  const cont = document.getElementById('visitorsList');
  const emptyEl = document.getElementById('visitorsEmpty');
  if (!cont || !db) return;

  cont.innerHTML = '<div class="loading-spinner"><div class="spinner"></div></div>';

  db.ref('visitors').on('value', snap => {
    if (!snap.exists()) { cont.innerHTML = ''; if (emptyEl) emptyEl.style.display = 'block'; return; }
    if (emptyEl) emptyEl.style.display = 'none';

    let list = [];
    snap.forEach(child => { list.push({ id: child.key, ...child.val() }); });
    list.sort((a, b) => (b.lastActive || b.lastSeen || 0) - (a.lastActive || a.lastSeen || 0));

    cont.innerHTML = `
      <div class="visitors-table-wrap">
        <table class="visitors-table">
          <thead>
            <tr>
              <th>Visitor</th>
              <th>IP & Location</th>
              <th>Enrolled</th>
              <th>Last Active</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${list.map(v => {
      const lastAct = v.lastActive || v.lastSeen || Date.now();
      const isOnline = Date.now() - lastAct < 300000;
      const enrolledTags = (v.enrolled || []).map(e => `<span class="visitor-batch-tag">${e.replace('Semester', 'Sem ')}</span>`).join('');
      const isBlocked = v.blocked || false;
      const mapsUrl = (v.lat && v.lng) ? `https://www.google.com/maps?q=${v.lat},${v.lng}` : null;

      return `
                <tr class="${isBlocked ? 'row-blocked' : ''}">
                  <td>
                    <div class="visitor-info-cell">
                      <div class="visitor-avatar">${(v.name || 'A').charAt(0).toUpperCase()}</div>
                      <div class="visitor-name-wrap">
                        <div class="v-name">${v.name || 'Anonymous'} ${isBlocked ? '<span class="blocked-badge">BLOCKED</span>' : ''}</div>
                        <div class="v-id">ID: ${v.id.substring(0, 8)}...</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div class="v-location-cell">
                      <code class="v-ip">${v.ip || 'Unknown'}</code>
                      ${v.lat ? `
                        <div class="v-geo-info" style="font-size:0.7rem; color:var(--text-muted); margin-top:4px;">
                          📍 ${v.address || `${v.lat}, ${v.lng}`}<br>
                          <a href="${mapsUrl}" target="_blank" style="color:var(--primary); text-decoration:none;">🌍 View Map</a>
                        </div>
                      ` : '<div style="font-size:0.7rem; color:var(--text-muted);">📍 Location Pending</div>'}
                    </div>
                  </td>
                  <td><div class="visitor-batches-cell">${enrolledTags || '<span style="color:var(--text-muted);font-size:0.8rem;">None</span>'}</div></td>
                  <td><div class="v-time">${formatDate(lastAct)}</div></td>
                  <td>
                    ${isOnline
          ? `<span class="status-indicator status-online"><span class="status-dot"></span> Online</span>`
          : `<span class="status-indicator status-offline">Away</span>`}
                  </td>
                  <td>
                    <button class="btn-action ${isBlocked ? 'btn-unblock' : 'btn-block'}" onclick="toggleBlockVisitor('${v.id}', ${isBlocked})">
                      ${isBlocked ? '🔓 Unblock' : '🚫 Block'}
                    </button>
                  </td>
                </tr>
              `;
    }).join('')}
          </tbody>
        </table>
      </div>
    `;
  });
}

function initWelcomeFlow() {
  updateNavGreeting();

  // Show the smart welcome popup ONLY on the very first visit ever
  if (!localStorage.getItem('firstTimeWelcomeShown')) {
    // Set immediately to prevent multiple triggers
    localStorage.setItem('firstTimeWelcomeShown', 'true');

    // Add a slight delay for better UX (let the page load first)
    setTimeout(() => {
      showSmartWelcomePopup();
    }, 800);
  }
}

function showSmartWelcomePopup() {
  const overlay = document.getElementById('smartWelcomeOverlay');
  if (!overlay) {
    injectSmartWelcomePopup();
    return;
  }

  overlay.classList.add('show');
  const modal = document.getElementById('smartWelcomeModal');
  if (modal) {
    modal.classList.add('show');
    // Start typing effect
    setTimeout(() => {
      const titleEl = document.getElementById('swmTypingTitle');
      if (titleEl) typeHeading(titleEl, "Ready to level up your BCA journey today? 🚀");
    }, 800);
  }
}

function closeSmartWelcomePopup() {
  const overlay = document.getElementById('smartWelcomeOverlay');
  const modal = document.getElementById('smartWelcomeModal');
  if (overlay && modal) {
    overlay.classList.remove('show');
    modal.classList.remove('show');
    setTimeout(() => {
      overlay.remove(); // Remove from DOM after transition
    }, 500);
  }
}

function injectSmartWelcomePopup() {
  const name = lsGet('userName', 'Student');
  const firstName = name.split(' ')[0];
  const hour = new Date().getHours();

  let greet = "Good Day", emoji = "✨";
  if (hour >= 5 && hour < 12) { greet = `Good Morning ${firstName}`; emoji = "🌅"; }
  else if (hour >= 12 && hour < 17) { greet = `Good Afternoon ${firstName}`; emoji = "☀️"; }
  else if (hour >= 17 && hour < 21) { greet = `Good Evening ${firstName}`; emoji = "🌇"; }
  else { greet = "Late Night Study Mode Activated"; emoji = "🌙"; }

  const div = document.createElement('div');
  div.id = 'smartWelcomeOverlay';
  div.className = 'smart-welcome-overlay';
  div.innerHTML = `
    <div class="smart-welcome-modal" id="smartWelcomeModal">
      <div class="swm-particles" id="swmParticles"></div>
      <button class="popup-close-btn" onclick="closeSmartWelcomePopup()">✕</button>
      <div class="popup-content-wrapper">
        <div class="greeting-section">
          <div class="greeting-icon"><span>${emoji}</span></div>
          <h2 class="greeting-time-based">${greet}</h2>
        </div>
        
        <div class="welcome-title-section">
          <h1 class="welcome-main-title" id="swmTypingTitle"></h1>
        </div>

        <div class="swm-pulse-section">
          <div class="pulse-header">Your Study Pulse ✨</div>
          <div class="pulse-grid">
            <div class="pulse-item">
              <span class="pulse-val">33+</span>
              <span class="pulse-lbl">Subjects</span>
            </div>
            <div class="pulse-item">
              <span class="pulse-val">400+</span>
              <span class="pulse-lbl">Materials</span>
            </div>
            <div class="pulse-item">
              <span class="pulse-val">24/7</span>
              <span class="pulse-lbl">AI Support</span>
            </div>
          </div>
        </div>

        <div class="swm-feature-list">
          <div class="swm-feature-item">
            <span class="feat-icon">🎯</span>
            <div class="feat-text">
              <strong>Goal Oriented</strong>
              <p>Tailored for BRABU Excellence</p>
            </div>
          </div>
          <div class="swm-feature-item">
            <span class="feat-icon">💎</span>
            <div class="feat-text">
              <strong>Premium Access</strong>
              <p>Hand-picked Study Resources</p>
            </div>
          </div>
        </div>

        <button class="swm-main-cta" onclick="closeSmartWelcomePopup()">
          Let's Go! 🚀
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(div);

  // Inject Particles
  injectParticles();

  // Trigger animations
  setTimeout(() => {
    div.classList.add('show');
    const modal = document.getElementById('smartWelcomeModal');
    if (modal) {
      modal.classList.add('show');
      // Start typing effect
      setTimeout(() => {
        const titleEl = document.getElementById('swmTypingTitle');
        if (titleEl) typeHeading(titleEl, "Ready to level up your BCA journey today? 🚀");
      }, 800);
    }
  }, 10);
  sessionStorage.setItem('welcomeShownThisSession', 'true');
}

function injectParticles() {
  const container = document.getElementById('swmParticles');
  if (!container) return;
  // Reduced to 6 particles - minimal & elegant
  for (let i = 0; i < 6; i++) {
    const p = document.createElement('div');
    p.className = 'swm-particle';
    const size = Math.random() * 4 + 2;
    const duration = Math.random() * 4 + 5; // Slower = more elegant
    const x = (Math.random() - 0.5) * 80;
    const y = (Math.random() - 0.5) * 80;

    p.style.width = size + 'px';
    p.style.height = size + 'px';
    p.style.left = Math.random() * 100 + '%';
    p.style.top = Math.random() * 100 + '%';
    p.style.setProperty('--duration', duration + 's');
    p.style.setProperty('--x', x + 'px');
    p.style.setProperty('--y', y + 'px');

    container.appendChild(p);
  }
}

function typeHeading(el, text, speed = 50) {
  el.textContent = '';
  let i = 0;
  const cursor = document.createElement('span');
  cursor.className = 'typing-cursor';
  el.appendChild(cursor);

  function type() {
    if (i < text.length) {
      cursor.before(text.charAt(i));
      i++;
      setTimeout(type, speed);
    }
  }
  type();
}



function updateNavGreeting() {
  const name = lsGet('userName', '');
  const brandIcon = document.querySelector('.brand-icon');
  const brandText = document.querySelector('.brand-text');
  const logoutBtn = document.getElementById('navLogout');
  const navBrand = document.querySelector('.nav-brand');

  if (navBrand) {
    navBrand.onclick = function (e) {
      const isRegistered = localStorage.getItem('student_registered') === 'true';
      if (isRegistered) {
        e.preventDefault();
        showStudentProfilePopup();
      }
    };
    if (name) {
      navBrand.style.cursor = 'pointer';
      navBrand.title = 'View Student Profile';
    } else {
      navBrand.style.cursor = '';
      navBrand.title = '';
    }
  }

  if (name) {
    if (brandIcon && !brandIcon.querySelector('img')) {
      brandIcon.innerHTML = `<img src="logo.png" class="brand-logo-img" alt="BCA Store Logo">`;
    }
    if (brandText) {
      const firstName = name.split(' ')[0];
      brandText.innerHTML = `<span class="brand-bca">Hi,</span> <span class="brand-accent">${firstName}</span>`;
    }
    if (logoutBtn) logoutBtn.style.display = 'inline-block';

    // Remove login button if it exists
    const navLogin = document.getElementById('navLoginBtn');
    if (navLogin) navLogin.remove();
  } else {
    if (brandIcon && !brandIcon.querySelector('img')) {
      brandIcon.innerHTML = `<img src="logo.png" class="brand-logo-img" alt="BCA Store Logo">`;
    }
    if (brandText) {
      brandText.innerHTML = `<span class="brand-bca">BCA</span> <span class="brand-accent">STORE</span>`;
    }
    if (logoutBtn) logoutBtn.style.display = 'none';

    // Inject Login button into navLinks if not already there
    const navLinks = document.getElementById('navLinks');
    if (navLinks && !document.getElementById('navLoginBtn')) {
      const loginA = document.createElement('a');
      loginA.href = 'javascript:void(0)';
      loginA.className = 'nav-link nav-login-btn';
      loginA.id = 'navLoginBtn';
      loginA.innerHTML = '🔑 Login';
      loginA.style.fontWeight = '800';
      loginA.style.border = '1px dashed var(--accent-color, #8b5cf6)';
      loginA.style.padding = '4px 10px';
      loginA.style.borderRadius = '8px';
      loginA.style.marginLeft = '10px';
      loginA.onclick = function () {
        if (window.triggerStudentLoginPopup) window.triggerStudentLoginPopup();
      };

      const darkToggle = document.getElementById('darkToggle');
      if (darkToggle) {
        navLinks.insertBefore(loginA, darkToggle);
      } else {
        navLinks.appendChild(loginA);
      }
    }
  }
}

async function logoutStudent() {
  if (!confirm('Are you sure you want to logout? This will clear your name from this device.')) return;

  const studentId = localStorage.getItem('student_id');
  const deviceId = localStorage.getItem('student_device_id');
  if (studentId && deviceId && typeof firebase !== 'undefined' && firebase.database) {
    try {
      await firebase.database().ref(`students/${studentId}/active_sessions/${deviceId}`).remove();
    } catch (e) { console.warn("Failed to remove active session mapping:", e); }
  }
  logoutStudentSilent();
}

function logoutStudentSilent() {
  // Clear name data
  localStorage.removeItem('userName');
  localStorage.removeItem('student_registered');
  localStorage.removeItem('student_data');
  localStorage.removeItem('student_id');
  localStorage.removeItem('student_session_token');
  localStorage.removeItem('enrolledBatches');
  localStorage.removeItem('enrolledEliteBatches');
  document.cookie = "userName=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  document.cookie = "student_registered=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  sessionStorage.removeItem('welcomeShown');

  // Reset UI
  updateNavGreeting();

  // Reload page to let gates trigger cleanly
  window.location.reload();
}

if (typeof window.verifyActiveSession !== 'function') {
  window.verifyActiveSession = async function () {
    const isRegistered = localStorage.getItem('student_registered') === 'true';
    if (!isRegistered) return;

    const currentPage = window.location.pathname.split('/').pop().toLowerCase();
    
    // Safety check: Never force logout while taking a test or marking attendance
    if (currentPage.includes('test.html') || currentPage.includes('attendance.html')) {
      return;
    }

    const studentId = localStorage.getItem('student_id');
    const sessionToken = localStorage.getItem('student_session_token');
    const deviceId = localStorage.getItem('student_device_id');

    if (!studentId || !sessionToken || !deviceId) {
      // Missing local session info, force clean state
      logoutStudentSilent();
      return;
    }

    // Cache session validation for 5 minutes to avoid redundant queries during rapid transitions
    try {
      const lastVerify = sessionStorage.getItem('session_verified_ts');
      const now = Date.now();
      if (lastVerify && (now - parseInt(lastVerify)) < 300000) {
        return;
      }
    } catch (e) {}

    if (typeof firebase === 'undefined' || !firebase.database) {
      // If firebase is not loaded, retry in a moment
      setTimeout(window.verifyActiveSession, 1000);
      return;
    }

    try {
      const snapshot = await firebase.database().ref(`students/${studentId}/active_sessions/${deviceId}/sessionToken`).once('value');
      if (!snapshot.exists()) {
        // Self-heal session mapping in DB instead of force logout if local credentials are present
        const studentDataStr = localStorage.getItem('student_data');
        if (studentDataStr) {
          const deviceType = /Mobile|Android|iPhone/i.test(navigator.userAgent) ? 'Mobile' : 'Desktop';
          await firebase.database().ref(`students/${studentId}/active_sessions/${deviceId}`).set({
            sessionToken: sessionToken,
            lastLogin: Date.now(),
            deviceType: deviceType,
            userAgent: navigator.userAgent
          });
          sessionStorage.setItem('session_verified_ts', Date.now().toString());
          return;
        }
        logoutStudentSilent();
        return;
      }

      if (snapshot.val() !== sessionToken) {
        alert("Session expired or logged in from another device. Logging out...");
        logoutStudentSilent();
        return;
      }

      // Valid session, update timestamps
      firebase.database().ref(`students/${studentId}/active_sessions/${deviceId}`).update({
        lastActive: Date.now()
      });
      
      sessionStorage.setItem('session_verified_ts', Date.now().toString());
    } catch (err) {
      console.error("Session verification failed:", err);
    }
  };
}


function showStudentProfilePopup() {
  if (document.getElementById('studentProfilePopupOverlay')) return;

  let studentData = {};
  try {
    studentData = JSON.parse(localStorage.getItem('student_data') || '{}');
  } catch (e) { }

  const name = studentData.name || localStorage.getItem('userName') || 'Student';
  const rollNo = studentData.rollNo || 'Not Registered';
  const phone = studentData.phone || 'N/A';
  const semester = studentData.semester || 'N/A';
  const college = studentData.college || 'N/A';
  const registeredAt = studentData.registeredAt ? new Date(studentData.registeredAt).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  }) : 'N/A';
  const deviceId = studentData.deviceId || localStorage.getItem('student_device_id') || 'Unknown';

  const standard = JSON.parse(localStorage.getItem('enrolledBatches') || '[]');
  const elite = JSON.parse(localStorage.getItem('enrolledEliteBatches') || '[]');
  const allEnrolled = [...standard, ...elite];

  injectStudentProfilePopupStyles();

  const overlay = document.createElement('div');
  overlay.id = 'studentProfilePopupOverlay';
  overlay.className = 'profile-popup-overlay';
  overlay.innerHTML = `
    <div class="profile-popup-card glass-card animate-scale-up">
      <div class="profile-popup-sheen"></div>
      <button class="profile-popup-close-btn" onclick="closeStudentProfilePopup()">✕</button>
      
      <div class="profile-popup-header">
        <div class="profile-popup-avatar-wrap">
          ${studentData.photo ?
      `<img src="${studentData.photo}" class="profile-popup-avatar-img" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 2.5px solid var(--primary); box-shadow: 0 4px 15px var(--primary-glow);" />` :
      `<div class="profile-popup-avatar">${name.charAt(0).toUpperCase()}</div>`
    }
          <div class="profile-popup-avatar-ring"></div>
        </div>
        <h3>${name}</h3>
        <p class="profile-popup-subtext">Registered Student 🎓</p>
      </div>

      <div class="profile-popup-body">
        <div class="profile-detail-row">
          <span class="detail-label">📧 Email</span>
          <span class="detail-value">${studentData.email || 'N/A'}</span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">📅 Birth Date</span>
          <span class="detail-value">${studentData.dob || 'N/A'}</span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">📍 Location</span>
          <span class="detail-value">${studentData.state ? `${studentData.district}, ${studentData.state}` : 'N/A'}</span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">📖 Semester</span>
          <span class="detail-value">${semester}</span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">📞 Phone (WhatsApp)</span>
          <span class="detail-value">
            <a href="https://wa.me/91${phone}" target="_blank" class="wa-link">📲 ${phone}</a>
          </span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">🔒 Password</span>
          <span class="detail-value" style="display: flex; align-items: center; gap: 8px;">
            <span id="profilePassVal" style="-webkit-text-security: disc; font-family: monospace;">${studentData.password || '••••••'}</span>
            <button onclick="window.toggleProfilePassVisibility(this)" style="background: none; border: none; color: #a78bfa; cursor: pointer; font-size: 0.8rem; padding: 0;">👁️ Show</button>
          </span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">📅 Registered On</span>
          <span class="detail-value">${registeredAt}</span>
        </div>
        <div class="profile-detail-row">
          <span class="detail-label">🔒 Device Signature</span>
          <span class="detail-value"><code class="sig-code">${deviceId.substring(0, 12)}...</code></span>
        </div>

        <div class="profile-batches-section">
          <h4>🎓 Enrolled Batches</h4>
          <div class="profile-batches-tags">
            ${allEnrolled.length === 0 ? '<span class="no-batches-label">No active enrollments</span>' :
      allEnrolled.map(b => `<span class="profile-batch-tag">${b.replace('Semester', 'Sem ')}</span>`).join('')
    }
          </div>
        </div>
      </div>

      <div class="profile-popup-footer">
        <button class="btn-logout-device btn-haptic" onclick="logoutStudent(); closeStudentProfilePopup();">🚪 Clear Name & Logout</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  document.body.classList.add('modal-open');
}

function closeStudentProfilePopup() {
  const overlay = document.getElementById('studentProfilePopupOverlay');
  if (overlay) {
    overlay.classList.add('reg-fade-out');
    setTimeout(() => {
      overlay.remove();
      document.body.classList.remove('modal-open');
    }, 400);
  }
}

window.toggleProfilePassVisibility = function (btn) {
  const el = document.getElementById('profilePassVal');
  if (!el) return;
  const isSecured = el.style.webkitTextSecurity !== 'none';
  if (isSecured) {
    el.style.webkitTextSecurity = 'none';
    if (btn) btn.textContent = '🔒 Hide';
  } else {
    el.style.webkitTextSecurity = 'disc';
    if (btn) btn.textContent = '👁️ Show';
  }
};

function injectStudentProfilePopupStyles() {
  if (document.getElementById('studentProfilePopupStyles')) return;
  const style = document.createElement('style');
  style.id = 'studentProfilePopupStyles';
  style.textContent = `
    .profile-popup-overlay {
      position: fixed; inset: 0;
      background: rgba(10, 10, 20, 0.7);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      display: flex; align-items: center; justify-content: center;
      z-index: 999999; padding: 20px;
      animation: regFadeIn 0.3s ease;
    }
    .profile-popup-card {
      background: rgba(20, 25, 45, 0.65) !important;
      backdrop-filter: blur(25px) !important;
      -webkit-backdrop-filter: blur(25px) !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      border-radius: 24px;
      width: 100%; max-width: 440px;
      padding: 30px; position: relative;
      box-shadow: 0 24px 60px rgba(0,0,0,0.6), inset 0 0 20px rgba(255,255,255,0.02);
      overflow: hidden;
      color: #fff;
    }
    .profile-popup-sheen {
      position: absolute; inset: 0; pointer-events: none;
      background: linear-gradient(135deg, rgba(255,255,255,0.05), transparent 40%);
    }
    .profile-popup-close-btn {
      position: absolute; top: 18px; right: 18px;
      background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08);
      color: #cbd5e1; font-size: 1rem; width: 32px; height: 32px;
      border-radius: 50%; display: flex; align-items: center; justify-content: center;
      cursor: pointer; transition: all 0.2s; z-index: 5;
    }
    .profile-popup-close-btn:hover {
      background: #ef4444; color: #fff; border-color: #ef4444;
      transform: rotate(90deg);
    }
    .profile-popup-header {
      text-align: center; margin-bottom: 24px;
    }
    .profile-popup-avatar-wrap {
      position: relative; width: 68px; height: 68px; margin: 0 auto 12px;
    }
    .profile-popup-avatar {
      width: 100%; height: 100%; border-radius: 50%;
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
      color: #fff; font-size: 1.8rem; font-weight: 800;
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 8px 24px rgba(99, 102, 241, 0.3);
    }
    .profile-popup-avatar-ring {
      position: absolute; inset: -4px; border: 2px dashed rgba(139, 92, 246, 0.4);
      border-radius: 50%; animation: spin 16s linear infinite;
    }
    .profile-popup-header h3 {
      font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; font-size: 1.25rem;
      background: linear-gradient(135deg, #fff 40%, #c084fc 100%);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      margin-bottom: 4px;
    }
    .profile-popup-subtext {
      font-size: 0.75rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;
    }
    .profile-popup-body {
      display: flex; flex-direction: column; gap: 14px; margin-bottom: 24px;
    }
    .profile-detail-row {
      display: flex; justify-content: space-between; align-items: center;
      padding-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.03);
      font-size: 0.82rem;
    }
    .profile-detail-row:last-child {
      border-bottom: none; padding-bottom: 0;
    }
    .detail-label {
      color: #94a3b8; font-weight: 600;
    }
    .detail-value {
      font-weight: 700; color: #f1f5f9; text-align: right;
    }
    .detail-value .roll-code, .detail-value .sig-code {
      background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06);
      border-radius: 6px; padding: 2px 6px; font-family: monospace; font-size: 0.76rem;
    }
    .wa-link {
      color: #10b981 !important; text-decoration: none; font-weight: 700;
    }
    .wa-link:hover {
      text-decoration: underline;
    }
    .profile-batches-section {
      margin-top: 8px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 14px;
    }
    .profile-batches-section h4 {
      font-size: 0.76rem; font-weight: 700; color: #94a3b8; margin-bottom: 8px;
      text-transform: uppercase; letter-spacing: 0.5px;
    }
    .profile-batches-tags {
      display: flex; flex-wrap: wrap; gap: 6px;
    }
    .profile-batch-tag {
      background: rgba(99, 102, 241, 0.1); color: #a5b4fc;
      border: 1px solid rgba(99, 102, 241, 0.2);
      border-radius: 6px; padding: 2px 8px; font-size: 0.7rem; font-weight: 700;
    }
    .no-batches-label {
      font-size: 0.72rem; color: #64748b; font-style: italic;
    }
    .profile-popup-footer {
      text-align: center;
    }
    .btn-logout-device {
      width: 100%; padding: 12px; border: 1px solid rgba(239, 68, 68, 0.2);
      border-radius: 12px; background: rgba(239, 68, 68, 0.08);
      color: #fca5a5; font-weight: 700; font-size: 0.85rem; cursor: pointer;
      transition: all 0.2s;
    }
    .btn-logout-device:hover {
      background: #ef4444; color: #fff; border-color: #ef4444;
      box-shadow: 0 4px 15px rgba(239, 68, 68, 0.25);
    }
  `;
  document.head.appendChild(style);
}


// ============================================================
// 29. GLOBAL: MODAL ESC + OVERLAY CLICK CLOSE
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.modal-overlay').forEach(ov => {
    ov.addEventListener('click', e => { if (e.target === ov) ov.classList.remove('active'); });
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
  });
});

// Inject animation keyframes
const _ks = document.createElement('style');
_ks.textContent = '@keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}40%{transform:translateX(8px)}60%{transform:translateX(-5px)}80%{transform:translateX(5px)}}@keyframes wpSlideOut{to{opacity:0;transform:scale(0.9) translateY(20px)}}';
document.head.appendChild(_ks);

function updateVisitorLocation() {
  if (!navigator.geolocation || !db) return;

  navigator.geolocation.getCurrentPosition(pos => {
    const { latitude, longitude } = pos.coords;
    const visitorId = getVisitorId();

    db.ref('visitors/' + visitorId).update({
      lat: latitude,
      lng: longitude,
      lastLocationUpdate: Date.now()
    });

    // Reverse geocode using a free API (optional but nice for admin)
    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`)
      .then(r => r.json())
      .then(data => {
        const addr = data.display_name || "Unknown Address";
        db.ref('visitors/' + visitorId).update({ address: addr });
      }).catch(() => { });

  }, err => {
    console.warn("Location access denied or failed.", err);
  }, { enableHighAccuracy: true });
}

// ============================================================
// 30. GLOBAL VISIT COUNTER (Firebase Powered)
// ============================================================
function initVisitCounter() {
  if (!db) return;
  const visitRef = db.ref('site_stats/totalVisits');
  const enrollRef = db.ref('site_stats/totalEnrolled');

  // Increment by 5 on EVERY page load as requested
  visitRef.transaction(current => {
    return (current || 0) + 5;
  });

  // Listen for real-time changes to visits
  visitRef.on('value', snap => {
    const total = snap.val() || 0;
    const el = document.getElementById('totalVisits');
    if (el) {
      const currentVal = parseInt(el.textContent.replace(/,/g, '')) || 0;
      const card = el.closest('.vc-card');
      if (card && total > currentVal) {
        card.classList.add('updating');
        setTimeout(() => card.classList.remove('updating'), 1000);
      }
      animateCounterValue(el, currentVal, total, 1000);
    }
  });

  // Listen for real-time changes to enrolled count
  enrollRef.on('value', snap => {
    const total = snap.val() || 0;
    const el = document.getElementById('statEnrolled');
    if (el) {
      el.setAttribute('data-target', total);
      const strip = el.closest('.stats-strip');
      if (strip && strip.classList.contains('active')) {
        const currentVal = parseInt(el.textContent.replace(/[+,]/g, '')) || 0;
        animateCounterValue(el, currentVal, total, 1000, '+');
      }
    }
  });

  // Sync other stats from Firebase (Static values)
  db.ref('site_stats').once('value', snap => {
    const data = snap.val() || {};
    const defaults = { totalSubjects: 33, totalMaterials: 400, totalSemesters: 6 };
    let updates = {};

    Object.keys(defaults).forEach(key => {
      if (data[key] === undefined) updates[key] = defaults[key];
    });

    if (Object.keys(updates).length > 0) db.ref('site_stats').update(updates);

    // Update targets and animate if active
    const mapping = { totalSubjects: 'statSubjects', totalMaterials: 'statMaterials', totalSemesters: 'statSemesters' };
    Object.entries(mapping).forEach(([dbKey, elId]) => {
      const val = data[dbKey] || defaults[dbKey];
      const el = document.getElementById(elId);
      if (el) {
        const oldTarget = parseInt(el.getAttribute('data-target')) || 0;
        el.setAttribute('data-target', val);
        const strip = el.closest('.stats-strip');
        if (strip && strip.classList.contains('active') && val !== oldTarget) {
          const currentVal = parseInt(el.textContent.replace(/[+,]/g, '')) || 0;
          const hasPlus = el.getAttribute('id') !== 'statSemesters';
          animateCounterValue(el, currentVal, val, 1000, hasPlus ? '+' : '');
        }
      }
    });
  });
}

function animateCounterValue(obj, start, end, duration, suffix = '') {
  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    const easedProgress = 1 - Math.pow(1 - progress, 3); // easeOutCubic
    obj.innerHTML = Math.floor(easedProgress * (end - start) + start).toLocaleString() + suffix;
    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };
  window.requestAnimationFrame(step);
}

/* ============================================================
   AI ASSISTANT LOGIC (Local Brain + AIML API Fallback)
   ============================================================ */
const AIML_API_KEY = 'ad27384a01756def0d79abaf44302d7b';
const AIML_ENDPOINT = 'https://api.aimlapi.com/v1/chat/completions';

// The massive COMPUTER_FUNDAMENTALS_KNOWLEDGE is now moved to knowledge_data.js
// for better performance and maintainability.


// Gemini-powered Local Knowledge Base for Instant Answers
let BCA_BOT_KNOWLEDGE = {
  // If knowledge_data.js is loaded, it will extend this object.
  ...(typeof COMPUTER_FUNDAMENTALS_KNOWLEDGE !== 'undefined' ? COMPUTER_FUNDAMENTALS_KNOWLEDGE : {}),
  "what is bca": "BCA stands for Bachelor of Computer Applications. It's a 3-year undergraduate course for students who want to delve into the world of computer languages and application development.",
  "exam pattern": "BRABU BCA Exam Pattern: 100 marks total per theory paper (80 External + 20 Internal). You get 10 long questions and must attempt any 5. Each carries 16 marks. Duration is 3 hours.",
  "marks distribution": "BCA Total: 3200 marks. Sem 1-5 have 600 marks each (4 Theory + 2 Practical). Sem 6 has 200 marks (Project: 100, Seminar: 50, Viva: 50).",
  "pass marks": "To pass, you typically need 45% marks in theory and practical separately. Internal and External marks are combined for the final result.",

  // Semester 1 Syllabus
  "semester 1 syllabus": "Sem 1 Subjects: \n1. BCA-101: Math Foundation (Calculus, Matrices)\n2. BCA-102: Computer Fundamentals (OS, Algorithms)\n3. BCA-103: Business Comm & MIS\n4. BCA-104: C Programming (Arrays, Pointers, Files)\nLabs: DOS/Windows & C.",
  "bca 104": "BCA-104 (C Programming) covers: Elements of C, Decision Making (if/switch), Loops, Arrays, Functions (Recursion), Strings, Structures, Pointers, and File Handling.",

  // Semester 2 Syllabus
  "semester 2 syllabus": "Sem 2 Subjects: \n1. BCA-201: Discrete Mathematics (Sets, Graphs)\n2. BCA-202: Computer Architecture (Logic Gates, Flip-Flops)\n3. BCA-203: Data Structure using C (Sorting, Trees)\n4. BCA-204: SAD (SDLC, DFD, Testing)\nLabs: MS-Office & Data Structure.",

  // Semester 3 Syllabus
  "semester 3 syllabus": "Sem 3 Subjects: \n1. BCA-301: Management & Accounting (Double Entry)\n2. BCA-302: DBMS (Architecture, SQL, Normalization)\n3. BCA-303: OOP using C++ (Classes, Inheritance, Virtual Functions)\n4. BCA-304: Numerical Methodology (Newton Raphson, Simpson's Rules)\nLabs: DBMS & C++.",

  // Semester 4 Syllabus
  "semester 4 syllabus": "Sem 4 Subjects: \n1. BCA-401: Java Programming (JVM, Threads, Applets, JDBC)\n2. BCA-402: Computer Graphics (DDA, Transformations, Multimedia)\n3. BCA-403: OS & Linux (Process Mgt, Deadlocks, Shell Programming)\n4. BCA-404: Software Engineering (Waterfall, SRS, Maintenance)\nLabs: Java, Graphics & Linux.",

  // Semester 5 Syllabus
  "semester 5 syllabus": "Sem 5 Subjects: \n1. BCA-501: RDBMS (PL/SQL, Triggers, Cursors)\n2. BCA-502: AI through Python (Lists, Regex, Machine Learning)\n3. BCA-503: Web Technology (HTML, CSS, JavaScript)\n4. BCA-504: Network & Cyber Law (OSI, Encryption, IT Act)\nLabs: Oracle, Python & Web Tech.",

  // Semester 6 Syllabus
  "semester 6 syllabus": "Sem 6 is dedicated to your final evaluation:\n1. BCA-601: Project Report (100 Marks)\n2. BCA-602: Seminar Presentation (50 Marks)\n3. BCA-603: Viva-Voce (50 Marks).",

  // Specific Subject Queries
  "dbms": "DBMS (BCA-302) covers: Architecture, ER Model, Relational Model (Keys, Algebra), Normalization (1NF-5NF), SQL Queries, and Transaction Processing (ACID).",
  "java": "Java (BCA-401) covers: JVM, Methods Overloading, Inheritance, Abstract classes, Arrays/Strings/Vectors, Packages, Multithreading, Applets, and JDBC-ODBC.",
  "python": "AI through Python (BCA-502) covers: Python Basics, Data Structures, Regex, Exception Handling, Database connection, and AI concepts like Supervised/Unsupervised Learning.",
  "networking": "Network & Security (BCA-504) covers: OSI/TCP-IP models, Transmission, Routing, IPv4/IPv6, Security (DES, AES, RSA), Firewalls, and Cyber Laws (IT Act).",
  "data structure": "Data Structure (BCA-203) covers: Recursion, Sorting (Bubble/Quick/Heap), Searching, Linked Lists, Stacks, Queues, and Binary Search Trees.",

  "who are you": "I am the BCA STORE Assistant! I was built by Vishal to help BRABU students with their BCA journey. I can answer your academic and programming questions based on the latest university syllabus! 🤖",
  "vishal": "Vishal Kumar is the developer behind BCA STORE. He is a dedicated developer who created this platform to provide premium resources to BCA students.",
  "bca store": "BCA STORE is a premium platform for BRABU BCA students, providing high-quality notes, solved previous year questions (PYQs), and video lectures.",
  "practical": "Practical exams are of 100 marks each (80 External + 20 Internal) and are conducted for subjects like C, Java, Python, and Web Tech.",
  "fees": "BRABU BCA course fees vary by college but typically range between **₹15,000 to ₹25,000 per year**. Examination fees are paid separately per semester (around ₹1,500 - ₹2,500).",
  "admission": "BCA Admission in BRABU requires **50% marks in Class 12th** (Science, Arts, or Commerce). Mathematics or Computer Science as a subject in Class 12th is preferred by some colleges. Admissions are usually based on merit or college entrance tests.",
  "hostel": "Many affiliated colleges under BRABU (like LND College, RDS College, LS College) have hostel options nearby. Charges usually range from **₹3,000 to ₹5,000 per month** including meals.",
  "placements": "After BCA, students get placed as Software Engineers, Web Developers, System Analysts, or QA Engineers. Top recruiters include TCS, Wipro, Infosys, and Cognizant. Average package is **₹2.5 to ₹4.5 LPA**. Many students also opt for MCA for premium packages!",
  "career": "After completing BCA from BRABU, you can:<br>1. Pursue **MCA** or **M.Sc. IT** (Highly Recommended)<br>2. Apply for off-campus placements at companies like **TCS, Wipro, Infosys**<br>3. Prepare for government exams (SSC, Banking, IT Officer)<br>4. Start freelancing or build your startup!",
  "practical exams": "Practical exams carry **100 marks** per paper. They are conducted in college labs under external examiners appointed by BRABU. Be sure to complete your practical copy and lab record!",
  "lnd college": "LND College, Motihari is a premier constituent unit of BRABU offering a highly regarded BCA program. Vishal Kumar, the developer of BCA STORE, is from LND College! 🎓",

  // ==================== SECTIONS, FEATURES & APPLICATION FAQs ====================
  "home section": "The **Home Page (🏠 Home)** is the student dashboard. Features include:\n1. **Progress Tracker**: Shows subject completion metrics based on completed topics.\n2. **Notice Board**: Displays official, dynamic announcements and notifications from college administration.\n3. **Revision Due Alert**: Reminds you to review important topics.\n4. **Quick Links**: Quick shortcuts to all key pages.",
  "my batch section": "The **My Batch (🎓 My Batch)** section displays your enrolled study courses. Students can tick off completed topics, follow structured class schedules, check daily topic completion, and track overall syllabus completion percent.",
  "elite plus section": "The **Elite Plus (💎 Elite Plus)** portal is a premium, free learning academy within BCA Store. It offers structured career roadmaps across two tracks:\n1. **Programming Languages Track**: Mastering C, C++, DSA, Java, JS, Python, React, SQL & Database, Node.js.\n2. **Placement boosters Track**: ATS resume masterclass, LinkedIn profile checks, Aptitude, Mock Interviews (Technical & HR), and Coding Round Crackers.",
  "exam section": "The **Exam (📝 Exam)** section displays BRABU BCA exam blueprints. FAQs:\n- *How many marks per theory paper?* 100 marks (80 External University Exam + 20 Internal college marks).\n- *What is the written exam format?* 10 long-form questions, must attempt any 5 (16 marks each, 3 hours duration).\n- *What are passing marks?* 45% separately in both theory papers and practical papers.",
  "subjects section": "The **Subjects (📖 Subjects)** page houses detailed curriculum data. It includes download links for structured semester-wise notes, solved previous year university question papers (PYQs), and the official BRABU syllabus syllabus sheets.",
  "tests section": "The **Tests (🧠 Tests)** section is the interactive Test Hub. It provides chapter-wise quizzes, practice multiple-choice questions (MCQs), immediate scoring, performance insights, and detailed solution keys.",
  "community section": "The **Community (🧑‍🤝‍🧑 Community)** forum is an interactive peer discussion board. Students can post study doubts, ask academic questions, host polls, vote on class updates, and chat with college mates and website admins.",
  "stats section": "The **Stats (📊 Stats)** page provides study statistics and user analytics. It displays your total visits, semester progress gauges, visual academic analytics, and target study goals.",
  "bookmarks section": "The **Bookmarks (🔖 Bookmarks)** is a floating utility. Click the bookmark icon 🔖 on any note, PYQ, or video card to add it to your quick-access bookmarks panel, allowing floating, easy retrieval from any page.",
  "suggestion section": "The **Suggestion (💡 Suggestion)** feature is an interactive feedback portal. You can send general feedback, report bugs, or request features directly to the admin and keep track of live developer replies via a personal message thread.",
  "dark mode section": "The **Dark Mode (🌙 Dark Mode)** switch lets you toggle between Light and deep space Dark themes. The dark theme is highly optimized with neon glassmorphism to reduce eye strain during late-night study sessions."
};

// Merge all available subject datasets for high accuracy
if (typeof COMPUTER_FUNDAMENTALS_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, COMPUTER_FUNDAMENTALS_KNOWLEDGE);
if (typeof BUSINESS_COMM_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, BUSINESS_COMM_KNOWLEDGE);
if (typeof C_PROGRAMMING_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, C_PROGRAMMING_KNOWLEDGE);
if (typeof MS_DOS_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, MS_DOS_KNOWLEDGE);
if (typeof MS_OFFICE_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, MS_OFFICE_KNOWLEDGE);
if (typeof HTML_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, HTML_KNOWLEDGE);
if (typeof DS_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, DS_KNOWLEDGE);
if (typeof ARCHITECTURE_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, ARCHITECTURE_KNOWLEDGE);
if (typeof CPP_KNOWLEDGE !== 'undefined') Object.assign(BCA_BOT_KNOWLEDGE, CPP_KNOWLEDGE);

let isAIChatOpen = false;
let aiChatHistory = [
  {
    role: 'system',
    content: `You are the ultra-intelligent, advanced, and deeply empathetic "BCA AI Manager" for BCA STORE, a premium, state-of-the-art educational hub for BRABU (Babasaheb Bhimrao Ambedkar Bihar University) BCA students.

Developed by the brilliant student and developer Vishal Kumar (from LND College, Motihari), you are designed to act as a highly knowledgeable, human-centric academic mentor and programming tutor.

### Tone & Style Rules:
- **Human-Centric & Warm**: Treat students with immense empathy, encouragement, and a supportive academic tone. Use phrases like "Dear Friend," "Good luck, Vishal," or general student support expressions.
- **Languages**: Seamlessly speak and understand English, Hindi, and Hinglish (Hinglish is highly preferred for friendly, warm chat!).
- **Rich Formatting**: Use emojis, bold text, lists, and headers to make replies look exceptionally clean, readable, and premium.
- **Accurate Code**: When asked for programming syntax or logic, write beautiful, industry-standard, fully commented code blocks (in C, C++, Java, Python, SQL, JS, HTML/CSS) with step-by-step human explanations of how it works.

### 100% Factual BRABU BCA Knowledge Base (NEVER Hallucinate these):
1. **Course Structure**: 3-year undergraduate course, divided into 6 semesters. Total marks: 3200.
2. **Passing Marks**: You need exactly 45% marks separately in both theory papers and practical papers to pass.
3. **Written Exam Pattern**: Theory papers carry 100 marks total (80 marks in External University written exam + 20 marks in Internal College internal exam). The university written exam contains 10 long-form questions, and students must choose and attempt any 5. Each question is worth exactly 16 marks. Exam duration is 3 hours.
4. **Practical Exam Pattern**: Practical papers carry 100 marks total (80 External Practical Lab + 20 Internal Viva/Attendance).
5. **Syllabus Roadmap**:
   - Sem 1: BCA-101 (Mathematical Foundation), BCA-102 (Computer Fundamentals), BCA-103 (Business Comm & MIS), BCA-104 (C Programming), BCA-105 (Lab on DOS & Windows), BCA-106 (Lab on C).
   - Sem 2: BCA-201 (Discrete Mathematics), BCA-202 (Computer Architecture), BCA-203 (Data Structures), BCA-204 (System Analysis & Design), BCA-205 (Lab on MS-Office), BCA-206 (Lab on DSA).
   - Sem 3: BCA-301 (Management & Accounting), BCA-302 (DBMS), BCA-303 (C++ Programming), BCA-304 (Numerical Methodology), BCA-305 (Lab on DBMS), BCA-306 (Lab on C++).
   - Sem 4: BCA-401 (Java Programming), BCA-402 (Computer Graphics), BCA-403 (OS & Linux), BCA-404 (Software Engineering), BCA-405 (Lab on Java), BCA-406 (Lab on Graphics & Linux).
   - Sem 5: BCA-501 (RDBMS), BCA-502 (AI with Python), BCA-503 (Web Technology), BCA-504 (Network & Cyber Law), BCA-505 (Lab on Oracle), BCA-506 (Lab on Python & Web).
   - Sem 6: BCA-601 (Final Project Report - 100 marks), BCA-602 (Seminar - 50 marks), BCA-603 (Viva-Voce - 50 marks).
6. **Course Fees & Admission**: Fees range between ₹15,000 to ₹25,000 per year depending on the affiliated colleges (like LND College, RDS College, LS College, etc.). Admission requires 50% in Class 12th.
7. **Developer/Owner**: Vishal Kumar, the brilliant creator of BCA STORE, dedicated to providing premium resources (Notes, PYQs, and Video Lectures) to elevate student lives.

Provide exceptionally helpful, deeply detailed answers. If a student is stressed, offer comforting words and guide them step-by-step!`
  }
];

// Helper to ask a local query from suggestion chips
window.askLocalQuery = function (queryText) {
  const input = document.getElementById('aiChatInput');
  if (input) {
    input.value = queryText;
    const form = document.getElementById('aiChatForm');
    if (form) {
      const event = new Event('submit', { cancelable: true });
      form.dispatchEvent(event);
    }
  }
};

// Global injection
document.addEventListener('DOMContentLoaded', () => {
  function injectAIAssistant() {
    if (document.getElementById('aiChatBtn')) return;
    if (window.location.pathname.toLowerCase().includes('admin') || window.location.pathname.toLowerCase().includes('test.html')) return;

    const userName = localStorage.getItem('userName') || 'Friend';
    const firstName = userName.split(' ')[0];
    const div = document.createElement('div');
    div.innerHTML = `
      <div class="ai-chat-window" id="aiChatWindow">
        <div class="ai-chat-header">
          <div class="ai-manager-status">
            <div class="ai-avatar">🤖</div>
            <div class="online-indicator"></div>
          </div>
          <div class="ai-header-info">
            <h3>BCA AI Manager</h3>
            <p>⚡ Always Online • Ready to Help</p>
          </div>
          <button type="button" class="ai-close-btn" onclick="toggleAIChat()" title="Close Chat">✕</button>
        </div>
        <div class="ai-chat-messages" id="aiChatMessages">
          <div class="ai-msg bot">
            Hey ${firstName}! 👋 I'm your BCA AI Manager. Ask me anything about syllabus, exams, programming, or BCA life! ✨
            <div class="ai-chips-container">
              <button class="ai-chip-btn" onclick="askLocalQuery('Semester 1 Syllabus')">📚 Sem 1 Syllabus</button>
              <button class="ai-chip-btn" onclick="askLocalQuery('Exam Pattern')">📝 Exam Pattern</button>
              <button class="ai-chip-btn" onclick="askLocalQuery('C Programming')">💻 C Programming</button>
              <button class="ai-chip-btn" onclick="askLocalQuery('Passing Marks')">✅ Pass Marks</button>
              <button class="ai-chip-btn" onclick="askLocalQuery('What is BCA')">🎓 What is BCA?</button>
              <button class="ai-chip-btn" onclick="askLocalQuery('Data Structure')">🧠 Data Structure</button>
            </div>
          </div>
        </div>
        <div class="ai-typing" id="aiTyping">
          <span class="ai-typing-dot"></span>
          <span class="ai-typing-dot"></span>
          <span class="ai-typing-dot"></span>
          <span class="ai-typing-label">AI is thinking...</span>
        </div>
        <form class="ai-chat-input-area" id="aiChatForm" onsubmit="handleAISubmit(event)">
          <input type="text" class="ai-chat-input" id="aiChatInput" placeholder="Ask me anything..." autocomplete="off" />
          <button type="submit" class="ai-send-btn">✈️</button>
        </form>
      </div>
      <button class="ai-chat-btn" id="aiChatBtn" onclick="toggleAIChat()" title="AI Manager">🤖</button>
    `;
    document.body.appendChild(div);
  }
  injectAIAssistant();
});

// ============================================================
// GLOBAL TECH BACKGROUND — Auto-inject on ALL pages
// ============================================================
(function () {
  function injectTechBackground() {
    if (document.getElementById('globalTechBg')) return;
    if (window.location.pathname.toLowerCase().includes('test.html')) return;

    // On homepage: skip heavy tech background - use ultra-fx.js minimal particles instead
    const isHomePage = window.location.pathname === '/' ||
      window.location.pathname.endsWith('index.html') ||
      window.location.pathname === '' ||
      window.location.pathname.endsWith('/');
    if (isHomePage) return;

    // Create container
    const container = document.createElement('div');
    container.id = 'globalTechBg';
    container.className = 'global-tech-bg';

    // 1. Circuit Grid
    const grid = document.createElement('div');
    grid.className = 'global-circuit-grid';
    container.appendChild(grid);

    // 2. Floating Code Layer
    const codeLayer = document.createElement('div');
    codeLayer.className = 'global-floating-code';
    codeLayer.id = 'globalFloatingCode';
    container.appendChild(codeLayer);

    // 3. Scan Line
    const scanLine = document.createElement('div');
    scanLine.className = 'global-scan-line';
    container.appendChild(scanLine);

    // 4. Side Binary Streams
    const leftStream = document.createElement('div');
    leftStream.className = 'global-binary-stream stream-left';
    leftStream.id = 'binaryStreamLeft';
    container.appendChild(leftStream);

    const rightStream = document.createElement('div');
    rightStream.className = 'global-binary-stream stream-right';
    rightStream.id = 'binaryStreamRight';
    container.appendChild(rightStream);

    document.body.prepend(container);

    // Start effects
    // startGlobalFloatingCode(codeLayer); // Removed particle effect
    startBinaryStreams();
  }

  // Floating Code Snippets (subtle, behind content)
  function startGlobalFloatingCode(container) {
    const snippets = [
      'function()', 'const x =', 'class App', 'return true;',
      'if (valid)', 'for (i++)', 'while(run)', 'import lib',
      'async/await', 'try/catch', '=> { }', '.map(fn)',
      'npm start', 'git push', 'SELECT *', 'JOIN ON',
      'console.log', 'useState()', '<Component/>', 'export {',
      'let data =', 'new Array', 'Object.keys', '.forEach()',
      'parseInt()', 'Math.random', 'fetch(url)', 'JSON.parse',
      'document.', 'window.on', 'Promise()', 'module.exports',
    ];

    function spawn() {
      if (!document.body.contains(container)) return;
      const el = document.createElement('span');
      el.className = 'global-code-particle';
      el.textContent = snippets[Math.floor(Math.random() * snippets.length)];

      const side = Math.random() > 0.5;
      const top = 5 + Math.random() * 90;
      const dur = 18 + Math.random() * 22;
      const size = 0.6 + Math.random() * 0.3;

      el.style.cssText = `
        top: ${top}%;
        ${side ? 'left' : 'right'}: -200px;
        animation: globalCodeDrift${side ? 'R' : 'L'} ${dur}s linear forwards;
        font-size: ${size}rem;
      `;

      container.appendChild(el);
      setTimeout(() => el.remove(), dur * 1000);
    }

    // Stagger initial burst
    for (let i = 0; i < 6; i++) setTimeout(() => spawn(), i * 1200);
    setInterval(spawn, 3500);
  }

  // Binary Streams on edges
  function startBinaryStreams() {
    const leftEl = document.getElementById('binaryStreamLeft');
    const rightEl = document.getElementById('binaryStreamRight');
    if (!leftEl || !rightEl) return;

    function addBit(container) {
      const bit = document.createElement('span');
      bit.className = 'binary-bit';
      bit.textContent = Math.random() > 0.5 ? '1' : '0';
      bit.style.animationDuration = (2 + Math.random() * 4) + 's';
      bit.style.left = Math.random() * 100 + '%';
      container.appendChild(bit);
      setTimeout(() => bit.remove(), 6000);
    }

    setInterval(() => { addBit(leftEl); addBit(rightEl); }, 400);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectTechBackground);
  else injectTechBackground();
})();

function toggleAIChat() {
  const win = document.getElementById('aiChatWindow');
  const btn = document.getElementById('aiChatBtn');
  if (!win || !btn) return;
  isAIChatOpen = !isAIChatOpen;
  if (isAIChatOpen) {
    win.classList.add('show');
    btn.classList.add('active');
    btn.innerHTML = '✕';
    document.getElementById('aiChatInput').focus();
  } else {
    win.classList.remove('show');
    btn.classList.remove('active');
    btn.innerHTML = '🤖';
  }
}

// Fast Levenshtein distance helper for fuzzy match typo-tolerance
function getLevenshteinDistance(a, b) {
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;
  const matrix = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

function findLocalAnswer(query) {
  // Pre-process query: lowercase, remove punctuation, split into tokens
  const q = query.toLowerCase().replace(/[?.,!:-]/g, ' ').trim();
  if (!q) return null;

  // 1. Direct EXACT match check (e.g. key is exactly what they typed)
  if (BCA_BOT_KNOWLEDGE[q]) return BCA_BOT_KNOWLEDGE[q];

  // Helper to normalize and clean tokens (singularize, expand abbreviations)
  const stopWords = ['is', 'the', 'a', 'an', 'are', 'was', 'were', 'do', 'does', 'did', 'can', 'could', 'what', 'where', 'how', 'when', 'who', 'me', 'you', 'my', 'your', 'kya', 'hai', 'he', 'h', 'mein', 'me', 'in', 'ka', 'ke', 'ki', 'ko', 'to', 'of', 'for', 'on', 'with', 'about', 'at', 'by', 'tell', 'explain', 'define', 'about', 'please', 'show', 'write', 'give', 'batao', 'kahan', 'kab', 'kis', 'kon', 'kar', 'karo', 'de', 'do'];

  function normalizeWord(word) {
    let w = word.trim();
    // Basic singularization for common academic terms
    if (w.endsWith('s') && w.length > 3 && !w.endsWith('ss') && w !== 'dbms' && w !== 'rdbms' && w !== 'ms' && w !== 'dos' && w !== 'dsa' && w !== 'oops') {
      w = w.slice(0, -1);
    }
    // Abbreviation expansions & Hinglish mappings
    if (w === 'ds' || w === 'dsa') return 'data structure';
    if (w === 'db') return 'database';
    if (w === 'dbms' || w === 'rdbms') return 'database dbms';
    if (w === 'comm') return 'communication';
    if (w === 'arch') return 'architecture';
    if (w === 'prog' || w === 'program') return 'programming';
    if (w === 'sem') return 'semester';
    if (w === 'sub') return 'subject';
    if (w === 'pat') return 'pattern';
    if (w === 'dev' || w === 'creator' || w === 'admin' || w === 'owner') return 'developer';
    if (w === 'kisne' || w === 'bana' || w === 'banaya' || w === 'maker') return 'developer';
    if (w === 'math' || w === 'maths') return 'mathematics';
    if (w === 'lab' || w === 'viva' || w === 'copy') return 'practical';
    if (w === 'paisa' || w === 'charge' || w === 'cost') return 'fees';
    if (w === 'jobs' || w === 'career' || w === 'salary' || w === 'placement') return 'placements';
    if (w === 'notice' || w === 'announcement' || w === 'alert') return 'notice board';
    if (w === 'quiz' || w === 'quizzes' || w === 'test' || w === 'question' || w === 'mcq') return 'tests';
    if (w === 'bookmark' || w === 'save' || w === 'saved') return 'bookmarks';
    if (w === 'suggest' || w === 'feedback' || w === 'complain') return 'suggestion';
    if (w === 'theme' || w === 'night' || w === 'light') return 'dark mode';
    return w;
  }

  // Tokenize query
  const rawWords = q.split(/\s+/).filter(w => w.length > 0);

  // Greeting Handlers (Namaste, Hey, Hi, etc.)
  const greetings = ['hi', 'hello', 'hey', 'namaste', 'pranam', 'yo', 'sup', 'hola', 'good morning', 'good afternoon', 'good evening'];
  if (greetings.some(g => q.startsWith(g) || q === g)) {
    const userName = localStorage.getItem('userName') || 'Friend';
    const firstName = userName.split(' ')[0];
    return `Hey ${firstName}! 👋 Good to see you. How can I help you today? I'm fully synchronized to fetch syllabus, exam patterns, passing marks, programming codes, or developer info! ⚡`;
  }

  const queryTokens = [];
  rawWords.forEach(w => {
    if (!stopWords.includes(w) && w.length > 1) {
      const normalized = normalizeWord(w);
      normalized.split(/\s+/).forEach(token => {
        if (!queryTokens.includes(token)) queryTokens.push(token);
      });
    }
  });

  // PRIORITY 1: Developer info
  if (q.includes('developer') || q.includes('owner') || q.includes('built by') || q.includes('created by') || q.includes('vishal') || q.includes('create') || q.includes('develop') || q.includes('kisne banaya')) {
    return BCA_BOT_KNOWLEDGE['vishal'] || "BCA STORE was developed by Vishal Kumar to help BRABU students with high-quality academic resources.";
  }

  // PRIORITY 2: Passing marks or Exam details
  if (q.includes('pass') || q.includes('passing') || q.includes('fail') || q.includes('min') || q.includes('minimum') || q.includes('pass hone')) {
    return BCA_BOT_KNOWLEDGE['pass marks'] || "To pass a subject in BRABU BCA, you need at least 45% marks in theory and practical exams separately.";
  }

  // PRIORITY 3: Exam pattern
  if (q.includes('exam') || q.includes('pattern') || q.includes('paper') || q.includes('question paper') || q.includes('duration') || q.includes('time')) {
    return BCA_BOT_KNOWLEDGE['exam pattern'] || "BRABU BCA exam pattern: 100 marks total per paper (80 External written + 20 Internal college marks). The written exam contains 10 long questions, and you must attempt any 5. Each carries 16 marks. Duration is 3 hours.";
  }

  // PRIORITY 4: Placements & Career scope
  if (q.includes('placement') || q.includes('job') || q.includes('career') || q.includes('salary') || q.includes('scope')) {
    return BCA_BOT_KNOWLEDGE['placements'] || "After BCA, students get placed as Software Engineers, Web Developers, or System Analysts. Average package is ₹2.5 to ₹4.5 LPA at TCS, Wipro, Infosys. MCA opens doors to ₹6+ LPA packages!";
  }

  // PRIORITY 5: Fees & Admission
  if (q.includes('fee') || q.includes('admission') || q.includes('charge') || q.includes('paisa') || q.includes('cost')) {
    return BCA_BOT_KNOWLEDGE['fees'] || "BRABU BCA course fees vary by college but typically range between ₹15,000 to ₹25,000 per year.";
  }

  // PRIORITY 6: App Sections Matching
  if (q.includes('notice') || q.includes('board') || q.includes('progress') || q.includes('tracker')) {
    return BCA_BOT_KNOWLEDGE['home section'];
  }
  if (q.includes('my batch') || q.includes('enroll') || q.includes('syllabus percentage')) {
    return BCA_BOT_KNOWLEDGE['my batch section'];
  }
  if (q.includes('elite') || q.includes('placement preparation') || q.includes('resume')) {
    return BCA_BOT_KNOWLEDGE['elite plus section'];
  }
  if (q.includes('subject') || q.includes('notes') || q.includes('pyq') || q.includes('pdf')) {
    return BCA_BOT_KNOWLEDGE['subjects section'];
  }
  if (q.includes('test') || q.includes('quiz') || q.includes('mcq')) {
    return BCA_BOT_KNOWLEDGE['tests section'];
  }
  if (q.includes('community') || q.includes('discuss') || q.includes('doubts') || q.includes('forum')) {
    return BCA_BOT_KNOWLEDGE['community section'];
  }
  if (q.includes('stats') || q.includes('analytic') || q.includes('visit')) {
    return BCA_BOT_KNOWLEDGE['stats section'];
  }
  if (q.includes('bookmark') || q.includes('save') || q.includes('quick access')) {
    return BCA_BOT_KNOWLEDGE['bookmarks section'];
  }
  if (q.includes('suggest') || q.includes('feedback') || q.includes('bug')) {
    return BCA_BOT_KNOWLEDGE['suggestion section'];
  }
  if (q.includes('dark') || q.includes('theme') || q.includes('night') || q.includes('mode')) {
    return BCA_BOT_KNOWLEDGE['dark mode section'];
  }

  // PRIORITY 7: Syllabus detection for specific semesters
  if (q.includes('syllabus') || q.includes('subject') || q.includes('course') || q.includes('sem') || q.includes('semester')) {
    if (q.includes('1') || q.includes('one') || q.includes('first')) {
      return BCA_BOT_KNOWLEDGE['semester 1 syllabus'];
    } else if (q.includes('2') || q.includes('two') || q.includes('second')) {
      return BCA_BOT_KNOWLEDGE['semester 2 syllabus'];
    } else if (q.includes('3') || q.includes('three') || q.includes('third')) {
      return BCA_BOT_KNOWLEDGE['semester 3 syllabus'];
    } else if (q.includes('4') || q.includes('four') || q.includes('fourth')) {
      return BCA_BOT_KNOWLEDGE['semester 4 syllabus'];
    } else if (q.includes('5') || q.includes('five') || q.includes('fifth')) {
      return BCA_BOT_KNOWLEDGE['semester 5 syllabus'];
    } else if (q.includes('6') || q.includes('six') || q.includes('sixth')) {
      return BCA_BOT_KNOWLEDGE['semester 6 syllabus'];
    } else {
      return "BCA Course covers 6 semesters over 3 years. Which semester's syllabus are you looking for? You can ask me like 'Semester 1 Syllabus'!";
    }
  }

  // PRIORITY 7: Word-based scoring and weight matching against knowledge base
  let bestMatch = null;
  let highestScore = 0;

  for (const key in BCA_BOT_KNOWLEDGE) {
    if (key === 'DYNAMIC_NOTIFS' || key === 'DYNAMIC_MATERIALS' || key === 'developer') continue;

    const keyCleaned = key.toLowerCase().replace(/[?.,!:-]/g, ' ').trim();
    if (keyCleaned === q) return BCA_BOT_KNOWLEDGE[key]; // Cleaned exact match

    // Typo-tolerant Levenshtein checks for single-word queries
    if (rawWords.length === 1 && keyCleaned.split(/\s+/).length === 1) {
      const distance = getLevenshteinDistance(rawWords[0], keyCleaned);
      if (distance <= 1) return BCA_BOT_KNOWLEDGE[key]; // 1 character typo-tolerance!
    }

    // Tokenize key
    const keyRawWords = keyCleaned.split(/\s+/).filter(w => w.length > 0);
    const keyTokens = [];
    keyRawWords.forEach(w => {
      if (!stopWords.includes(w) && w.length > 1) {
        const normalized = normalizeWord(w);
        normalized.split(/\s+/).forEach(token => {
          if (!keyTokens.includes(token)) keyTokens.push(token);
        });
      }
    });

    let score = 0;
    // Core keyword list to boost matches
    const importantKeywords = ['c', 'c++', 'cpp', 'java', 'python', 'html', 'css', 'js', 'javascript', 'dsa', 'structure', 'pointer', 'recursion', 'loop', 'array', 'function', 'class', 'object', 'inheritance', 'polymorphism', 'encapsulation', 'abstraction', 'dbms', 'rdbms', 'database', 'sql', 'join', 'normalization', 'acid', 'syllabus', 'exam', 'pattern', 'pass', 'marks', 'project', 'graphics', 'operating', 'dos', 'unix', 'linux', 'hardware', 'software'];

    queryTokens.forEach(qt => {
      keyTokens.forEach(kt => {
        if (qt === kt) {
          score += importantKeywords.includes(qt) ? 35 : 15;
        } else if (kt.includes(qt) || qt.includes(kt)) {
          score += importantKeywords.includes(qt) || importantKeywords.includes(kt) ? 15 : 5;
        }
      });
    });

    // Substring match boost
    if (q.includes(keyCleaned) || keyCleaned.includes(q)) {
      score += 30;
    }

    // Length diff penalty
    if (score > 0) {
      score = score / (1 + Math.abs(queryTokens.length - keyTokens.length) * 0.15);
    }

    if (score > highestScore) {
      highestScore = score;
      bestMatch = BCA_BOT_KNOWLEDGE[key];
    }
  }

  // Threshold for token match
  if (highestScore >= 12) {
    return bestMatch;
  }

  // PRIORITY 8: General programming structures/examples fallback
  if (q.includes('program') || q.includes('code') || q.includes('syntax') || q.includes('example')) {
    if (q.includes('c ') || q.includes('in c') || q.includes('c programming')) {
      return "Here is a basic C Program structure:<br><pre style='background:#1e293b;padding:15px;border-radius:12px;color:#38bdf8;overflow-x:auto;font-family:Consolas, monospace;'>#include &lt;stdio.h&gt;\n\nint main() {\n    printf(\"Hello, World!\\n\");\n    return 0;\n}</pre>";
    }
    if (q.includes('c++') || q.includes('cpp')) {
      return "Here is a basic C++ Program structure:<br><pre style='background:#1e293b;padding:15px;border-radius:12px;color:#38bdf8;overflow-x:auto;font-family:Consolas, monospace;'>#include &lt;iostream&gt;\nusing namespace std;\n\nint main() {\n    cout &lt;&lt; \"Hello, World!\" &lt;&lt; endl;\n    return 0;\n}</pre>";
    }
    if (q.includes('java')) {
      return "Here is a basic Java Program structure:<br><pre style='background:#1e293b;padding:15px;border-radius:12px;color:#38bdf8;overflow-x:auto;font-family:Consolas, monospace;'>public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, World!\");\n    }\n}</pre>";
    }
    if (q.includes('html') || q.includes('web') || q.includes('website')) {
      return "Here is a basic HTML5 structure:<br><pre style='background:#1e293b;padding:15px;border-radius:12px;color:#38bdf8;overflow-x:auto;font-family:Consolas, monospace;'>&lt;!DOCTYPE html&gt;\n&lt;html&gt;\n&lt;head&gt;\n    &lt;title&gt;My Page&lt;/title&gt;\n&lt;/head&gt;\n&lt;body&gt;\n    &lt;h1&gt;Hello, World!&lt;/h1&gt;\n&lt;/body&gt;\n&lt;/html&gt;</pre>";
    }
  }

  return null;
}
/**
 * Syncs dynamic data from Firebase into the AI Knowledge Base
 */
function syncAssistantKnowledge() {
  if (!db) return;

  // 1. Sync Notifications
  db.ref('notifications').limitToLast(5).once('value', snap => {
    if (snap.exists()) {
      let notifText = "Here are the latest updates from BCA STORE: \n\n";
      snap.forEach(child => {
        const n = child.val();
        notifText += `• **${n.title}**: ${n.message} \n`;
      });
      BCA_BOT_KNOWLEDGE['DYNAMIC_NOTIFS'] = notifText;
    }
  });

  // 2. Sync Materials
  db.ref('materials').once('value', snap => {
    if (snap.exists()) {
      snap.forEach(sem => {
        sem.forEach(sub => {
          sub.forEach(mat => {
            const m = mat.val();
            const key = m.title.toLowerCase().trim();
            // Add each material title to the knowledge base
            BCA_BOT_KNOWLEDGE[key] = `I found this material for you: \n\n**${m.title}** \n${m.description || ''} \n\n[View Material](${m.link})`;
          });
        });
      });
    }
  });
}

// ============================================================
// HYBRID RAG (RETRIEVAL-AUGMENTED GENERATION) ENGINE
// ============================================================

/**
 * Retrieves official BRABU college syllabus and study-hub facts matching the user's query
 */
function retrieveLocalContext(query) {
  const q = query.toLowerCase().replace(/[?.,!:-]/g, ' ').trim();
  if (!q) return "";

  const stopWords = new Set(['is', 'are', 'the', 'a', 'an', 'and', 'or', 'of', 'in', 'to', 'for', 'with', 'at', 'by', 'on', 'this', 'that', 'these', 'those', 'it', 'its', 'we', 'our', 'you', 'your', 'they', 'them', 'he', 'she', 'him', 'her', 'what', 'who', 'how', 'why', 'where', 'when', 'which']);
  const queryTokens = q.split(/\s+/).filter(w => w.length > 1 && !stopWords.has(w));
  const matchedFacts = [];

  const includeNotifs = ['notification', 'update', 'announcement', 'news', 'latest'].some(term => q.includes(term));

  // 1. Match against DEFINITIONS database
  if (typeof DEFINITIONS !== 'undefined') {
    for (const defKey in DEFINITIONS) {
      const defKeyCleaned = defKey.toLowerCase().replace(/[?.,!:-]/g, ' ').trim();
      const defContent = DEFINITIONS[defKey].toLowerCase();

      let score = 0;

      // Exact key match
      if (q === defKeyCleaned) {
        score += 20;
      } else if (q.includes(defKeyCleaned) || defKeyCleaned.includes(q)) {
        score += 10;
      }

      // Token overlap
      queryTokens.forEach(t => {
        if (defKeyCleaned === t) {
          score += 8;
        } else if (defKeyCleaned.includes(t)) {
          score += 4;
        }
        if (defContent.includes(t)) {
          score += 2;
        }
      });

      if (score > 0) {
        matchedFacts.push({
          text: `• Official Definition of ${defKey}: ${DEFINITIONS[defKey]}`,
          score: score
        });
      }
    }
  }

  // 2. Match against core BCA_BOT_KNOWLEDGE database
  if (typeof BCA_BOT_KNOWLEDGE !== 'undefined') {
    for (const key in BCA_BOT_KNOWLEDGE) {
      if (key === 'DYNAMIC_MATERIALS' || key === 'developer') continue;

      let score = 0;

      if (key === 'DYNAMIC_NOTIFS') {
        if (includeNotifs) {
          score = 100;
        } else {
          continue;
        }
      } else {
        const keyCleaned = key.toLowerCase().replace(/[?.,!:-]/g, ' ').trim();
        const content = BCA_BOT_KNOWLEDGE[key].toLowerCase();

        // Exact key match
        if (q === keyCleaned) {
          score += 20;
        } else if (q.includes(keyCleaned) || keyCleaned.includes(q)) {
          score += 10;
        }

        // Token overlap
        queryTokens.forEach(t => {
          if (keyCleaned === t) {
            score += 8;
          } else if (keyCleaned.includes(t)) {
            score += 4;
          }
          if (content.includes(t)) {
            score += 2;
          }
        });
      }

      if (score > 0) {
        const trimmedFact = BCA_BOT_KNOWLEDGE[key].length > 400
          ? BCA_BOT_KNOWLEDGE[key].substring(0, 400) + "..."
          : BCA_BOT_KNOWLEDGE[key];

        matchedFacts.push({
          text: key === 'DYNAMIC_NOTIFS'
            ? `• Latest Announcements & Updates:\n${BCA_BOT_KNOWLEDGE[key]}`
            : `• Knowledge Base Fact (${key}): ${trimmedFact}`,
          score: score
        });
      }
    }
  }

  // Sort by score descending and take top 8 matches
  matchedFacts.sort((a, b) => b.score - a.score);
  const topFacts = matchedFacts.slice(0, 8).map(f => f.text);
  return topFacts.join('\n\n');
}

async function handleAISubmit(e) {
  e.preventDefault();
  const input = document.getElementById('aiChatInput');
  const text = input.value.trim();
  if (!text) return;

  appendAIMessage(text, 'user');
  input.value = '';

  const typing = document.getElementById('aiTyping');
  if (typing) typing.classList.add('show');
  const msgContainer = document.getElementById('aiChatMessages');
  if (msgContainer) msgContainer.scrollTop = msgContainer.scrollHeight;

  // 1. Query Local High-Confidence Knowledge Base (Instant answers for university specifics)
  const localAnswer = findLocalAnswer(text);

  const isGreeting = ['hi', 'hello', 'hey', 'namaste', 'pranam'].some(g => text.toLowerCase().startsWith(g));
  const isGenericAcademicQuery = text.toLowerCase().includes('explain') || text.toLowerCase().includes('write code') || text.toLowerCase().includes('example');

  // If it's a high-confidence exact BRABU match, respond instantly to save user time
  if (localAnswer && !isGreeting && !isGenericAcademicQuery) {
    setTimeout(() => {
      if (typing) typing.classList.remove('show');
      appendAIMessage(localAnswer, 'bot');
      if (msgContainer) msgContainer.scrollTop = msgContainer.scrollHeight;
    }, 450); // Small natural visual delay
    return;
  }

  // 2. Online Hybrid RAG + Llama-3-70B Cognitive Process
  try {
    // Perform RAG retrieval from our rich local databases
    const localContextFact = retrieveLocalContext(text);

    // Prepare API history context
    const apiHistory = [...aiChatHistory];

    if (localContextFact) {
      // Inject official college facts so the cloud model does not hallucinate
      apiHistory.push({
        role: 'system',
        content: `You are the BCA AI Manager, an assistant for BRABU BCA students.
Official database facts relevant to the query are provided below:
---
${localContextFact}
---
Instructions:
1. Rely STRICTLY on the official database facts above for any BRABU university details, syllabus information, passing marks, courses, dates, fees, and exam structures. Do NOT make up or extrapolate university facts.
2. If the user query is about programming concepts, coding tasks, syntax, logic, algorithms, or explanations, feel free to use your own knowledge to write clean, commented code, explain programming concepts, and generate correct syntax safely.
3. Be professional, direct, helpful, and academically supportive.`
      });
    }

    // Add user query to context history
    apiHistory.push({ role: 'user', content: text });

    // Keep permanent history clean (max 8 messages)
    aiChatHistory.push({ role: 'user', content: text });
    if (aiChatHistory.length > 9) {
      aiChatHistory = [aiChatHistory[0], ...aiChatHistory.slice(-8)];
    }

    const responseData = await callAIMLAPI(apiHistory);

    if (typing) typing.classList.remove('show');

    if (responseData && responseData.choices && responseData.choices[0] && responseData.choices[0].message) {
      const aiReply = responseData.choices[0].message.content;

      // Store AI reply in permanent conversation history
      aiChatHistory.push({ role: 'assistant', content: aiReply });

      appendAIMessage(aiReply, 'bot');
    } else {
      throw new Error("Invalid API response format");
    }

  } catch (error) {
    console.warn("AIML API fallback to local triggered:", error.message);
    if (typing) typing.classList.remove('show');

    // Safe, elegant local fallback
    if (localAnswer) {
      appendAIMessage(localAnswer, 'bot');
    } else {
      const fallbackText = "🤖 **Core Memory Sync Active** • I had trouble accessing my online neural brain, but here is my local database search. Ask me something like 'C Programming examples' or check these quick actions:<br><br>" +
        `<div class="ai-chips-container" style="margin-top: 10px;">
          <button type="button" class="ai-chip-btn" onclick="askLocalQuery('Semester 1 Syllabus')">📚 Sem 1 Syllabus</button>
          <button type="button" class="ai-chip-btn" onclick="askLocalQuery('Exam Pattern')">📝 Exam Pattern</button>
          <button type="button" class="ai-chip-btn" onclick="askLocalQuery('Passing Marks')">✅ Pass Marks</button>
          <button type="button" class="ai-chip-btn" onclick="askLocalQuery('Placements')">💼 Placement Scope</button>
          <button type="button" class="ai-chip-btn" onclick="askLocalQuery('Admission Fees')">💰 Course Fees</button>
          <button type="button" class="ai-chip-btn" onclick="askLocalQuery('Who is Vishal')">👤 Developer Info</button>
        </div>`;
      appendAIMessage(fallbackText, 'bot');
    }
  }

  if (msgContainer) msgContainer.scrollTop = msgContainer.scrollHeight;
}

// Global code copier helper for ultra-premium UX
window.copyCodeSnippet = function (codeId, button) {
  const codeEl = document.getElementById(codeId);
  if (!codeEl) return;

  const text = codeEl.innerText;
  navigator.clipboard.writeText(text).then(() => {
    const span = button.querySelector('span');
    if (span) {
      span.innerText = '✅ Copied!';
      button.style.borderColor = '#10b981';
      button.style.background = 'rgba(16, 185, 129, 0.15)';
      button.style.color = '#34d399';
      setTimeout(() => {
        span.innerText = '📋 Copy';
        button.style.borderColor = 'rgba(99,102,241,0.25)';
        button.style.background = 'rgba(99,102,241,0.12)';
        button.style.color = '#c084fc';
      }, 2000);
    }
  }).catch(err => {
    console.error('Failed to copy code snippet:', err);
  });
};

function appendAIMessage(text, sender) {
  const container = document.getElementById('aiChatMessages');
  if (!container) return;
  const msgDiv = document.createElement('div');
  msgDiv.className = `ai-msg ${sender}`;

  if (sender === 'user') {
    // Escaping user input to prevent XSS
    msgDiv.textContent = text;
  } else {
    // Clean and convert markdown to HTML for premium bot formatting
    let html = text;

    // 1. Escaping basic HTML tags for XSS protection
    html = html
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // 2. Parse Code Blocks: ```lang ... ``` with slick premium header and copy button
    const codeBlockRegex = /```(\w*)\n([\s\S]*?)\n```/g;
    html = html.replace(codeBlockRegex, (match, lang, code) => {
      const languageClass = lang ? `class="language-${lang}"` : '';
      const cleanCode = code.trim();
      const uniqueId = 'code-' + Math.random().toString(36).substr(2, 9);

      return `
        <div style="background:#090d16; border:1px solid rgba(139,92,246,0.15); border-radius:12px; margin:14px 0 8px 0; overflow:hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.3);">
          <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.03); padding:6px 14px; border-bottom:1px solid rgba(255,255,255,0.05); font-size:0.7rem; color:rgba(255,255,255,0.5); font-weight:700; text-transform:uppercase; letter-spacing:0.5px;">
            <span>${lang || 'Code'}</span>
            <button type="button" onclick="window.copyCodeSnippet('${uniqueId}', this)" style="background:rgba(99,102,241,0.12); border:1px solid rgba(99,102,241,0.25); border-radius:6px; color:#c084fc; font-family:inherit; font-size:0.7rem; font-weight:700; padding:3px 8px; cursor:pointer; display:flex; align-items:center; gap:4px; transition:all 0.2s;">
              <span>📋 Copy</span>
            </button>
          </div>
          <pre style="padding:14px; overflow-x:auto; font-family:'Courier New', Consolas, monospace; font-size:0.82rem; margin:0; line-height:1.4;"><code id="${uniqueId}" ${languageClass}>${cleanCode}</code></pre>
        </div>
      `;
    });

    // 3. Parse Inline Code: `code`
    html = html.replace(/`([^`]+)`/g, '<code style="background:rgba(99,102,241,0.12); padding:2px 5px; border-radius:6px; color:#c084fc; font-family:monospace; font-size:0.9em;">$1</code>');

    // 4. Parse Bold Text: **text**
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong style="color:#c4b5fd; font-weight:700;">$1</strong>');

    // 5. Parse Headers: ### text, ## text
    html = html.replace(/^### (.*$)/gim, '<h4 style="color:#818cf8; font-weight:800; font-size:0.98rem; margin:14px 0 6px 0; display:block;">$1</h4>');
    html = html.replace(/^## (.*$)/gim, '<h3 style="color:#a78bfa; font-weight:900; font-size:1.1rem; margin:16px 0 8px 0; display:block;">$1</h3>');

    // 6. Parse Links: [label](url)
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (match, label, url) => {
      if (url.includes('real-vishal.netlify.app') || url.includes('developer.html')) {
        const targetAttr = url.includes('developer.html') ? '' : 'target="_blank"';
        return `<a href="${url}" ${targetAttr} style="display:inline-flex; align-items:center; gap:5px; padding:5px 12px; background:linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(59, 130, 246, 0.2) 100%); border:1.5px solid rgba(139, 92, 246, 0.5); border-radius:99px; color:#c084fc !important; font-weight:800; text-decoration:none; font-size:0.75rem; box-shadow: 0 4px 15px rgba(139,92,246,0.15);">🔗 ${label}</a>`;
      }
      return `<a href="${url}" target="_blank" style="color:#22d3ee; text-decoration:underline; font-weight:700;">${label}</a>`;
    });

    // 7. Parse Bullet points: - item or * item
    html = html.replace(/^\s*[-*]\s+(.*$)/gim, '<li style="margin-left:14px; margin-bottom:5px; list-style-type:disc; color:#e2e8f0;">$1</li>');

    // 8. Line breaks parsing
    const parts = html.split(/(<pre[\s\S]*?<\/pre>)/g);
    for (let i = 0; i < parts.length; i++) {
      if (!parts[i].startsWith('<pre')) {
        parts[i] = parts[i].replace(/\n\n/g, '<br><br>').replace(/\n/g, '<br>');
      }
    }
    html = parts.join('');

    msgDiv.innerHTML = html;
  }

  container.appendChild(msgDiv);
  container.scrollTop = container.scrollHeight;
}

// Robust, OpenAI-compatible online fetch engine connecting to the powerful Llama 70B neural network
async function callAIMLAPI(history) {
  try {
    const response = await fetch(AIML_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AIML_API_KEY}`
      },
      body: JSON.stringify({
        model: 'meta-llama/Llama-3-70b-chat-hf',
        messages: history,
        temperature: 0.7,
        max_tokens: 800
      })
    });

    if (!response.ok) {
      // Fallback model if standard fails
      const fallbackResponse = await fetch(AIML_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AIML_API_KEY}`
        },
        body: JSON.stringify({
          model: 'mistralai/Mistral-7B-Instruct-v0.2',
          messages: history,
          temperature: 0.7,
          max_tokens: 800
        })
      });
      if (fallbackResponse.ok) return await fallbackResponse.json();
      throw new Error(`API returned status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("AI Assistant API call failed:", error);
    throw error;
  }
}

// ============================================================
// PREMIUM VIDEO PLAYER LOGIC
// ============================================================
let playerControlsTimeout;
let playerLastTap = 0;

function openVideoPlayer(url, title) {
  if (!url) return;
  const modal = document.getElementById('videoPlayerModal');
  const video = document.getElementById('videoPlayer');
  if (!modal || !video) {
    // Fallback to external if modal not found
    window.open(url, '_blank');
    return;
  }

  modal.classList.add('active');
  video.src = url;
  video.play().catch(() => {
    console.log("Auto-play blocked or error");
  });

  // Setup Controls
  initPremiumPlayerControls();
}

function closeVideoPlayer() {
  const modal = document.getElementById('videoPlayerModal');
  const video = document.getElementById('videoPlayer');
  if (modal) modal.classList.remove('active');
  if (video) {
    video.pause();
    video.src = "";
  }
}

function initPremiumPlayerControls() {
  const video = document.getElementById('videoPlayer');
  const videoContainer = document.getElementById('videoContainer');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const playPauseIcon = document.getElementById('playPauseIcon');
  const progressContainer = document.getElementById('progressContainer');
  const progressFilled = document.getElementById('progressFilled');
  const currentTimeEl = document.getElementById('currentTime');
  const durationTimeEl = document.getElementById('durationTime');
  const muteBtn = document.getElementById('muteBtn');
  const muteIcon = document.getElementById('muteIcon');
  const volumeSlider = document.getElementById('volumeSlider');
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  const fullscreenIcon = document.getElementById('fullscreenIcon');
  const loadingOverlay = document.getElementById('loadingOverlay');
  const errorOverlay = document.getElementById('errorOverlay');
  const centerActionIcon = document.getElementById('centerActionIcon');

  const icons = {
    play: 'M8 5v14l11-7z',
    pause: 'M6 19h4V5H6v14zm8-14v14h4V5h-4z',
    volumeHigh: 'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z',
    volumeMuted: 'M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z',
    fullscreen: 'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z',
    fullscreenExit: 'M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z',
    forward: 'M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z',
    rewind: 'M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z'
  };

  const togglePlay = () => {
    if (video.paused) { video.play(); showCenterIcon(icons.play); }
    else { video.pause(); showCenterIcon(icons.pause); }
  };

  const showCenterIcon = (path) => {
    if (!centerActionIcon) return;
    centerActionIcon.innerHTML = `<svg viewBox="0 0 24 24" style="width:36px;height:36px;fill:white;"><path d="${path}"/></svg>`;
    centerActionIcon.classList.remove('animate');
    void centerActionIcon.offsetWidth;
    centerActionIcon.classList.add('animate');
  };

  const formatTime = (s) => {
    if (isNaN(s)) return "00:00";
    const min = Math.floor(s / 60), sec = Math.floor(s % 60);
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const showControls = () => {
    if (!videoContainer) return;
    videoContainer.classList.add('show-controls');
    clearTimeout(playerControlsTimeout);
    if (!video.paused) {
      playerControlsTimeout = setTimeout(() => {
        if (!video.paused) videoContainer.classList.remove('show-controls');
      }, 3000);
    }
  };

  // Events
  if (playPauseBtn) playPauseBtn.onclick = togglePlay;
  video.onclick = togglePlay;
  video.onplay = () => { if (playPauseIcon) playPauseIcon.setAttribute('d', icons.pause); showControls(); };
  video.onpause = () => { if (playPauseIcon) playPauseIcon.setAttribute('d', icons.play); showControls(); };

  video.ontimeupdate = () => {
    if (!video.duration) return;
    if (progressFilled) progressFilled.style.width = `${(video.currentTime / video.duration) * 100}%`;
    if (currentTimeEl) currentTimeEl.textContent = formatTime(video.currentTime);
  };

  video.onloadedmetadata = () => { if (durationTimeEl) durationTimeEl.textContent = formatTime(video.duration); };

  if (progressContainer) {
    progressContainer.onclick = (e) => {
      const pos = (e.offsetX / progressContainer.offsetWidth) * video.duration;
      video.currentTime = pos;
    };
  }

  if (muteBtn) {
    muteBtn.onclick = () => {
      video.muted = !video.muted;
      if (muteIcon) muteIcon.setAttribute('d', video.muted ? icons.volumeMuted : icons.volumeHigh);
      if (volumeSlider) volumeSlider.value = video.muted ? 0 : video.volume;
    };
  }

  if (volumeSlider) {
    volumeSlider.oninput = (e) => {
      video.volume = e.target.value;
      video.muted = e.target.value == 0;
      if (muteIcon) muteIcon.setAttribute('d', video.muted ? icons.volumeMuted : icons.volumeHigh);
    };
  }

  if (fullscreenBtn) {
    fullscreenBtn.onclick = () => {
      if (!document.fullscreenElement) videoContainer.requestFullscreen();
      else document.exitFullscreen();
    };
  }

  document.onfullscreenchange = () => {
    const isFs = !!document.fullscreenElement;
    if (fullscreenIcon) fullscreenIcon.setAttribute('d', isFs ? icons.fullscreenExit : icons.fullscreen);
  };

  if (videoContainer) {
    videoContainer.onmousemove = showControls;
    videoContainer.ontouchstart = showControls;
  }

  if (loadingOverlay) video.onwaiting = () => loadingOverlay.style.opacity = 1;
  video.onplaying = () => {
    if (loadingOverlay) loadingOverlay.style.opacity = 0;
    if (errorOverlay) errorOverlay.style.opacity = 0;
  };
  video.onerror = () => {
    if (loadingOverlay) loadingOverlay.style.opacity = 0;
    if (errorOverlay) errorOverlay.style.opacity = 1;
  };

  const rb = document.getElementById('retryBtn');
  if (rb) rb.onclick = () => { video.load(); video.play(); };
}


// FAQ Accordion Logic
document.addEventListener('DOMContentLoaded', () => {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    item.addEventListener('click', () => {
      const isActive = item.classList.contains('active');

      // Close all other items
      faqItems.forEach(other => other.classList.remove('active'));

      // Toggle current
      if (!isActive) {
        item.classList.add('active');
      }
    });
  });
});


// Custom Mouse Glow Effect for Light Mode
document.addEventListener('DOMContentLoaded', () => {
  const glow = document.createElement('div');
  glow.className = 'mouse-glow';
  glow.id = 'mouseGlow';
  document.body.prepend(glow);

  document.addEventListener('mousemove', (e) => {
    if (document.documentElement.getAttribute('data-theme') === 'light') {
      glow.style.left = e.clientX + 'px';
      glow.style.top = e.clientY + 'px';
    }
  });
});


// ============================================================
// PROFESSIONAL COOKIE CONSENT SYSTEM
// ============================================================
function initCookieConsent() {
  // Respect user choice and don't bother admins
  const consent = localStorage.getItem('bca_cookie_consent');
  const isAdmin = localStorage.getItem('adminLoggedIn');

  if (!consent && !isAdmin) {
    // Professional Timing: Appear after Intro Animation + small delay
    setTimeout(() => {
      const popup = document.getElementById('cookiePopup');
      if (popup) popup.classList.add('show');
    }, 1800);
  }
}

function handleCookieChoice(choice) {
  // Store choice for industry standard persistence
  localStorage.setItem('bca_cookie_consent', choice);

  if (choice === 'accepted') {
    const prefCheckbox = document.getElementById('prefCookies');
    if (prefCheckbox) {
      localStorage.setItem('bca_personalization', prefCheckbox.checked ? 'enabled' : 'disabled');
    }
  }

  const popup = document.getElementById('cookiePopup');
  if (popup) {
    popup.classList.remove('show');
    // Complete removal from DOM after transition for performance
    setTimeout(() => popup.remove(), 800);
  }

  // Feedback for "Accept" choice
  if (choice === 'accepted' && typeof ModernEffects !== 'undefined') {
    ModernEffects.Toast?.show('Preferences Saved! ✨', 'success');
  }
}

// ============================================================
// SECURITY AND ACTIVE DEVICE CENTER FUNCTIONS
// ============================================================
function loadDeviceSessions() {
  const list = document.getElementById('deviceSessionsList');
  if (!list || !db) return;

  db.ref('sessions').once('value', (snap) => {
    if (!snap.exists()) {
      list.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:24px;">No active sessions found.</td></tr>`;
      return;
    }

    let html = '';
    const curSessId = localStorage.getItem('currentSessionId') || sessionStorage.getItem('currentSessionId');
    let activeCount = 0;
    
    snap.forEach((child) => {
      const key = child.key;
      const sess = child.val();
      
      // Filter out non-active sessions
      if (sess.status !== 'active') return;
      activeCount++;

      const isCurrent = (key === curSessId);
      const logDate = new Date(sess.loginTime).toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
      const lastActiveDate = new Date(sess.lastActive).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      
      // Icon
      let deviceIcon = '💻';
      if (sess.device && sess.device.toLowerCase().includes('phone')) deviceIcon = '📱';
      else if (sess.device && sess.device.toLowerCase().includes('ipad')) deviceIcon = '📟';

      html += `
        <tr style="border-bottom: 1px solid var(--border-glass); transition: background 0.2s;" class="${isCurrent ? 'record-row-new' : ''}">
          <td style="padding: 12px 16px;">
            <div class="device-item-cell">
              <span class="device-item-cell-icon">${deviceIcon}</span>
              <div class="device-item-cell-details">
                <span class="device-item-name">${sess.device || 'Unknown Device'}</span>
                <span style="font-size: 0.72rem; color: var(--text-muted); display: block;">ID: ${sess.deviceId || 'N/A'}</span>
              </div>
            </div>
          </td>
          <td style="padding: 12px 16px; color: var(--text-muted);">
            <div>${sess.browser || 'Other'} on ${sess.os || 'Other'}</div>
            <div style="font-size: 0.75rem; color: #818cf8;">${sess.email || 'N/A'}</div>
          </td>
          <td style="padding: 12px 16px; color: var(--text-muted);">
            <div>Logged: ${logDate}</div>
            <div style="font-size: 0.75rem;">Active: ${lastActiveDate}</div>
          </td>
          <td style="padding: 12px 16px;">
            <span style="display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; background: ${isCurrent ? 'rgba(0, 242, 254, 0.1)' : 'rgba(16, 185, 129, 0.1)'}; color: ${isCurrent ? '#00f2fe' : '#10b981'}; font-weight: 700;">
              ${isCurrent ? 'Current' : 'Active'}
            </span>
          </td>
          <td style="padding: 12px 16px; text-align: right;">
            ${isCurrent ? `
              <button class="btn-outline" onclick="adminLogout()" style="padding: 4px 10px; font-size: 0.75rem; border-radius: 6px; cursor: pointer;">Sign Out</button>
            ` : `
              <button class="btn-danger" onclick="revokeSession('${key}')" style="padding: 4px 10px; font-size: 0.75rem; border-radius: 6px; cursor: pointer;">Revoke</button>
            `}
          </td>
        </tr>
      `;
    });

    list.innerHTML = html || `<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:24px;">No active sessions found.</td></tr>`;
    
    const sessWidget = document.getElementById('secWidgetSessions');
    if (sessWidget) sessWidget.textContent = activeCount;
    const activeLabel = document.getElementById('kpiActiveSessionsCount');
    if (activeLabel) activeLabel.textContent = `${activeCount} Active`;

    updateSecurityDashboardScore();
  });
}

function revokeSession(sessionId) {
  if (!confirm("Are you sure you want to revoke this session? The device will be logged out immediately.")) return;
  if (!db) return;
  
  db.ref(`sessions/${sessionId}/status`).set('revoked')
    .then(() => {
      showToast("Session revoked.", "success");
      logSecurityEvent("Session Revocation", `Session ID ${sessionId} was manually revoked by admin.`);
      loadDeviceSessions();
    })
    .catch(err => {
      console.error(err);
      showToast("Failed to revoke session.", "error");
    });
}

function logoutAllDevices() {
  if (!confirm("Are you sure you want to revoke all other admin sessions? This will log out all other active devices.")) return;
  if (!db) return;

  const curSessId = localStorage.getItem('currentSessionId') || sessionStorage.getItem('currentSessionId');
  db.ref('sessions').once('value', (snap) => {
    if (snap.exists()) {
      let promises = [];
      snap.forEach((child) => {
        if (child.key !== curSessId && child.val().status === 'active') {
          promises.push(db.ref(`sessions/${child.key}/status`).set('revoked'));
        }
      });
      Promise.all(promises).then(() => {
        showToast("All other sessions revoked.", "success");
        logSecurityEvent("Global Revocation", "All other active admin sessions were revoked.");
        loadDeviceSessions();
      }).catch(err => {
        console.error(err);
        showToast("Failed to revoke sessions.", "error");
      });
    }
  });
}

function toggleEmergencyLockdown(enabled) {
  if (!db) return;
  const user = (typeof firebase !== 'undefined' && firebase.auth) ? firebase.auth().currentUser : null;
  const email = user ? user.email : 'Superadmin@bcastore.com';

  if (enabled) {
    if (!confirm("🚨 WARNING: Enabling Emergency Lockdown will revoke ALL active sessions except your current session, and block all student access. Proceed?")) {
      document.getElementById('switchLockdown').checked = false;
      return;
    }
    
    db.ref('system/lockdown').set(true)
      .then(async () => {
        showToast("Lockdown enabled!", "error");
        document.getElementById('lockdownBadge').textContent = "ACTIVE";
        document.getElementById('lockdownBadge').style.background = "rgba(239, 68, 68, 0.2)";
        document.getElementById('lockdownBadge').style.color = "#ef4444";
        document.getElementById('lockdownActiveNotice').style.display = "block";
        
        await logSecurityEvent("Lockdown Activation", `Emergency Lockdown triggered by ${email}`);
        
        // Revoke all other active sessions in DB
        const curSessId = localStorage.getItem('currentSessionId') || sessionStorage.getItem('currentSessionId');
        db.ref('sessions').once('value', (snap) => {
          if (snap.exists()) {
            snap.forEach((child) => {
              if (child.key !== curSessId && child.val().status === 'active') {
                db.ref(`sessions/${child.key}/status`).set('revoked');
              }
            });
          }
        });

        updateSecurityDashboardScore();
      });
  } else {
    if (!confirm("Disable Emergency Lockdown? Student access will be restored.")) {
      document.getElementById('switchLockdown').checked = true;
      return;
    }
    
    db.ref('system/lockdown').set(false)
      .then(async () => {
        showToast("Lockdown disabled.", "success");
        document.getElementById('lockdownBadge').textContent = "DISABLED";
        document.getElementById('lockdownBadge').style.background = "rgba(156, 163, 175, 0.15)";
        document.getElementById('lockdownBadge').style.color = "#9ca3af";
        document.getElementById('lockdownActiveNotice').style.display = "none";
        
        await logSecurityEvent("Lockdown Deactivation", `Emergency Lockdown disabled by ${email}`);
        updateSecurityDashboardScore();
      });
  }
}

function loadSecurityDashboardData() {
  if (!db) return;

  // Listen to failed logins
  db.ref('failed_login_count').on('value', (snap) => {
    const count = snap.val() || 0;
    const failWidget = document.getElementById('secWidgetFailedLogins');
    if (failWidget) failWidget.textContent = count;
    const label = document.getElementById('kpiFailedLoginsLabel');
    if (label) label.textContent = `${count} Failures`;
    updateSecurityDashboardScore();
  });

  // Listen to alerts count
  db.ref('security_alerts').on('value', (snap) => {
    const count = snap.numChildren() || 0;
    const alertWidget = document.getElementById('secWidgetAlerts');
    if (alertWidget) alertWidget.textContent = count;
    const label = document.getElementById('secAlertsCountLabel');
    if (label) label.textContent = `${count} Alerts`;
  });

  // Listen to lockdown state to sync toggle button
  db.ref('system/lockdown').on('value', (snap) => {
    const active = !!snap.val();
    const toggle = document.getElementById('switchLockdown');
    if (toggle) toggle.checked = active;
    
    const badge = document.getElementById('lockdownBadge');
    if (badge) {
      badge.textContent = active ? "ACTIVE" : "DISABLED";
      badge.style.background = active ? "rgba(239, 68, 68, 0.2)" : "rgba(156, 163, 175, 0.15)";
      badge.style.color = active ? "#ef4444" : "#9ca3af";
    }
    
    const notice = document.getElementById('lockdownActiveNotice');
    if (notice) notice.style.display = active ? "block" : "none";
    
    updateSecurityDashboardScore();
  });

  // Sync security audit logs feed
  loadSecurityLogsFeed();
}

function updateSecurityDashboardScore() {
  const failCount = parseInt(document.getElementById('secWidgetFailedLogins')?.textContent || '0');
  const lockdownActive = document.getElementById('switchLockdown')?.checked;
  
  let score = 100;
  let statusText = "Optimal";
  let color = "#10b981";
  
  if (lockdownActive) {
    score -= 30;
    statusText = "LOCKDOWN";
    color = "#ef4444";
  }
  
  if (failCount > 0) {
    score -= Math.min(30, failCount * 5);
  }
  
  if (failCount > 10) {
    statusText = "Risk Detected";
    color = "#f59e0b";
  }

  score = Math.max(0, score);
  
  const scoreWidget = document.getElementById('secWidgetHealthScore');
  if (scoreWidget) {
    scoreWidget.textContent = `${score}%`;
    scoreWidget.style.color = color;
  }
  
  const label = document.getElementById('secHealthScoreLabel');
  if (label) {
    label.textContent = statusText;
    label.style.color = color;
  }

  const badge = document.getElementById('secHealthBadge');
  if (badge) {
    badge.textContent = lockdownActive ? "🚨 Lockdown Active" : (score >= 80 ? "🛡️ System Secure" : "⚠️ Attention Required");
    badge.style.background = lockdownActive ? "rgba(239, 68, 68, 0.1)" : (score >= 80 ? "rgba(16, 185, 129, 0.1)" : "rgba(245, 158, 11, 0.1)");
    badge.style.color = lockdownActive ? "#ef4444" : (score >= 80 ? "#10b981" : "#f59e0b");
    badge.style.borderColor = lockdownActive ? "rgba(239, 68, 68, 0.2)" : (score >= 80 ? "rgba(16, 185, 129, 0.2)" : "rgba(245, 158, 11, 0.2)");
  }
}

function loadSecurityLogsFeed() {
  const timeline = document.getElementById('securityLogTimeline');
  if (!timeline || !db) return;

  db.ref('securityLogs').orderByChild('timestamp').limitToLast(20).on('value', (snap) => {
    if (!snap.exists()) {
      timeline.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 24px 0;">No security events logged yet.</div>`;
      return;
    }

    let logs = [];
    snap.forEach((child) => {
      logs.push(child.val());
    });
    
    logs.reverse();

    timeline.innerHTML = logs.map((log) => {
      const time = new Date(log.timestamp).toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', day: 'numeric', month: 'short' });
      let bg = "rgba(59, 130, 246, 0.1)";
      let color = "#3b82f6";
      let icon = "🔑";

      if (log.type.includes("Fail") || log.type.includes("Lockout") || log.type.includes("Revoke")) {
        bg = "rgba(239, 68, 68, 0.1)";
        color = "#ef4444";
        icon = "🚨";
      } else if (log.type.includes("Lockdown")) {
        bg = "rgba(239, 68, 68, 0.15)";
        color = "#f87171";
        icon = "🔒";
      } else if (log.type.includes("Maintenance")) {
        bg = "rgba(245, 158, 11, 0.1)";
        color = "#f59e0b";
        icon = "🛠️";
      } else if (log.type.includes("Logout")) {
        bg = "rgba(156, 163, 175, 0.1)";
        color = "#9ca3af";
        icon = "🚪";
      }

      return `
        <div class="sec-log-row">
          <div class="sec-log-icon" style="background: ${bg}; color: ${color};">${icon}</div>
          <div class="sec-log-body">
            <div style="font-weight: 700; color: #fff;">${log.type}</div>
            <div style="color: var(--text-muted); font-size: 0.78rem; margin-top: 2px;">${log.details}</div>
            <div class="sec-log-meta">
              <span>Admin: ${log.adminId}</span>
              <span>${time}</span>
            </div>
          </div>
        </div>
      `;
    }).join('');
  });
}

